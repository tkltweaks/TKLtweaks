# ============================================================
#  TKL Tweaks  v5.4 - layout fixed UI, animations, fullscreen, extra tweaks
#  Windows tweaking suite with Free / Premium / Ultimate plans.
#  Every change is backed up first and can be undone.
#  (ASCII only on purpose so it works with every PowerShell encoding.)
# ============================================================

# ---------- Product configuration (edit before you sell) ----------
$TKL = @{
    Brand         = "TKL Tweaks"
    Version       = "6.0"
    # Optional: URL of YOUR license/login server. When empty the app uses
    # local accounts and offline license keys (see TKL-KeyGen.ps1).
    ApiUrl        = ""
    # Secret used to sign offline license keys. MUST match TKL-KeyGen.ps1.
    LicenseSecret = "uJpydOsQzIkdeuD3kSiUeIS6UpDZ0KDJQNRvW0C6"
}

# ---------- Auto-elevate ----------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell -Verb RunAs -WindowStyle Hidden -ArgumentList `
        "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`""
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = "SilentlyContinue"

# ---------- Native canvas: animated backgrounds run in compiled C# ----------
Add-Type -ReferencedAssemblies System.Windows.Forms,System.Drawing -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public static class Native
{
    [DllImport("user32.dll", SetLastError = true)]
    static extern bool SystemParametersInfo(uint uiAction, uint uiParam, int[] pvParam, uint fWinIni);
    public static void SetMouse(int t1, int t2, int accel)
    {
        SystemParametersInfo(0x0004, 0, new int[] { t1, t2, accel }, 3);
    }
}

public class BufferedPanel : Panel
{
    public BufferedPanel()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
    }
}

public static class UiTheme
{
    public static Color Accent = Color.FromArgb(124, 92, 255);
    public static Color Accent2 = Color.FromArgb(90, 215, 255);
    public static Color Track = Color.FromArgb(18, 19, 29);
    public static Color Neutral = Color.FromArgb(58, 62, 86);

    public static Color Mix(Color a, Color b, float t)
    {
        t = Math.Max(0f, Math.Min(1f, t));
        return Color.FromArgb((int)(a.A + (b.A - a.A) * t), (int)(a.R + (b.R - a.R) * t),
                              (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }
    public static GraphicsPath Round(RectangleF r, float rad)
    {
        GraphicsPath p = new GraphicsPath();
        float d = Math.Min(rad * 2, Math.Min(r.Width, r.Height));
        if (d < 1) { p.AddRectangle(r); return p; }
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }
    public static void PaintUnder(Control c, Graphics g)
    {
        Card cd = c.Parent as Card;
        if (cd != null && cd.Glass)
        {
            GraphicsState st = g.Save();
            g.TranslateTransform(-c.Left, -c.Top);
            cd.PaintGlass(g);
            g.Restore(st);
            return;
        }
        using (SolidBrush b = new SolidBrush(ParentBack(c))) g.FillRectangle(b, c.ClientRectangle);
    }
    public static Color ParentBack(Control c)
    {
        Control p = c.Parent;
        while (p != null && p.BackColor.A < 255) p = p.Parent;
        return p != null ? p.BackColor : Color.FromArgb(28, 30, 44);
    }
}

// Controls that animate share one timer that only runs while something is moving.
public abstract class AnimControl : Control
{
    static readonly List<AnimControl> active = new List<AnimControl>();
    static Timer anim;

    protected AnimControl()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer |
                 ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
        SetStyle(ControlStyles.StandardDoubleClick, false);
        Cursor = Cursors.Hand;
    }
    protected void Kick()
    {
        if (!active.Contains(this)) active.Add(this);
        if (anim == null) { anim = new Timer(); anim.Interval = 15; anim.Tick += OnAnim; }
        if (!anim.Enabled) anim.Start();
    }
    static void OnAnim(object s, EventArgs e)
    {
        for (int i = active.Count - 1; i >= 0; i--)
        {
            AnimControl c = active[i];
            bool more = !c.IsDisposed && c.Step();
            if (!c.IsDisposed) c.Invalidate();
            if (!more) active.RemoveAt(i);
        }
        if (active.Count == 0) anim.Stop();
    }
    protected static float Toward(float v, float target, float step)
    {
        if (v < target) return Math.Min(target, v + step);
        return Math.Max(target, v - step);
    }
    protected abstract bool Step();
    protected void PaintParentBack(Graphics g)
    {
        UiTheme.PaintUnder(this, g);
    }
}

public class TButton : AnimControl, IButtonControl
{
    float hover, hoverTarget;
    bool pressed;
    static Font glyphFont;
    public int Radius = 12;
    public string Glyph = "";
    public bool Selected;
    public Color Color2 = Color.Empty;
    public Color HoverColor = Color.Empty;
    ContentAlignment align = ContentAlignment.MiddleCenter;
    DialogResult result = DialogResult.None;

    public TButton()
    {
        BackColor = UiTheme.Neutral; ForeColor = Color.White;
        Size = new Size(120, 34); TabStop = true;
    }
    public ContentAlignment TextAlign { get { return align; } set { align = value; Invalidate(); } }
    public DialogResult DialogResult { get { return result; } set { result = value; } }
    public void NotifyDefault(bool value) { }
    public void PerformClick() { if (Enabled && Visible) OnClick(EventArgs.Empty); }

    protected override bool Step()
    {
        hover = Toward(hover, hoverTarget, 0.28f);
        return hover != hoverTarget;
    }
    protected override void OnMouseEnter(EventArgs e) { hoverTarget = 1f; Kick(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hoverTarget = 0f; pressed = false; Kick(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { pressed = true; Invalidate(); } base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { pressed = false; Invalidate(); base.OnMouseUp(e); }
    protected override void OnEnabledChanged(EventArgs e) { if (!Enabled) { hover = hoverTarget = 0f; pressed = false; } Invalidate(); base.OnEnabledChanged(e); }
    protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }
    protected override void OnBackColorChanged(EventArgs e) { Invalidate(); base.OnBackColorChanged(e); }
    protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
    protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
    protected override void OnKeyUp(KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter) { PerformClick(); e.Handled = true; }
        base.OnKeyUp(e);
    }

    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        PaintParentBack(g);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        Color parent = UiTheme.ParentBack(this);
        Color baseC = BackColor.A == 0 ? parent : BackColor;
        Color c = HoverColor.IsEmpty ? UiTheme.Mix(baseC, Color.White, hover * 0.28f) : UiTheme.Mix(baseC, HoverColor, hover);
        if (pressed) c = UiTheme.Mix(c, Color.Black, 0.18f);
        if (!Enabled) c = UiTheme.Mix(baseC, parent, 0.55f);
        Card pc = Parent as Card;
        if (pc != null && pc.Glass && baseC.ToArgb() == pc.BackColor.ToArgb())
            c = Color.FromArgb(Math.Min(255, pc.Opacity + (int)(hover * 110) + (pressed ? 50 : 0)), c);
        RectangleF r = new RectangleF(0.5f, pressed ? 1.5f : 0.5f, Width - 1.5f, Height - (pressed ? 2.5f : 1.5f));
        using (GraphicsPath p = UiTheme.Round(r, Radius))
        {
            if (!Color2.IsEmpty && Enabled)
            {
                Color c2 = UiTheme.Mix(Color2, Color.White, hover * 0.28f);
                using (LinearGradientBrush lb = new LinearGradientBrush(new RectangleF(0, 0, Width, Height), c, c2, 0f))
                    g.FillPath(lb, p);
            }
            else using (SolidBrush b = new SolidBrush(c)) g.FillPath(b, p);
            // soft top highlight gives the button some depth
            using (LinearGradientBrush hl = new LinearGradientBrush(new RectangleF(0, 0, Width, Height),
                       Color.FromArgb(Enabled ? 26 : 8, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                g.FillPath(hl, p);
            if (Selected)
                using (Pen pen = new Pen(Color.White, 2f))
                using (GraphicsPath p2 = UiTheme.Round(new RectangleF(1.5f, 1.5f, Width - 3.5f, Height - 3.5f), Radius - 1))
                    g.DrawPath(pen, p2);
            else if (Focused && ShowFocusCues)
                using (Pen pen = new Pen(Color.FromArgb(120, 255, 255, 255), 1f)) g.DrawPath(pen, p);
        }
        Color fc = Enabled ? ForeColor : Color.FromArgb(130, ForeColor);
        Rectangle tr = new Rectangle(Padding.Left + 6, pressed ? 1 : 0, Width - Padding.Left - Padding.Right - 12, Height);
        if (Glyph.Length > 0)
        {
            if (glyphFont == null) glyphFont = new Font("Segoe MDL2 Assets", 10f);
            if (string.IsNullOrEmpty(Text))
            {
                // Icon-only button (caption min/max/close): center the glyph
                TextRenderer.DrawText(g, Glyph, glyphFont, new Rectangle(0, pressed ? 1 : 0, Width, Height),
                    fc, TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPrefix);
                tr.Width = 0;
            }
            else
            {
                Rectangle gr = new Rectangle(tr.X, tr.Y, 22, Height);
                TextRenderer.DrawText(g, Glyph, glyphFont, gr, fc, TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter | TextFormatFlags.NoPrefix);
                tr.X += 28; tr.Width -= 28;
            }
        }
        TextFormatFlags f = TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine;
        if (align == ContentAlignment.MiddleLeft || align == ContentAlignment.TopLeft || align == ContentAlignment.BottomLeft) f |= TextFormatFlags.Left;
        else if (align == ContentAlignment.MiddleRight) f |= TextFormatFlags.Right;
        else f |= TextFormatFlags.HorizontalCenter;
        TextRenderer.DrawText(g, Text, Font, tr, fc, f);
    }
}

public class TToggle : AnimControl
{
    bool on;
    float pos;
    public event EventHandler CheckedChanged;

    public TToggle() { Size = new Size(200, 24); ForeColor = Color.White; TabStop = true; }
    public bool Checked
    {
        get { return on; }
        set
        {
            if (on == value) return;
            on = value;
            if (IsHandleCreated && Visible) Kick(); else pos = on ? 1f : 0f;
            Invalidate();
            if (CheckedChanged != null) CheckedChanged(this, EventArgs.Empty);
        }
    }
    protected override bool Step()
    {
        pos = Toward(pos, on ? 1f : 0f, 0.22f);
        return pos != (on ? 1f : 0f);
    }
    public override Size GetPreferredSize(Size proposed) { return new Size(54 + TextRenderer.MeasureText(Text, Font).Width, Math.Max(24, Height)); }
    protected override void OnTextChanged(EventArgs e) { Width = GetPreferredSize(Size.Empty).Width; Invalidate(); base.OnTextChanged(e); }
    protected override void OnFontChanged(EventArgs e) { Width = GetPreferredSize(Size.Empty).Width; Invalidate(); base.OnFontChanged(e); }
    protected override void OnClick(EventArgs e) { Checked = !Checked; base.OnClick(e); }
    protected override void OnKeyUp(KeyEventArgs e) { if (e.KeyCode == Keys.Space) Checked = !Checked; base.OnKeyUp(e); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        PaintParentBack(g);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        float th = 20f, tw = 40f, ty = (Height - th) / 2f;
        RectangleF tr = new RectangleF(1, ty, tw, th);
        using (GraphicsPath p = UiTheme.Round(tr, th / 2f))
        {
            using (SolidBrush b = new SolidBrush(UiTheme.Mix(UiTheme.Neutral, UiTheme.Accent, pos))) g.FillPath(b, p);
        }
        float k = th - 6f, kx = 4f + pos * (tw - k - 6f);
        using (SolidBrush kb = new SolidBrush(Color.FromArgb(40, 0, 0, 0))) g.FillEllipse(kb, kx, ty + 4f, k, k);
        using (SolidBrush kb = new SolidBrush(Color.White)) g.FillEllipse(kb, kx, ty + 3f, k, k);
        TextRenderer.DrawText(g, Text, Font, new Rectangle(50, 0, Width - 50, Height), Enabled ? ForeColor : Color.Gray,
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPrefix);
    }
}

public class TSlider : AnimControl
{
    int min = 0, max = 100, val = 0;
    bool drag;
    float hover, hoverTarget;
    public event EventHandler ValueChanged;

    public TSlider() { Size = new Size(300, 30); TabStop = true; }
    public int Minimum { get { return min; } set { min = value; if (max < min) max = min; Value = val; Invalidate(); } }
    public int Maximum { get { return max; } set { max = value; if (min > max) min = max; Value = val; Invalidate(); } }
    public int Value
    {
        get { return val; }
        set
        {
            int v = Math.Max(min, Math.Min(max, value));
            if (v == val) return;
            val = v; Invalidate();
            if (ValueChanged != null) ValueChanged(this, EventArgs.Empty);
        }
    }
    protected override bool Step()
    {
        hover = Toward(hover, hoverTarget, 0.2f);
        return hover != hoverTarget;
    }
    void SetFromX(int x)
    {
        float t = (x - 10f) / Math.Max(1f, Width - 20f);
        Value = min + (int)Math.Round(Math.Max(0f, Math.Min(1f, t)) * (max - min));
    }
    protected override void OnMouseEnter(EventArgs e) { hoverTarget = 1f; Kick(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { if (!drag) { hoverTarget = 0f; Kick(); } base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { drag = true; Focus(); SetFromX(e.X); } base.OnMouseDown(e); }
    protected override void OnMouseMove(MouseEventArgs e) { if (drag) SetFromX(e.X); base.OnMouseMove(e); }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        drag = false;
        if (!ClientRectangle.Contains(e.Location)) { hoverTarget = 0f; Kick(); }
        base.OnMouseUp(e);
    }
    protected override void OnMouseWheel(MouseEventArgs e) { Value += Math.Sign(e.Delta) * Math.Max(1, (max - min) / 50); base.OnMouseWheel(e); }
    protected override bool IsInputKey(Keys k) { return k == Keys.Left || k == Keys.Right || base.IsInputKey(k); }
    protected override void OnKeyDown(KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Left) Value -= 1; else if (e.KeyCode == Keys.Right) Value += 1;
        base.OnKeyDown(e);
    }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        PaintParentBack(g);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        float cy = Height / 2f, x0 = 10f, x1 = Width - 10f;
        float t = max > min ? (float)(val - min) / (max - min) : 0f;
        float tx = x0 + (x1 - x0) * t;
        using (GraphicsPath p = UiTheme.Round(new RectangleF(x0, cy - 3, x1 - x0, 6), 3))
        using (SolidBrush b = new SolidBrush(UiTheme.Track)) g.FillPath(b, p);
        if (tx - x0 > 1)
            using (GraphicsPath p = UiTheme.Round(new RectangleF(x0, cy - 3, tx - x0, 6), 3))
            using (LinearGradientBrush lb = new LinearGradientBrush(new RectangleF(x0 - 1, 0, x1 - x0 + 2, Height), UiTheme.Accent, UiTheme.Accent2, 0f))
                g.FillPath(lb, p);
        float r = 7f + hover * 2f;
        using (SolidBrush glow = new SolidBrush(Color.FromArgb((int)(60 * hover), UiTheme.Accent))) g.FillEllipse(glow, tx - r - 4, cy - r - 4, (r + 4) * 2, (r + 4) * 2);
        using (SolidBrush kb = new SolidBrush(Color.White)) g.FillEllipse(kb, tx - r, cy - r, r * 2, r * 2);
        using (Pen pen = new Pen(UiTheme.Accent, 2.5f)) g.DrawEllipse(pen, tx - r + 1.5f, cy - r + 1.5f, r * 2 - 3, r * 2 - 3);
    }
}

public class DarkCombo : ComboBox
{
    public DarkCombo()
    {
        DrawMode = DrawMode.OwnerDrawFixed; DropDownStyle = ComboBoxStyle.DropDownList;
        FlatStyle = FlatStyle.Flat; ItemHeight = 22; Cursor = Cursors.Hand;
    }
    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        if (e.Index < 0) return;
        bool sel = (e.State & DrawItemState.Selected) != 0 && (e.State & DrawItemState.ComboBoxEdit) == 0;
        using (SolidBrush b = new SolidBrush(sel ? UiTheme.Accent : BackColor)) e.Graphics.FillRectangle(b, e.Bounds);
        Rectangle r = new Rectangle(e.Bounds.X + 6, e.Bounds.Y, e.Bounds.Width - 6, e.Bounds.Height);
        TextRenderer.DrawText(e.Graphics, GetItemText(Items[e.Index]), Font, r, sel ? Color.White : ForeColor,
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
    }
}

public class DarkList : ListBox
{
    public DarkList() { DrawMode = DrawMode.OwnerDrawFixed; ItemHeight = 34; BorderStyle = BorderStyle.None; IntegralHeight = false; }
    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        Graphics g = e.Graphics;
        using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, e.Bounds);
        if (e.Index < 0 || e.Index >= Items.Count) return;
        bool sel = (e.State & DrawItemState.Selected) != 0;
        if (sel)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (GraphicsPath p = UiTheme.Round(new RectangleF(e.Bounds.X + 4, e.Bounds.Y + 3, e.Bounds.Width - 9, e.Bounds.Height - 6), 8))
            using (LinearGradientBrush lb = new LinearGradientBrush(e.Bounds, UiTheme.Accent, UiTheme.Mix(UiTheme.Accent, UiTheme.Accent2, 0.6f), 0f))
                g.FillPath(lb, p);
        }
        Rectangle r = new Rectangle(e.Bounds.X + 16, e.Bounds.Y, e.Bounds.Width - 20, e.Bounds.Height);
        TextRenderer.DrawText(g, GetItemText(Items[e.Index]), Font, r, sel ? Color.White : ForeColor,
            TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
    }
}

public class TabStrip : Control
{
    public event EventHandler SelectedChanged;
    public Color MutedColor = Color.FromArgb(150, 155, 180);
    List<string> keys = new List<string>(), texts = new List<string>();
    List<int> counts = new List<int>();
    List<RectangleF> rects = new List<RectangleF>();
    int sel = 0, hover = -1;
    float offset = 0f, total = 0f, indX = -1f, indW = 0f;
    bool showCounts = true;
    int pad = 22;
    Font small;
    Timer anim;

    public TabStrip()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        Height = 34; Cursor = Cursors.Hand;
        anim = new Timer(); anim.Interval = 15;
        anim.Tick += delegate { Step(); };
    }
    protected override void Dispose(bool disposing) { if (disposing) { anim.Dispose(); if (small != null) small.Dispose(); } base.Dispose(disposing); }

    public void AddTab(string key, string text, int count) { keys.Add(key); texts.Add(text); counts.Add(count); Relayout(); Invalidate(); }
    public int Count { get { return keys.Count; } }
    public string SelectedKey { get { return sel < keys.Count ? keys[sel] : "all"; } }
    public int SelectedIndex
    {
        get { return sel; }
        set
        {
            if (value < 0 || value >= keys.Count || value == sel) return;
            sel = value; EnsureVisible(); anim.Start(); Invalidate();
            if (SelectedChanged != null) SelectedChanged(this, EventArgs.Empty);
        }
    }

    void Relayout()
    {
        if (small != null) small.Dispose();
        small = new Font(Font.FontFamily, Math.Max(6f, Font.Size - 1.5f), FontStyle.Bold);
        for (int pass = 0; pass < 3; pass++)
        {
            showCounts = pass == 0; pad = pass < 2 ? 22 : 12;
            rects.Clear(); float x = 0;
            for (int i = 0; i < keys.Count; i++)
            {
                float w = TextRenderer.MeasureText(texts[i], Font).Width + pad;
                if (showCounts && counts[i] >= 0) w += TextRenderer.MeasureText(counts[i].ToString(), small).Width + 2;
                rects.Add(new RectangleF(x, 0, w, Height)); x += w + 4;
            }
            total = x - 4;
            if (total <= Width) break;
        }
        Clamp();
        if (rects.Count > sel) { indX = rects[sel].X; indW = rects[sel].Width; }
    }
    void Clamp() { offset = Math.Max(0f, Math.Min(offset, Math.Max(0f, total - Width))); }
    void EnsureVisible()
    {
        if (sel >= rects.Count) return;
        RectangleF r = rects[sel];
        if (r.X - offset < 0) offset = r.X;
        if (r.Right - offset > Width) offset = r.Right - Width;
        Clamp();
    }
    void Step()
    {
        if (sel >= rects.Count) { anim.Stop(); return; }
        float tx = rects[sel].X, tw = rects[sel].Width;
        indX += (tx - indX) * 0.28f; indW += (tw - indW) * 0.28f;
        if (Math.Abs(tx - indX) < 0.5f && Math.Abs(tw - indW) < 0.5f) { indX = tx; indW = tw; anim.Stop(); }
        Invalidate();
    }
    protected override void OnFontChanged(EventArgs e) { base.OnFontChanged(e); Relayout(); }
    protected override void OnResize(EventArgs e) { base.OnResize(e); Relayout(); }

    int HitTest(int x) { for (int i = 0; i < rects.Count; i++) if (x + offset >= rects[i].X && x + offset < rects[i].Right) return i; return -1; }
    protected override void OnMouseMove(MouseEventArgs e) { int h = HitTest(e.X); if (h != hover) { hover = h; Invalidate(); } base.OnMouseMove(e); }
    protected override void OnMouseLeave(EventArgs e) { hover = -1; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseEnter(EventArgs e) { if (total > Width) Focus(); base.OnMouseEnter(e); }
    protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { int h = HitTest(e.X); if (h >= 0) SelectedIndex = h; } base.OnMouseDown(e); }
    protected override void OnMouseWheel(MouseEventArgs e) { offset -= e.Delta / 3f; Clamp(); Invalidate(); base.OnMouseWheel(e); }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        UiTheme.PaintUnder(this, g);
        using (GraphicsPath tp = UiTheme.Round(new RectangleF(0, 0, Width - 1, Height - 1), 10))
        using (SolidBrush tb = new SolidBrush(UiTheme.Track)) g.FillPath(tb, tp);
        if (rects.Count == 0) return;
        if (hover >= 0 && hover != sel)
            using (GraphicsPath hp = UiTheme.Round(new RectangleF(rects[hover].X - offset + 3, 4, rects[hover].Width - 6, Height - 8), 8))
            using (SolidBrush hb = new SolidBrush(Color.FromArgb(22, 255, 255, 255))) g.FillPath(hb, hp);
        RectangleF ir = new RectangleF(indX - offset + 3, 4, Math.Max(8f, indW - 6), Height - 8);
        using (GraphicsPath ip = UiTheme.Round(ir, 8))
        using (LinearGradientBrush ib = new LinearGradientBrush(new RectangleF(ir.X - 1, 0, ir.Width + 2, Height), UiTheme.Accent, UiTheme.Mix(UiTheme.Accent, UiTheme.Accent2, 0.7f), 0f))
            g.FillPath(ib, ip);
        for (int i = 0; i < rects.Count; i++)
        {
            float x = rects[i].X - offset;
            if (x > Width || x + rects[i].Width < 0) continue;
            bool on = i == sel;
            Color tc = on ? Color.White : (i == hover ? ForeColor : MutedColor);
            Size ts = TextRenderer.MeasureText(texts[i], Font);
            int tx = (int)(x + pad / 2);
            TextRenderer.DrawText(g, texts[i], Font, new Rectangle(tx, 0, ts.Width + 2, Height), tc, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPrefix);
            if (showCounts && counts[i] >= 0)
                TextRenderer.DrawText(g, counts[i].ToString(), small, new Rectangle(tx + ts.Width, 1, 40, Height), Color.FromArgb(on ? 220 : 150, tc),
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPrefix);
        }
        if (offset > 0)
            using (LinearGradientBrush fb = new LinearGradientBrush(new RectangleF(0, 0, 28, Height), UiTheme.Track, Color.FromArgb(0, UiTheme.Track), 0f)) g.FillRectangle(fb, 0, 0, 28, Height);
        if (offset < total - Width)
            using (LinearGradientBrush fb = new LinearGradientBrush(new RectangleF(Width - 28, 0, 28, Height), Color.FromArgb(0, UiTheme.Track), UiTheme.Track, 0f)) g.FillRectangle(fb, Width - 28, 0, 28, Height);
    }
}

public class Card : Panel
{
    public int Radius = 16;
    public Color BorderColor = Color.FromArgb(62, 66, 96);
    public int Opacity = 255;
    public ParticleCanvas Host;
    public bool Glass { get { return Opacity < 255 && Host != null; } }
    public void PaintGlass(Graphics g)
    {
        if (Opacity >= 200 || Host == null)
        {
            using (SolidBrush b = new SolidBrush(Color.FromArgb(Math.Max(Opacity, 200), BackColor)))
                g.FillRectangle(b, 0, 0, Width, Height);
            return;
        }
        using (GraphicsPath clip = UiTheme.Round(new RectangleF(0, 0, Width, Height), Radius))
        {
            g.SetClip(clip);
            Point o = Host.PointToClient(PointToScreen(Point.Empty));
            Host.PaintUnder(g, new Rectangle(o.X, o.Y, Width, Height));
            using (SolidBrush b = new SolidBrush(Color.FromArgb(Math.Max(Opacity, 155), BackColor)))
                g.FillRectangle(b, 0, 0, Width, Height);
            g.ResetClip();
        }
    }
    protected override void OnPaintBackground(PaintEventArgs e)
    {
        if (Glass) PaintGlass(e.Graphics); else base.OnPaintBackground(e);
    }
    public Card()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                 ControlStyles.SupportsTransparentBackColor, true);
        BackColor = Color.FromArgb(255, 28, 30, 44);
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using (GraphicsPath p = UiTheme.Round(new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f), Radius))
        {
            using (Pen pen = new Pen(BorderColor, 1.4f)) e.Graphics.DrawPath(pen, p);
            using (GraphicsPath p2 = UiTheme.Round(new RectangleF(1.8f, 1.8f, Width - 4f, Height - 4f), Math.Max(4, Radius - 2)))
            using (Pen hi = new Pen(Color.FromArgb(40, 255, 255, 255), 1f))
                e.Graphics.DrawPath(hi, p2);
        }
        base.OnPaint(e);
    }
}

public class TForm : Form
{
    public TForm()
    {
        FormBorderStyle = FormBorderStyle.None;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
    }
    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ClassStyle |= 0x20000;          // CS_DROPSHADOW
            cp.Style |= 0x20000 | 0x80000;     // WS_MINIMIZEBOX | WS_SYSMENU: taskbar click minimizes/restores
            return cp;
        }
    }
    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        NativeUi.RoundCorners(Handle);
    }
}

public class ParticleCanvas : Panel
{
    class P { public float X, Y, VX, VY, R, A, Z; public int[] G; }
    P[] ps = new P[0];
    Random rnd = new Random();
    Timer timer;
    float phase = 0f;
    int tick = 0;
    Bitmap img, cache, bg, vig;
    bool cacheDirty = true, bgDirty = true;
    readonly Dictionary<string, Bitmap> sprites = new Dictionary<string, Bitmap>();
    Bitmap[] glyphs;
    Color glyphColor;
    Font titleFont = new Font("Segoe UI Semibold", 20f), subFont = new Font("Segoe UI", 9.5f);
    const string CodeChars = "0123456789ABCDEFXZ$#%&*+=<>";

    public static readonly string[] Styles = new string[] {
        "Network", "Starfield", "Nebula", "Aurora", "Waves", "Synthwave", "Hex Grid",
        "Code Rain", "Fireflies", "Embers", "Snow", "Bubbles", "Rain" };

    public bool Animate = true;
    public string Style = "Network";
    public int Count = 36;
    public float Speed = 1.15f;
    public float Dim = 0.55f;
    public float Glow = 1f;
    public bool Vignette = true;
    public bool Border = false;
    public string PageTitle = "";
    public string PageSubtitle = "";
    public int TitleX = 214, TitleY = 14;
    public Color C1A = Color.FromArgb(16, 14, 38), C1B = Color.FromArgb(30, 16, 62);
    public Color C2A = Color.FromArgb(8, 26, 50), C2B = Color.FromArgb(12, 10, 34);
    public Color Orb1 = Color.FromArgb(124, 92, 255), Orb2 = Color.FromArgb(40, 200, 255);
    public Color Dot = Color.FromArgb(190, 175, 255);
    public Color Accent = Color.FromArgb(124, 92, 255), Accent2 = Color.FromArgb(90, 215, 255);

    public ParticleCanvas()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        Rebuild();
        timer = new Timer();
        timer.Interval = 40;
        timer.Tick += OnTick;
        timer.Start();
    }

    public bool HasImage { get { return img != null; } }

    public void SetImage(string path)
    {
        Bitmap nb;
        using (Image tmp = Image.FromFile(path)) nb = new Bitmap(tmp);
        if (img != null) img.Dispose();
        img = nb; cacheDirty = true; bgDirty = true; Invalidate();
    }
    public void ClearImage()
    {
        if (img != null) { img.Dispose(); img = null; }
        if (cache != null) { cache.Dispose(); cache = null; }
        bgDirty = true; Invalidate();
    }
    // Call after changing colours, Glow, Vignette or Dim
    public void MarkDirty()
    {
        cacheDirty = true; bgDirty = true;
        foreach (Bitmap b in sprites.Values) b.Dispose();
        sprites.Clear();
        if (vig != null) { vig.Dispose(); vig = null; }
        Invalidate();
    }

    public void Rebuild()
    {
        int n = Math.Max(0, Count);
        if (Style == "Aurora" || Style == "Waves" || Style == "Hex Grid") n = 0;
        else if (Style == "Code Rain") n = Math.Max(8, n / 2);
        else if (Style == "Synthwave") n = n / 2;
        else if (Style == "Nebula") n = n * 2;
        ps = new P[n];
        for (int i = 0; i < n; i++) ps[i] = Spawn(true);
        bgDirty = true; Invalidate();
    }

    float Rf() { return (float)rnd.NextDouble(); }

    P Spawn(bool anywhere)
    {
        int w = Width > 0 ? Width : 880, h = Height > 0 ? Height : 640;
        P p = new P();
        p.A = Rf() * 6.2832f;
        p.X = rnd.Next(0, w); p.Y = rnd.Next(0, h);
        switch (Style)
        {
            case "Starfield":
                p.Z = Rf() * (float)Math.Sqrt(w * w + h * h) / 2f;
                break;
            case "Bubbles":
                p.VY = -(0.3f + Rf() * 0.9f); p.R = 3f + Rf() * 12f;
                break;
            case "Rain":
                p.VY = 2f + Rf() * 4f; p.R = 12f + Rf() * 34f;
                break;
            case "Snow":
                p.R = 0.8f + Rf() * 2.6f; p.VY = 0.25f + p.R * 0.3f; p.Z = 0.5f + Rf();
                break;
            case "Embers":
                p.VX = (Rf() - 0.5f) * 0.4f; p.VY = -(0.4f + Rf() * 1.1f); p.R = 0.8f + Rf() * 2.2f;
                if (!anywhere) p.Y = h + rnd.Next(0, 40);
                break;
            case "Fireflies":
                p.VX = (Rf() - 0.5f) * 0.6f; p.VY = (Rf() - 0.5f) * 0.6f; p.R = 1.5f + Rf() * 1.8f;
                break;
            case "Code Rain":
                p.X = (float)(Math.Floor(Rf() * (w / 14f)) * 14);
                p.Y = anywhere ? rnd.Next(-h, h) : -rnd.Next(20, 300);
                p.VY = 1.2f + Rf() * 2.6f; p.R = 8 + rnd.Next(0, 14);
                p.G = new int[(int)p.R];
                for (int i = 0; i < p.G.Length; i++) p.G[i] = rnd.Next(CodeChars.Length);
                break;
            case "Synthwave":
                p.Y = rnd.Next(0, (int)(h * 0.5f)); p.R = 0.6f + Rf() * 1.4f;
                break;
            case "Nebula":
                p.R = 0.5f + Rf() * 1.5f;
                break;
            default:
                p.VX = (Rf() - 0.5f) * 0.8f; p.VY = (Rf() - 0.5f) * 0.8f; p.R = 1.5f + Rf() * 2f;
                break;
        }
        return p;
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        Form f = FindForm();
        if (e.Button == MouseButtons.Left && f != null && f.FormBorderStyle == FormBorderStyle.None) NativeUi.DragMove(f.Handle);
    }

    void OnTick(object s, EventArgs e)
    {
        // Only animate while this window is the active one (saves CPU while you game)
        Form f = FindForm();
        if (!Animate || f == null || !Visible || f.WindowState == FormWindowState.Minimized || Form.ActiveForm != f) return;
        int w = Width, h = Height;
        float sp = Speed;
        double maxD = Math.Sqrt(w * w + h * h) / 2.0;
        foreach (P p in ps)
        {
            switch (Style)
            {
                case "Starfield":
                    p.Z += (0.6f + p.Z * 0.012f) * sp;
                    if (p.Z > maxD) { p.Z = 2f + Rf() * 20f; p.A = Rf() * 6.2832f; }
                    break;
                case "Bubbles":
                    p.Y += p.VY * sp;
                    p.X += (float)Math.Sin(p.Y * 0.02 + p.A) * 0.3f * sp;
                    if (p.Y < -p.R * 2) { p.Y = h + p.R * 2; p.X = rnd.Next(0, w); }
                    break;
                case "Rain":
                    p.Y += p.VY * sp;
                    if (p.Y - p.R > h) { p.Y = -p.R; p.X = rnd.Next(0, w); }
                    break;
                case "Snow":
                    p.Y += p.VY * sp;
                    p.X += (float)Math.Sin(phase * 40 * p.Z + p.A) * 0.45f * sp;
                    if (p.Y > h + 4) { p.Y = -4; p.X = rnd.Next(0, w); }
                    break;
                case "Embers":
                    p.VX += (Rf() - 0.5f) * 0.05f; p.VX = Math.Max(-0.6f, Math.Min(0.6f, p.VX));
                    p.X += (p.VX + (float)Math.Sin(p.Y * 0.015 + p.A) * 0.35f) * sp; p.Y += p.VY * sp; p.A += 0.09f * sp;
                    if (p.Y < -10) { p.Y = h + rnd.Next(0, 30); p.X = rnd.Next(0, w); }
                    break;
                case "Fireflies":
                    p.VX += (Rf() - 0.5f) * 0.08f; p.VY += (Rf() - 0.5f) * 0.08f;
                    p.VX = Math.Max(-0.7f, Math.Min(0.7f, p.VX)); p.VY = Math.Max(-0.7f, Math.Min(0.7f, p.VY));
                    p.X += p.VX * sp; p.Y += p.VY * sp; p.A += 0.05f * sp;
                    if (p.X < -10) p.X = w + 10; if (p.X > w + 10) p.X = -10;
                    if (p.Y < -10) p.Y = h + 10; if (p.Y > h + 10) p.Y = -10;
                    break;
                case "Code Rain":
                    p.Y += p.VY * sp;
                    if (rnd.Next(12) == 0) p.G[rnd.Next(p.G.Length)] = rnd.Next(CodeChars.Length);
                    if (p.Y - p.G.Length * 16 > h) { P n = Spawn(false); p.X = n.X; p.Y = n.Y; p.VY = n.VY; }
                    break;
                case "Synthwave":
                case "Nebula":
                    p.A += 0.04f * sp;
                    break;
                default:
                    p.X += p.VX * sp; p.Y += p.VY * sp;
                    if (p.X < 0) p.X = w; if (p.X > w) p.X = 0;
                    if (p.Y < 0) p.Y = h; if (p.Y > h) p.Y = 0;
                    break;
            }
        }
        phase += 0.0025f * sp;
        while (phase > 1f) phase -= 1f;
        tick++;
        if ((tick & 1) == 0) bgDirty = true;
        InvalidateExposed();
        if (tick % 45 == 0)
            foreach (Control c in Controls)
            {
                Card cd = c as Card;
                if (cd != null && cd.Visible && cd.Glass) cd.Invalidate(true);
            }
    }

    // Repaint only the parts of the background that no card is covering
    void InvalidateExposed()
    {
        using (Region r = new Region(ClientRectangle))
        {
            foreach (Control c in Controls)
            {
                if (!c.Visible || c.BackColor.A < 255) continue;
                if (c.Region != null)
                {
                    using (Region cr = c.Region.Clone()) { cr.Translate(c.Left, c.Top); r.Exclude(cr); }
                }
                else r.Exclude(c.Bounds);
            }
            Invalidate(r);
        }
    }

    static Color Lerp(Color a, Color b, float t)
    {
        return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }
    static Color Alpha(Color c, int a) { return Color.FromArgb(Math.Max(0, Math.Min(255, a)), c.R, c.G, c.B); }

    Bitmap OrbSprite(Color c, int alpha, int r)
    {
        alpha = Math.Max(0, Math.Min(255, alpha));
        string key = c.ToArgb() + "_" + alpha + "_" + r;
        Bitmap b;
        if (sprites.TryGetValue(key, out b)) return b;
        b = new Bitmap(r * 2, r * 2, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(b))
        using (GraphicsPath path = new GraphicsPath())
        {
            path.AddEllipse(0, 0, r * 2, r * 2);
            using (PathGradientBrush pb = new PathGradientBrush(path))
            {
                pb.CenterColor = Alpha(c, alpha);
                pb.SurroundColors = new Color[] { Color.FromArgb(0, c) };
                pb.FocusScales = new PointF(0.08f, 0.08f);
                g.FillPath(pb, path);
            }
        }
        sprites[key] = b;
        return b;
    }
    void DrawOrb(Graphics g, float cx, float cy, int r, Color c, int alpha)
    {
        alpha = (int)(alpha * Glow);
        if (alpha <= 0) return;
        g.DrawImage(OrbSprite(c, alpha, r), new Rectangle((int)(cx - r), (int)(cy - r), r * 2, r * 2));
    }

    void EnsureCache()
    {
        if (img == null) return;
        if (cache != null && !cacheDirty && cache.Size == ClientSize) return;
        if (cache != null) cache.Dispose();
        cache = new Bitmap(Math.Max(1, ClientSize.Width), Math.Max(1, ClientSize.Height), System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
        using (Graphics cg = Graphics.FromImage(cache))
        {
            cg.InterpolationMode = InterpolationMode.HighQualityBicubic;
            float s = Math.Max((float)cache.Width / img.Width, (float)cache.Height / img.Height);
            float w = img.Width * s, h = img.Height * s;
            cg.DrawImage(img, (cache.Width - w) / 2f, (cache.Height - h) / 2f, w, h);
            using (SolidBrush b = new SolidBrush(Color.FromArgb((int)(Math.Max(0f, Math.Min(1f, Dim)) * 255), 8, 8, 14)))
                cg.FillRectangle(b, 0, 0, cache.Width, cache.Height);
        }
        cacheDirty = false;
    }

    void EnsureVignette()
    {
        if (vig != null && vig.Size == ClientSize) return;
        if (vig != null) vig.Dispose();
        int w = Math.Max(1, Width), h = Math.Max(1, Height);
        vig = new Bitmap(w, h, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
        using (Graphics g = Graphics.FromImage(vig))
        using (GraphicsPath path = new GraphicsPath())
        {
            path.AddEllipse(-w * 0.35f, -h * 0.4f, w * 1.7f, h * 1.8f);
            using (PathGradientBrush pb = new PathGradientBrush(path))
            {
                pb.CenterColor = Color.FromArgb(0, 0, 0, 0);
                pb.SurroundColors = new Color[] { Color.FromArgb(235, 0, 0, 0) };
                Blend bl = new Blend();
                bl.Positions = new float[] { 0f, 0.35f, 1f };
                bl.Factors = new float[] { 0f, 0.55f, 1f };
                pb.Blend = bl;
                g.Clear(Color.FromArgb(235, 0, 0, 0));
                g.CompositingMode = CompositingMode.SourceCopy;
                g.FillPath(pb, path);
            }
        }
    }

    // Gradient, light orbs, static decoration and vignette are baked into one bitmap every other frame
    void RenderBg()
    {
        int w = Math.Max(1, Width), h = Math.Max(1, Height);
        if (bg == null || bg.Width != w || bg.Height != h)
        {
            if (bg != null) bg.Dispose();
            bg = new Bitmap(w, h, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
        }
        using (Graphics g = Graphics.FromImage(bg))
        {
            g.CompositingQuality = CompositingQuality.HighSpeed;
            g.InterpolationMode = InterpolationMode.NearestNeighbor;
            float a = (float)(0.5 + 0.5 * Math.Sin(phase * 2 * Math.PI));
            bool hasImg = img != null;
            if (hasImg) { EnsureCache(); g.DrawImage(cache, new Rectangle(0, 0, w, h)); }
            else
            {
                using (LinearGradientBrush br = new LinearGradientBrush(new Rectangle(0, 0, w, h), Lerp(C1A, C1B, a), Lerp(C2A, C2B, a), 40f + 50f * a))
                    g.FillRectangle(br, 0, 0, w, h);
            }
            double ang = phase * 2 * Math.PI;
            int o1 = hasImg ? 40 : 80, o2 = hasImg ? 26 : 55;
            DrawOrb(g, w * (0.25f + 0.15f * (float)Math.Sin(ang)), h * 0.12f, 300, Orb1, o1);
            DrawOrb(g, w * (0.85f - 0.12f * (float)Math.Cos(ang)), h * (0.70f + 0.08f * (float)Math.Sin(ang)), 320, Orb2, o2);
            if (Style == "Nebula")
            {
                DrawOrb(g, w * (0.55f + 0.2f * (float)Math.Cos(ang * 2)), h * (0.45f + 0.1f * (float)Math.Sin(ang * 3)), 260, Accent, o1);
                DrawOrb(g, w * (0.15f + 0.1f * (float)Math.Sin(ang * 2)), h * 0.85f, 220, Accent2, o2);
                DrawOrb(g, w * 0.7f, h * (0.15f + 0.1f * (float)Math.Cos(ang)), 200, Dot, o2 / 2);
            }
            else if (Style == "Synthwave") DrawSun(g, w, h);
            else if (Style == "Hex Grid") DrawHex(g, w, h);
            if (Vignette) { EnsureVignette(); g.DrawImage(vig, new Rectangle(0, 0, w, h)); }
        }
        bgDirty = false;
    }

    protected override void OnPaintBackground(PaintEventArgs e) { }

    public void PaintUnder(Graphics g, Rectangle src)
    {
        if (Width < 2 || Height < 2) return;
        if (bg == null || bg.Width != Width || bg.Height != Height) RenderBg();
        g.DrawImage(bg, new Rectangle(0, 0, src.Width, src.Height), src, GraphicsUnit.Pixel);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        if (Width < 2 || Height < 2) return;
        if (bgDirty || bg == null || bg.Width != Width || bg.Height != Height) RenderBg();
        g.CompositingQuality = CompositingQuality.HighSpeed;
        g.InterpolationMode = InterpolationMode.NearestNeighbor;
        g.DrawImage(bg, new Rectangle(0, 0, Width, Height));
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        switch (Style)
        {
            case "Starfield": DrawStars(g); break;
            case "Bubbles": DrawBubbles(g); break;
            case "Rain": DrawRain(g); break;
            case "Aurora": DrawAurora(g); break;
            case "Waves": DrawWaves(g); break;
            case "Snow": DrawSnow(g); break;
            case "Fireflies": DrawFireflies(g); break;
            case "Embers": DrawEmbers(g); break;
            case "Code Rain": DrawCode(g); break;
            case "Synthwave": DrawTwinkle(g); DrawGrid(g); break;
            case "Nebula": DrawTwinkle(g); break;
            case "Hex Grid": break;
            default: DrawNetwork(g); break;
        }

        if (PageTitle.Length > 0)
        {
            SizeF sz = g.MeasureString(PageTitle, titleFont);
            using (LinearGradientBrush tb = new LinearGradientBrush(
                new RectangleF(TitleX, TitleY, sz.Width + 2, sz.Height + 2), Accent, Accent2, 0f))
                g.DrawString(PageTitle, titleFont, tb, TitleX, TitleY);
            using (SolidBrush mb = new SolidBrush(Color.FromArgb(175, 180, 205)))
                g.DrawString(PageSubtitle, subFont, mb, TitleX + 3, TitleY + 36);
        }
        if (Border)
        {
            g.SmoothingMode = SmoothingMode.None;
            using (Pen pen = new Pen(Alpha(Accent, 110), 1f)) g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
        }
        base.OnPaint(e);
    }

    void DrawNetwork(Graphics g)
    {
        using (Pen pen = new Pen(Color.White, 1f))
        {
            for (int i = 0; i < ps.Length; i++)
                for (int j = i + 1; j < ps.Length; j++)
                {
                    float dx = ps[i].X - ps[j].X;
                    if (dx > 130f || dx < -130f) continue;
                    float dy = ps[i].Y - ps[j].Y;
                    float d2 = dx * dx + dy * dy;
                    if (d2 < 130f * 130f)
                    {
                        float d = (float)Math.Sqrt(d2);
                        pen.Color = Alpha(Dot, (int)(80 * (1 - d / 130f)));
                        g.DrawLine(pen, ps[i].X, ps[i].Y, ps[j].X, ps[j].Y);
                    }
                }
        }
        using (SolidBrush halo = new SolidBrush(Alpha(Dot, 35)))
        using (SolidBrush sb = new SolidBrush(Alpha(Dot, 170)))
            foreach (P p in ps)
            {
                g.FillEllipse(halo, p.X - p.R * 2.2f, p.Y - p.R * 2.2f, p.R * 4.4f, p.R * 4.4f);
                g.FillEllipse(sb, p.X - p.R, p.Y - p.R, p.R * 2, p.R * 2);
            }
    }

    void DrawStars(Graphics g)
    {
        float cx = Width / 2f, cy = Height / 2f;
        float maxD = (float)(Math.Sqrt(Width * Width + Height * Height) / 2.0);
        using (Pen pen = new Pen(Dot, 1f))
        {
            foreach (P p in ps)
            {
                float t = p.Z / maxD;
                float ca = (float)Math.Cos(p.A), sa = (float)Math.Sin(p.A);
                float tail = (2f + t * 14f) * Speed;
                pen.Color = Alpha(Dot, (int)(Math.Min(1f, t * 2.2f) * 210));
                pen.Width = 1f + t * 1.6f;
                g.DrawLine(pen, cx + ca * (p.Z - tail), cy + sa * (p.Z - tail), cx + ca * p.Z, cy + sa * p.Z);
            }
        }
    }

    void DrawBubbles(Graphics g)
    {
        using (Pen pen = new Pen(Alpha(Dot, 95), 1.2f))
        using (SolidBrush sb = new SolidBrush(Alpha(Dot, 18)))
        using (SolidBrush shine = new SolidBrush(Alpha(Color.White, 70)))
            foreach (P p in ps)
            {
                g.FillEllipse(sb, p.X - p.R, p.Y - p.R, p.R * 2, p.R * 2);
                g.DrawEllipse(pen, p.X - p.R, p.Y - p.R, p.R * 2, p.R * 2);
                if (p.R > 6) g.FillEllipse(shine, p.X - p.R * 0.55f, p.Y - p.R * 0.6f, p.R * 0.4f, p.R * 0.4f);
            }
    }

    void DrawRain(Graphics g)
    {
        using (Pen pen = new Pen(Alpha(Dot, 110), 1.4f))
        using (SolidBrush sb = new SolidBrush(Alpha(Dot, 220)))
            foreach (P p in ps)
            {
                g.DrawLine(pen, p.X, p.Y - p.R, p.X, p.Y);
                g.FillEllipse(sb, p.X - 1.5f, p.Y - 1.5f, 3f, 3f);
            }
    }

    void DrawSnow(Graphics g)
    {
        using (SolidBrush sb = new SolidBrush(Color.White))
            foreach (P p in ps)
            {
                sb.Color = Color.FromArgb((int)(70 + p.R * 50), 235, 240, 255);
                g.FillEllipse(sb, p.X - p.R, p.Y - p.R, p.R * 2, p.R * 2);
            }
    }

    void DrawEmbers(Graphics g)
    {
        float h = Math.Max(1, Height);
        Color hot = UiTheme.Mix(Color.White, Accent, 0.35f);
        using (SolidBrush outer = new SolidBrush(Color.White))
        using (SolidBrush inner = new SolidBrush(Color.White))
            foreach (P p in ps)
            {
                float life = Math.Max(0f, Math.Min(1f, p.Y / h));
                float flick = 0.65f + 0.35f * (float)Math.Sin(p.A * 3f);
                outer.Color = Alpha(p.R > 2f ? Orb2 : Accent, (int)((14 + 46 * life) * flick));
                float r2 = p.R * 4f;
                g.FillEllipse(outer, p.X - r2, p.Y - r2, r2 * 2, r2 * 2);
                inner.Color = Alpha(hot, (int)((60 + 190 * life) * flick));
                g.FillEllipse(inner, p.X - p.R, p.Y - p.R, p.R * 2, p.R * 2);
            }
    }

    void DrawFireflies(Graphics g)
    {
        using (SolidBrush outer = new SolidBrush(Color.White))
        using (SolidBrush inner = new SolidBrush(Color.White))
            foreach (P p in ps)
            {
                float pulse = 0.5f + 0.5f * (float)Math.Sin(p.A);
                Color c = (p.R > 2.4f) ? Accent2 : Dot;
                outer.Color = Alpha(c, (int)(18 + 40 * pulse));
                float r2 = p.R * 4.5f;
                g.FillEllipse(outer, p.X - r2, p.Y - r2, r2 * 2, r2 * 2);
                inner.Color = Alpha(Color.White, (int)(110 + 140 * pulse));
                g.FillEllipse(inner, p.X - p.R, p.Y - p.R, p.R * 2, p.R * 2);
            }
    }

    void EnsureGlyphs()
    {
        if (glyphs != null && glyphColor == Dot) return;
        if (glyphs != null) foreach (Bitmap b in glyphs) b.Dispose();
        glyphColor = Dot;
        glyphs = new Bitmap[CodeChars.Length * 4];
        using (Font f = new Font("Consolas", 11f, FontStyle.Bold))
            for (int i = 0; i < CodeChars.Length; i++)
                for (int lv = 0; lv < 4; lv++)
                {
                    Bitmap b = new Bitmap(14, 16, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
                    using (Graphics g = Graphics.FromImage(b))
                    {
                        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
                        Color c = lv == 0 ? Color.FromArgb(240, 245, 255, 245) : Alpha(Dot, 220 - lv * 50);
                        using (SolidBrush sb = new SolidBrush(c)) g.DrawString(CodeChars[i].ToString(), f, sb, -2, -1);
                    }
                    glyphs[i * 4 + lv] = b;
                }
    }

    void DrawCode(Graphics g)
    {
        EnsureGlyphs();
        foreach (P p in ps)
        {
            int n = p.G.Length;
            for (int k = 0; k < n; k++)
            {
                float y = p.Y - k * 16;
                if (y < -16 || y > Height) continue;
                int lv = k == 0 ? 0 : Math.Min(3, 1 + (k * 3) / n);
                g.DrawImageUnscaledAndClipped(glyphs[p.G[k] * 4 + lv], new Rectangle((int)p.X, (int)y, 14, 16));
            }
        }
    }

    void DrawTwinkle(Graphics g)
    {
        using (SolidBrush sb = new SolidBrush(Color.White))
            foreach (P p in ps)
            {
                float tw = 0.5f + 0.5f * (float)Math.Sin(p.A);
                sb.Color = Alpha(Dot, (int)(60 + 180 * tw));
                float r = p.R * (0.7f + 0.5f * tw);
                g.FillEllipse(sb, p.X - r, p.Y - r, r * 2, r * 2);
            }
    }

    void DrawSun(Graphics g, int w, int h)
    {
        float hy = h * 0.58f, r = h * 0.2f, cx = w * 0.6f, cy = hy - r * 0.55f;
        DrawOrb(g, cx, cy, (int)(r * 2.2f), Accent2, 70);
        using (GraphicsPath sun = new GraphicsPath())
        {
            sun.AddEllipse(cx - r, cy - r, r * 2, r * 2);
            Region old = g.Clip;
            g.SetClip(new RectangleF(0, 0, w, hy));
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush lb = new LinearGradientBrush(new RectangleF(cx - r, cy - r - 1, r * 2, r * 2 + 2), Alpha(Accent2, 220), Alpha(Accent, 200), 90f))
                g.FillPath(lb, sun);
            using (SolidBrush cut = new SolidBrush(Lerp(C2A, C2B, 0.5f)))
                for (int i = 0; i < 6; i++)
                {
                    float y = cy + r * 0.1f + i * r * 0.16f, th = 1.5f + i * 1.6f;
                    g.FillRectangle(cut, cx - r, y, r * 2, th);
                }
            g.Clip = old;
        }
        using (LinearGradientBrush floor = new LinearGradientBrush(new RectangleF(0, hy - 1, w, h - hy + 2), Color.FromArgb(150, 5, 4, 14), Color.FromArgb(40, 5, 4, 14), 90f))
            g.FillRectangle(floor, 0, hy, w, h - hy);
    }

    void DrawGrid(Graphics g)
    {
        float hy = Height * 0.58f, cx = Width * 0.6f;
        using (Pen pen = new Pen(Alpha(Accent, 150), 1.2f))
        {
            for (int i = -14; i <= 14; i++)
            {
                pen.Color = Alpha(Accent, 140 - Math.Abs(i) * 5);
                g.DrawLine(pen, cx + i * 14, hy, cx + i * 130, Height);
            }
            float off = (phase * 40f) % 1f;
            for (int i = 0; i < 14; i++)
            {
                float t = (i + off) / 14f;
                float y = hy + (Height - hy) * t * t;
                pen.Color = Alpha(Accent2, (int)(30 + 170 * t));
                g.DrawLine(pen, 0, y, Width, y);
            }
            pen.Color = Alpha(Accent2, 220); pen.Width = 2f;
            g.DrawLine(pen, 0, hy, Width, hy);
        }
    }

    void DrawHex(Graphics g, int w, int h)
    {
        float s = 26f, hw = s * 1.732f;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        float px = w * (0.5f + 0.4f * (float)Math.Sin(phase * 6.2832)), py = h * (0.5f + 0.35f * (float)Math.Sin(phase * 12.566));
        PointF[] pts = new PointF[6];
        using (Pen pen = new Pen(Alpha(Dot, 26), 1f))
        using (SolidBrush fill = new SolidBrush(Color.White))
            for (int row = -1; row * s * 1.5f < h + s; row++)
                for (int col = -1; col * hw < w + hw; col++)
                {
                    float cx = col * hw + ((row & 1) == 1 ? hw / 2 : 0), cy = row * s * 1.5f;
                    for (int k = 0; k < 6; k++)
                    {
                        double an = Math.PI / 180 * (60 * k - 30);
                        pts[k] = new PointF(cx + (s - 2) * (float)Math.Cos(an), cy + (s - 2) * (float)Math.Sin(an));
                    }
                    float d = (float)Math.Sqrt((cx - px) * (cx - px) + (cy - py) * (cy - py));
                    if (d < 190f)
                    {
                        fill.Color = Alpha(Accent, (int)(70 * (1 - d / 190f)));
                        g.FillPolygon(fill, pts);
                    }
                    g.DrawPolygon(pen, pts);
                }
    }

    void DrawAurora(Graphics g)
    {
        int w = Width, h = Height, steps = 36;
        for (int b = 0; b < 3; b++)
        {
            PointF[] pts = new PointF[(steps + 1) * 2];
            for (int i = 0; i <= steps; i++)
            {
                float x = w * (float)i / steps;
                float y = h * (0.28f + 0.17f * b)
                    + (float)Math.Sin(i * 0.35 + phase * 6.283 * (1 + b) + b * 2) * 38f
                    + (float)Math.Sin(i * 0.12 - phase * 6.283) * 26f;
                pts[i] = new PointF(x, y);
            }
            for (int i = 0; i <= steps; i++)
                pts[steps + 1 + i] = new PointF(w * (float)(steps - i) / steps, pts[steps - i].Y + 95f + 20f * b);
            Color c = (b == 0) ? Accent : ((b == 1) ? Accent2 : Orb2);
            using (SolidBrush sb = new SolidBrush(Alpha(c, 42))) g.FillPolygon(sb, pts);
            using (Pen edge = new Pen(Alpha(c, 90), 1.5f)) g.DrawCurve(edge, pts, 0, steps, 0.5f);
        }
    }

    void DrawWaves(Graphics g)
    {
        int w = Width, h = Height, steps = 48;
        Color[] cols = new Color[] { Accent, Accent2, Dot, Orb2, Accent };
        using (Pen pen = new Pen(Color.White, 2f))
            for (int b = 0; b < 5; b++)
            {
                PointF[] pts = new PointF[steps + 1];
                for (int i = 0; i <= steps; i++)
                {
                    float x = w * (float)i / steps;
                    double t = phase * 6.2832 * (1 + b * 0.35);
                    float y = h * (0.42f + 0.07f * b) + (float)(Math.Sin(i * 0.22 + t + b) * (30 + b * 8) + Math.Sin(i * 0.07 - t * 0.6) * 22);
                    pts[i] = new PointF(x, y);
                }
                pen.Color = Alpha(cols[b], 120 - b * 15); pen.Width = 2.2f - b * 0.25f;
                g.DrawCurve(pen, pts, 0.5f);
            }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            if (timer != null) { timer.Stop(); timer.Dispose(); }
            if (img != null) img.Dispose();
            if (cache != null) cache.Dispose();
            if (bg != null) bg.Dispose();
            if (vig != null) vig.Dispose();
            foreach (Bitmap b in sprites.Values) b.Dispose();
            if (glyphs != null) foreach (Bitmap b in glyphs) b.Dispose();
            titleFont.Dispose(); subFont.Dispose();
        }
        base.Dispose(disposing);
    }
}

public static class NativeUi
{
    [DllImport("dwmapi.dll")]
    static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);
    [DllImport("user32.dll")]
    static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    public static int ForegroundPid() { uint pid; GetWindowThreadProcessId(GetForegroundWindow(), out pid); return (int)pid; }
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, string lp);

    public static void DarkTitle(IntPtr h)
    {
        try
        {
            int v = 1;
            DwmSetWindowAttribute(h, 20, ref v, 4);
            DwmSetWindowAttribute(h, 19, ref v, 4);
        }
        catch (Exception) { }
    }
    public static void CaptionColor(IntPtr h, int r, int g, int b)
    {
        try
        {
            int c = r | (g << 8) | (b << 16);
            DwmSetWindowAttribute(h, 35, ref c, 4);
        }
        catch (Exception) { }
    }
    [DllImport("user32.dll")]
    static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, IntPtr lp);
    [DllImport("user32.dll")]
    static extern bool ReleaseCapture();

    public static void RoundCorners(IntPtr h)
    {
        try { int v = 2; DwmSetWindowAttribute(h, 33, ref v, 4); }
        catch (Exception) { }
    }
    public static void DragMove(IntPtr h)
    {
        ReleaseCapture();
        SendMessage(h, 0xA1, new IntPtr(2), IntPtr.Zero);
    }
    // Stops a control drawing while lots of children change, then repaints once
    public static void Redraw(Control c, bool on)
    {
        if (!c.IsHandleCreated) return;
        SendMessage(c.Handle, 0x000B, new IntPtr(on ? 1 : 0), IntPtr.Zero);
        if (on) c.Invalidate(true);
    }
    public static void Cue(IntPtr h, string text)
    {
        try { SendMessage(h, 0x1501, new IntPtr(1), text); }
        catch (Exception) { }
    }
}

public class TweakList : Control
{
    class Item
    {
        public string Id, Cat, Name, Desc;
        public int Plan;
        public bool Rec, Checked, Applied;
    }

    List<Item> all = new List<Item>();
    List<Item> view = new List<Item>();
    const int RowH = 56;
    int scroll = 0, hover = -1, dragDY = 0;
    bool dragging = false;
    Font fName = new Font("Segoe UI Semibold", 10f);
    Font fDesc = new Font("Segoe UI", 8.5f);
    Font fBadge = new Font("Segoe UI Semibold", 7.5f);

    public int UserPlan = 0;
    public string Category = "all", Search = "", PlanFilter = "all", LastId = "";
    public Color Accent = Color.FromArgb(124, 92, 255);
    public Color CardBg = Color.FromArgb(28, 30, 44);
    public Color RowHi = Color.FromArgb(38, 41, 60);
    public Dictionary<string, bool> IdSet;
    public Color TextCol = Color.FromArgb(232, 234, 244);
    public Color MutedCol = Color.FromArgb(150, 155, 180);
    public event EventHandler CheckChanged;
    public event EventHandler LockedClicked;

    static Color[] PlanCol = new Color[] { Color.FromArgb(80, 210, 140), Color.FromArgb(255, 190, 55), Color.FromArgb(230, 70, 80) };
    static string[] PlanTxt = new string[] { "FREE", "PREMIUM", "ULTIMATE" };

    public TweakList()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
    }

    // ---------- data ----------
    public void Clear() { all.Clear(); view.Clear(); scroll = 0; hover = -1; Invalidate(); }

    public void Add(string id, string cat, string name, string desc, int plan, bool rec)
    {
        Item it = new Item();
        it.Id = id; it.Cat = cat; it.Name = name; it.Desc = desc; it.Plan = plan; it.Rec = rec;
        all.Add(it);
    }

    public void Refilter()
    {
        view.Clear();
        string s = (Search == null ? "" : Search).Trim().ToLowerInvariant();
        foreach (Item it in all)
        {
            if (Category == "lat") { if (IdSet == null || !IdSet.ContainsKey(it.Id)) continue; }
            else if (Category != "all" && it.Cat != Category) continue;
            if (PlanFilter == "free" && it.Plan != 0) continue;
            if (PlanFilter == "premium" && it.Plan != 1) continue;
            if (PlanFilter == "ultimate" && it.Plan != 2) continue;
            if (s.Length > 0 && it.Name.ToLowerInvariant().IndexOf(s) < 0 && it.Desc.ToLowerInvariant().IndexOf(s) < 0) continue;
            view.Add(it);
        }
        scroll = 0; hover = -1; Invalidate();
    }

    public int VisibleCount { get { return view.Count; } }
    public int TotalCount { get { return all.Count; } }
    public int CheckedCount { get { int n = 0; foreach (Item it in all) if (it.Checked) n++; return n; } }
    public int AppliedCount { get { int n = 0; foreach (Item it in all) if (it.Applied) n++; return n; } }
    public int PlanCount(int plan) { int n = 0; foreach (Item it in all) if (it.Plan == plan) n++; return n; }
    public int UnlockedCount { get { int n = 0; foreach (Item it in all) if (it.Plan <= UserPlan) n++; return n; } }

    public string[] CheckedIds()
    {
        List<string> r = new List<string>();
        foreach (Item it in all) if (it.Checked && it.Plan <= UserPlan) r.Add(it.Id);
        return r.ToArray();
    }
    public string NameOf(string id) { foreach (Item it in all) if (it.Id == id) return it.Name; return id; }
    public int PlanOf(string id) { foreach (Item it in all) if (it.Id == id) return it.Plan; return 0; }

    public void SetApplied(string id, bool v)
    {
        foreach (Item it in all) if (it.Id == id) it.Applied = v;
        Invalidate();
    }
    public void SetUserPlan(int p)
    {
        UserPlan = p;
        foreach (Item it in all) if (it.Plan > p) it.Checked = false;
        Invalidate();
        if (CheckChanged != null) CheckChanged(this, EventArgs.Empty);
    }
    public void SelectVisible(string mode)
    {
        foreach (Item it in view)
        {
            if (it.Plan > UserPlan) continue;
            if (mode == "all") it.Checked = true;
            else if (mode == "none") it.Checked = false;
            else if (mode == "rec") it.Checked = it.Rec;
        }
        Invalidate();
        if (CheckChanged != null) CheckChanged(this, EventArgs.Empty);
    }
    public void SelectRecommendedEverywhere()
    {
        foreach (Item it in all) it.Checked = (it.Rec && it.Plan <= UserPlan);
        Invalidate();
        if (CheckChanged != null) CheckChanged(this, EventArgs.Empty);
    }

    // ---------- geometry ----------
    int Total { get { return view.Count * RowH; } }
    int MaxScroll { get { return Math.Max(0, Total - Height); } }
    void ClampScroll() { if (scroll > MaxScroll) scroll = MaxScroll; if (scroll < 0) scroll = 0; }

    Rectangle ThumbRect()
    {
        int track = Height - 8;
        int th = Math.Max(36, (int)((long)track * Height / Math.Max(1, Total)));
        int ty = 4 + (MaxScroll == 0 ? 0 : (int)((long)(track - th) * scroll / MaxScroll));
        return new Rectangle(Width - 10, ty, 6, th);
    }

    static GraphicsPath RR(Rectangle r, int rad)
    {
        int d = rad * 2;
        GraphicsPath p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }

    // ---------- painting ----------
    void DrawCheck(Graphics g, Rectangle cb, Item it, bool locked)
    {
        using (GraphicsPath p = RR(cb, 6))
        {
            if (locked)
            {
                using (SolidBrush fb = new SolidBrush(Color.FromArgb(40, 255, 255, 255))) g.FillPath(fb, p);
                using (Pen lp = new Pen(MutedCol, 1.6f))
                {
                    g.DrawArc(lp, cb.X + 6, cb.Y + 3, 8, 8, 180, 180);
                    g.DrawLine(lp, cb.X + 6, cb.Y + 7, cb.X + 6, cb.Y + 9);
                    g.DrawLine(lp, cb.X + 14, cb.Y + 7, cb.X + 14, cb.Y + 9);
                }
                using (SolidBrush bb = new SolidBrush(MutedCol)) g.FillRectangle(bb, cb.X + 4, cb.Y + 9, 12, 8);
            }
            else if (it.Checked)
            {
                using (SolidBrush fb = new SolidBrush(Accent)) g.FillPath(fb, p);
                using (Pen cp = new Pen(Color.White, 2.2f))
                {
                    cp.StartCap = LineCap.Round; cp.EndCap = LineCap.Round; cp.LineJoin = LineJoin.Round;
                    g.DrawLines(cp, new Point[] { new Point(cb.X + 5, cb.Y + 10), new Point(cb.X + 9, cb.Y + 14), new Point(cb.X + 15, cb.Y + 6) });
                }
            }
            else
            {
                using (Pen op = new Pen(MutedCol, 1.5f)) g.DrawPath(op, p);
            }
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        UiTheme.PaintUnder(this, g);

        using (StringFormat cf = new StringFormat())
        using (StringFormat tf = new StringFormat())
        {
            cf.Alignment = StringAlignment.Center; cf.LineAlignment = StringAlignment.Center;
            tf.FormatFlags = StringFormatFlags.NoWrap; tf.Trimming = StringTrimming.EllipsisCharacter;

            if (view.Count == 0)
            {
                using (SolidBrush mb = new SolidBrush(MutedCol))
                    g.DrawString("No tweaks match your filters.", fName, mb, new RectangleF(0, 0, Width, Height), cf);
                return;
            }

            int first = Math.Max(0, scroll / RowH);
            int last = Math.Min(view.Count - 1, (scroll + Height) / RowH);
            bool bar = Total > Height;
            int rw = Width - (bar ? 20 : 8);

            for (int i = first; i <= last; i++)
            {
                Item it = view[i];
                int y = i * RowH - scroll;
                Rectangle r = new Rectangle(4, y + 2, rw, RowH - 4);
                bool locked = it.Plan > UserPlan;

                if (i == hover)
                    using (GraphicsPath hp = RR(r, 10))
                    using (SolidBrush hb = new SolidBrush(RowHi)) g.FillPath(hb, hp);

                Rectangle cb = new Rectangle(r.X + 12, r.Y + (r.Height - 20) / 2, 20, 20);
                DrawCheck(g, cb, it, locked);

                int bw = 70, bh = 20;
                Rectangle br = new Rectangle(r.Right - bw - 12, r.Y + 8, bw, bh);
                Color pc = PlanCol[it.Plan];
                using (GraphicsPath bp = RR(br, 10))
                {
                    using (SolidBrush bb = new SolidBrush(Color.FromArgb(40, pc))) g.FillPath(bb, bp);
                    using (Pen bpn = new Pen(Color.FromArgb(150, pc), 1f)) g.DrawPath(bpn, bp);
                }
                using (SolidBrush pb = new SolidBrush(pc))
                    g.DrawString(PlanTxt[it.Plan], fBadge, pb, br, cf);
                if (it.Applied)
                    using (SolidBrush ab = new SolidBrush(Color.FromArgb(90, 210, 150)))
                        g.DrawString("APPLIED", fBadge, ab, new RectangleF(br.X, br.Bottom + 4, bw, 14), cf);

                int tx = cb.Right + 14;
                int tw = br.X - tx - 12;
                Color nc = locked ? Color.FromArgb(125, TextCol) : TextCol;
                using (SolidBrush nb = new SolidBrush(nc))
                    g.DrawString(it.Name, fName, nb, new RectangleF(tx, r.Y + 7, tw, 20), tf);
                using (SolidBrush db = new SolidBrush(MutedCol))
                    g.DrawString(it.Desc, fDesc, db, new RectangleF(tx, r.Y + 29, tw, 16), tf);
            }

            if (bar)
            {
                using (SolidBrush trk = new SolidBrush(Color.FromArgb(30, 255, 255, 255)))
                    g.FillRectangle(trk, Width - 10, 4, 6, Height - 8);
                Rectangle t = ThumbRect();
                using (GraphicsPath tp = RR(t, 3))
                using (SolidBrush tb = new SolidBrush(Color.FromArgb(170, Accent))) g.FillPath(tb, tp);
            }
        }
    }

    // ---------- mouse ----------
    int RowAt(int x, int y)
    {
        if (x > Width - (Total > Height ? 18 : 4)) return -1;
        int i = (y + scroll) / RowH;
        return (i >= 0 && i < view.Count) ? i : -1;
    }

    protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); Focus(); }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (dragging)
        {
            Rectangle t = ThumbRect();
            int range = (Height - 8) - t.Height;
            if (range > 0) { scroll = (int)((long)(e.Y - dragDY - 4) * MaxScroll / range); ClampScroll(); }
            Invalidate();
            return;
        }
        int h = RowAt(e.X, e.Y);
        if (h != hover) { hover = h; Cursor = (h >= 0) ? Cursors.Hand : Cursors.Default; Invalidate(); }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left) return;
        if (Total > Height && e.X >= Width - 18)
        {
            Rectangle t = ThumbRect();
            if (t.Contains(e.X, e.Y)) { dragging = true; dragDY = e.Y - t.Y; }
            else { scroll += (e.Y < t.Y ? -Height : Height); ClampScroll(); Invalidate(); }
            return;
        }
        int i = RowAt(e.X, e.Y);
        if (i < 0) return;
        Item it = view[i];
        LastId = it.Id;
        if (it.Plan > UserPlan)
        {
            if (LockedClicked != null) LockedClicked(this, EventArgs.Empty);
            return;
        }
        it.Checked = !it.Checked;
        Invalidate();
        if (CheckChanged != null) CheckChanged(this, EventArgs.Empty);
    }

    protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); dragging = false; }

    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        if (hover != -1) { hover = -1; Invalidate(); }
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        base.OnMouseWheel(e);
        scroll -= Math.Sign(e.Delta) * RowH * 2;
        ClampScroll();
        Invalidate();
    }

    protected override void OnResize(EventArgs e) { base.OnResize(e); ClampScroll(); Invalidate(); }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { fName.Dispose(); fDesc.Dispose(); fBadge.Dispose(); }
        base.Dispose(disposing);
    }
}
'@

# ---------- Paths, settings, backup ----------
$dataDir      = Join-Path $env:APPDATA "TKLTweaks"
$oldDir       = Join-Path $env:APPDATA "FortniteTweaker"
$settingsFile = Join-Path $dataDir "settings.json"
$backupFile   = Join-Path $dataDir "backup.json"
$accountFile  = Join-Path $dataDir "account.json"
try {
    if (-not (Test-Path $dataDir)) {
        New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
        foreach ($f in "settings.json", "backup.json") {
            $src = Join-Path $oldDir $f
            if (Test-Path $src) { Copy-Item $src (Join-Path $dataDir $f) }
        }
    }
} catch { }

$guidRx   = '[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}'
$highPerf = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
$balanced = "381b4222-f694-41f0-9685-ff5bb260df2e"

$settings = @{ Theme = "Purple Haze"; Style = "Network"; Count = 36; Speed = 115; Dim = 50; Animate = $true; Image = ""; Vignette = $true; Glow = 115; Glass = 20; Custom = "" }
try {
    if (Test-Path $settingsFile) {
        $j = Get-Content $settingsFile -Raw | ConvertFrom-Json
        foreach ($k in @($settings.Keys)) { if ($j.PSObject.Properties[$k] -ne $null) { $settings[$k] = $j.$k } }
    }
} catch { }
function Save-Settings {
    try {
        New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
        ConvertTo-Json -InputObject $settings | Set-Content -Path $settingsFile -Encoding UTF8
    } catch { }
}

$script:backup = @{}
try {
    if (Test-Path $backupFile) {
        $bj = Get-Content $backupFile -Raw | ConvertFrom-Json
        foreach ($p in $bj.PSObject.Properties) { $script:backup[$p.Name] = $p.Value }
    }
} catch { }
function Save-Backup {
    try {
        New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
        ConvertTo-Json -InputObject $script:backup -Depth 6 | Set-Content -Path $backupFile -Encoding UTF8
    } catch { }
}

# ---------- Account + license ----------
$script:user = "Guest"
$script:acct = @{ User = ""; Salt = ""; Hash = ""; Key = ""; Auto = $false; ServerPlan = 0 }
try {
    if (Test-Path $accountFile) {
        $aj = Get-Content $accountFile -Raw | ConvertFrom-Json
        foreach ($k in @($script:acct.Keys)) { if ($aj.PSObject.Properties[$k] -ne $null) { $script:acct[$k] = $aj.$k } }
    }
} catch { }
function Save-Account {
    try {
        New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
        ConvertTo-Json -InputObject $script:acct | Set-Content -Path $accountFile -Encoding UTF8
    } catch { }
}
function New-PwHash($pw, $saltB64) {
    if ($saltB64) { $salt = [Convert]::FromBase64String($saltB64) }
    else {
        $salt = New-Object byte[] 16
        $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
        $rng.GetBytes($salt)
    }
    $kdf = New-Object Security.Cryptography.Rfc2898DeriveBytes($pw, $salt, 20000)
    return @{ Salt = [Convert]::ToBase64String($salt); Hash = [Convert]::ToBase64String($kdf.GetBytes(32)) }
}
function Get-Hwid {
    try {
        $g = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
        $h = [Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes("TKL|$g"))
        return ((($h | ForEach-Object { $_.ToString("X2") }) -join "").Substring(0, 16))
    } catch { return "UNKNOWN" }
}
function Invoke-Api($body) {
    if (-not $TKL.ApiUrl) { return $null }
    try {
        return Invoke-RestMethod -Uri $TKL.ApiUrl -Method Post -ContentType "application/json" `
            -Body (ConvertTo-Json -InputObject $body) -TimeoutSec 12 -ErrorAction Stop
    } catch { return $null }
}
function PlanFromName($n) {
    switch ("$n".ToLower()) { "premium" { return 1 } "ultimate" { return 2 } default { return 0 } }
}
function Get-KeySig($code, $r1, $r2) {
    $h = New-Object System.Security.Cryptography.HMACSHA256
    $h.Key = [Text.Encoding]::UTF8.GetBytes($TKL.LicenseSecret)
    $b = $h.ComputeHash([Text.Encoding]::UTF8.GetBytes("$code|$r1$r2"))
    return ((($b | ForEach-Object { $_.ToString("X2") }) -join "").Substring(0, 8))
}
function Test-LicenseKey($key) {
    $k = "$key".Trim().ToUpper()
    if ($k -match '^TKL-(PR|UL)-([A-Z0-9]{4})-([A-Z0-9]{4})-([0-9A-F]{8})$') {
        $code = $Matches[1]; $r1 = $Matches[2]; $r2 = $Matches[3]; $sig = $Matches[4]
        if ((Get-KeySig $code $r1 $r2) -eq $sig) { if ($code -eq "PR") { return 1 } else { return 2 } }
    }
    return -1
}
function Get-AccountPlan {
    # Guest always Free
    if (-not $script:user -or $script:user -eq "Guest") { return 0 }
    # Online server mode
    if ($TKL.ApiUrl) { return [int]$script:acct.ServerPlan }
    # Offline: plan comes only from a valid key generated by TKL-KeyGen
    $p = Test-LicenseKey $script:acct.Key
    if ($p -lt 0) { return 0 }
    return $p
}
function Invoke-Activate($key) {
    $key = "$key".Trim()
    if ($TKL.ApiUrl) {
        $r = Invoke-Api @{ action = "activate"; user = $script:user; key = $key; hwid = (Get-Hwid) }
        if ($r -and $r.ok) { return @{ Ok = $true; Plan = (PlanFromName $r.plan); Msg = "License activated." } }
        $m = "Activation failed."
        if (-not $r) { $m = "Could not reach the license server." } elseif ($r.message) { $m = [string]$r.message }
        return @{ Ok = $false; Plan = 0; Msg = $m }
    }
    $p = Test-LicenseKey $key
    if ($p -lt 0) { return @{ Ok = $false; Plan = 0; Msg = "That license key is not valid." } }
    return @{ Ok = $true; Plan = $p; Msg = "License activated." }
}
function Invoke-Login($user, $pw) {
    if ($TKL.ApiUrl) {
        $r = Invoke-Api @{ action = "login"; user = $user; pass = $pw; hwid = (Get-Hwid) }
        if ($r -and $r.ok) { $script:acct.ServerPlan = (PlanFromName $r.plan); return @{ Ok = $true; Msg = "" } }
        $m = "Sign in failed."
        if (-not $r) { $m = "Could not reach the server." } elseif ($r.message) { $m = [string]$r.message }
        return @{ Ok = $false; Msg = $m }
    }
    if (-not $script:acct.User -or $user -ne $script:acct.User) { return @{ Ok = $false; Msg = "Wrong username or password." } }
    $h = New-PwHash $pw $script:acct.Salt
    if ($h.Hash -ne $script:acct.Hash) { return @{ Ok = $false; Msg = "Wrong username or password." } }
    return @{ Ok = $true; Msg = "" }
}
function Invoke-Register($user, $pw) {
    if ($TKL.ApiUrl) {
        $r = Invoke-Api @{ action = "register"; user = $user; pass = $pw; hwid = (Get-Hwid) }
        if ($r -and $r.ok) { $script:acct.ServerPlan = (PlanFromName $r.plan); return @{ Ok = $true; Msg = "" } }
        $m = "Could not create the account."
        if (-not $r) { $m = "Could not reach the server." } elseif ($r.message) { $m = [string]$r.message }
        return @{ Ok = $false; Msg = $m }
    }
    $h = New-PwHash $pw ""
    $script:acct.User = $user; $script:acct.Salt = $h.Salt; $script:acct.Hash = $h.Hash
    $script:acct.Key = ""; $script:acct.ServerPlan = 0
    Save-Account
    return @{ Ok = $true; Msg = "" }
}

# ---------- Helpers ----------
function Rgb($a) { [System.Drawing.Color]::FromArgb($a[0], $a[1], $a[2]) }
function Set-Reg($path, $name, $value, $type = "DWord") {
    if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force | Out-Null }
    Set-ItemProperty -LiteralPath $path -Name $name -Value $value -Type $type
}
function Set-Rounded($c, $r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = $r * 2; $w = $c.Width; $h = $c.Height
    $p.AddArc(0, 0, $d, $d, 180, 90);            $p.AddArc($w - $d, 0, $d, $d, 270, 90)
    $p.AddArc($w - $d, $h - $d, $d, $d, 0, 90);  $p.AddArc(0, $h - $d, $d, $d, 90, 90)
    $p.CloseFigure()
    $c.Region = New-Object System.Drawing.Region($p)
}
function Log($msg) {
    $script:logBox.AppendText("[$(Get-Date -Format HH:mm:ss)] $msg`r`n")
    $script:statusLbl.Text = "$msg".Trim()
}
function Get-FortniteExe {
    $dat = Join-Path $env:ProgramData "Epic\UnrealEngineLauncher\LauncherInstalled.dat"
    try {
        if (Test-Path $dat) {
            $j = Get-Content $dat -Raw | ConvertFrom-Json
            $fn = $j.InstallationList | Where-Object { $_.AppName -eq "Fortnite" } | Select-Object -First 1
            if ($fn) {
                $exe = Join-Path $fn.InstallLocation "FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe"
                if (Test-Path $exe) { return $exe }
            }
        }
    } catch { }
    $def = "C:\Program Files\Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe"
    if (Test-Path $def) { return $def }
    return $null
}

# ---------- Registry tweak engine (saves YOUR original values) ----------
function Apply-RegList($id, $regs) {
    $saved = @()
    foreach ($r in $regs) {
        $existed = $false; $cur = $null
        $k = Get-Item -LiteralPath $r.P -ErrorAction SilentlyContinue
        if ($k -and ($k.GetValueNames() -contains $r.N)) { $existed = $true; $cur = $k.GetValue($r.N) }
        $saved += @{ P = $r.P; N = $r.N; T = $r.T; E = $existed; V = $cur }
        Set-Reg $r.P $r.N $r.V $r.T
    }
    if (-not $script:backup.ContainsKey($id)) { $script:backup[$id] = $saved; Save-Backup }
}
function Undo-RegList($id) {
    foreach ($e in @($script:backup[$id])) {
        if ($e.E) { Set-Reg $e.P $e.N $e.V $e.T }
        else { Remove-ItemProperty -LiteralPath $e.P -Name $e.N -ErrorAction SilentlyContinue }
    }
}

# ---------- Tweak table (id|category|plan|recommended|name|description|registry values) ----------
$tweakData = @'
dvr|perf|0|1|Disable Xbox Game Bar background recording|Stops background capture that costs CPU and GPU and can cause stutter.|HKCU\System\GameConfigStore>>GameDVR_Enabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR>>AppCaptureEnabled>>D>>0
gamemode|perf|0|1|Enable Windows Game Mode|Asks Windows to prioritise your game and pause driver and update installs.|HKCU\Software\Microsoft\GameBar>>AutoGameModeEnabled>>D>>1;;HKCU\Software\Microsoft\GameBar>>AllowAutoGameMode>>D>>1
bgapps|perf|0|1|Disable background apps|Stops Store apps running in the background and using CPU and network.|HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications>>GlobalUserDisabled>>D>>1
windowed|perf|0|0|Optimizations for windowed games|Uses the faster flip presentation model for windowed and borderless games.|HKCU\Software\Microsoft\DirectX\UserGpuPreferences>>DirectXUserGlobalSettings>>S>>SwapEffectUpgradeEnable=1;
gbtips|perf|0|1|Hide Game Bar startup panel|Removes the Game Bar welcome and tips panel.|HKCU\Software\Microsoft\GameBar>>ShowStartupPanel>>D>>0
dvrpolicy|perf|1|1|Block Game DVR by policy|System-wide policy that keeps game capture switched off.|HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR>>AllowGameDVR>>D>>0
fseglobal|perf|1|0|Disable fullscreen optimizations globally|Uses classic exclusive fullscreen behaviour for all games.|HKCU\System\GameConfigStore>>GameDVR_FSEBehaviorMode>>D>>2;;HKCU\System\GameConfigStore>>GameDVR_HonorUserFSEBehaviorMode>>D>>1;;HKCU\System\GameConfigStore>>GameDVR_DXGIHonorFSEWindowsCompatible>>D>>1;;HKCU\System\GameConfigStore>>GameDVR_EFSEFeatureFlags>>D>>0
pthrottle|perf|1|1|Turn off Windows power throttling|Stops Windows slowing apps it thinks are background. Uses more battery on laptops.|HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling>>PowerThrottlingOff>>D>>1
mmcss|perf|1|1|Boost games in the Windows scheduler|Raises the Games task priority in the multimedia scheduler (MMCSS).|HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games>>GPU Priority>>D>>8;;HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games>>Priority>>D>>6;;HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games>>Scheduling Category>>S>>High;;HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games>>SFIO Priority>>S>>High
sysresp|perf|1|1|Reserve no CPU for background multimedia|Sets the multimedia scheduler to keep 0 percent of CPU in reserve.|HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile>>SystemResponsiveness>>D>>0
hags|perf|1|1|Enable hardware-accelerated GPU scheduling|Lets the GPU manage its own scheduling. Needs a supported GPU and a restart.|HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers>>HwSchMode>>D>>2
prefetch|perf|1|0|Disable Prefetch and Superfetch|Stops preloading apps into memory. Best on SSD systems.|HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters>>EnablePrefetcher>>D>>0;;HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters>>EnableSuperfetch>>D>>0
bgpolicy|perf|1|1|Block Store apps from running in the background|Policy that forces Store apps to stay closed in the background.|HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy>>LetAppsRunInBackground>>D>>2
presence|perf|1|1|Disable Game Bar presence writer|Stops a Game Bar background component from activating.|HKLM\SOFTWARE\Microsoft\WindowsRuntime\ActivatableClassId\Windows.Gaming.GameBar.PresenceServer.Internal.PresenceWriter>>ActivationType>>D>>0
win32prio|perf|2|1|Favour foreground apps for CPU time|Short, variable, high foreground boost so the active window gets priority.|HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl>>Win32PrioritySeparation>>D>>38
pagingexe|perf|2|0|Keep kernel and drivers in RAM|Stops paging core system code to disk. Best with 16 GB of RAM or more.|HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management>>DisablePagingExecutive>>D>>1
timerres|perf|2|0|Restore global timer resolution requests|Windows 11 setting that lets games keep a high-resolution timer. Needs restart.|HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel>>GlobalTimerResolutionRequests>>D>>1
maint|perf|2|0|Disable automatic maintenance|Stops idle-time maintenance tasks from starting while you play.|HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance>>MaintenanceDisabled>>D>>1
ntfslast|perf|2|1|Disable NTFS last-access updates|Avoids a disk write every time a file is read. Needs restart.|HKLM\SYSTEM\CurrentControlSet\Control\FileSystem>>NtfsDisableLastAccessUpdate>>D>>1
delivery|net|0|1|Stop Windows Update sharing your upload bandwidth|Turns off peer-to-peer update sharing so it cannot eat your upload.|HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization>>DODownloadMode>>D>>0
nthrottle|net|1|1|Disable network throttling index|Removes the multimedia network throttle. Small or no effect on many PCs.|HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile>>NetworkThrottlingIndex>>D>>-1
ncsi|net|1|0|Disable internet connectivity probe|Stops Windows pinging Microsoft to test your connection. Tray icon may be less accurate.|HKLM\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet>>EnableActiveProbing>>D>>0
qos|net|1|1|Remove QoS bandwidth limit|Makes sure Windows reserves no bandwidth for QoS-tagged apps.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Psched>>NonBestEffortLimit>>D>>0
llmnr|net|1|0|Disable LLMNR name resolution|Turns off a legacy multicast lookup that adds background network chatter.|HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient>>EnableMulticast>>D>>0
negcache|net|2|0|Do not cache failed DNS lookups|Retries failed lookups immediately instead of waiting for the cache to expire.|HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters>>MaxNegativeCacheTtl>>D>>0
ipv4pref|net|2|0|Prefer IPv4 over IPv6|Tries IPv4 first without turning IPv6 off. Can help on networks with slow IPv6.|HKLM\SYSTEM\CurrentControlSet\Services\TCPIP6\Parameters>>DisabledComponents>>D>>32
mouse|input|0|1|Disable mouse acceleration|Turns off Enhance pointer precision so your aim is consistent.|HKCU\Control Panel\Mouse>>MouseSpeed>>S>>0;;HKCU\Control Panel\Mouse>>MouseThreshold1>>S>>0;;HKCU\Control Panel\Mouse>>MouseThreshold2>>S>>0
sticky|input|0|1|Disable Sticky, Filter and Toggle Keys popups|Stops the Shift-spam popup from pulling you out of a game.|HKCU\Control Panel\Accessibility\StickyKeys>>Flags>>S>>506;;HKCU\Control Panel\Accessibility\Keyboard Response>>Flags>>S>>122;;HKCU\Control Panel\Accessibility\ToggleKeys>>Flags>>S>>58
mtrails|input|0|1|Turn off mouse pointer trails|Makes sure no pointer trail effect is drawn.|HKCU\Control Panel\Mouse>>MouseTrails>>S>>0
winkeys|input|0|0|Disable Windows key shortcuts|Stops accidental Win key presses minimising your game. Disables all Win+ shortcuts.|HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer>>NoWinKeys>>D>>1
kblayout|input|0|0|Disable keyboard layout hotkeys|Stops Alt+Shift and Ctrl+Shift switching your keyboard layout mid-game.|HKCU\Keyboard Layout\Toggle>>Hotkey>>S>>3;;HKCU\Keyboard Layout\Toggle>>Language Hotkey>>S>>3;;HKCU\Keyboard Layout\Toggle>>Layout Hotkey>>S>>3
ducking|input|0|1|Stop Windows lowering game volume during calls|Sets communications audio ducking to Do nothing.|HKCU\Software\Microsoft\Multimedia\Audio>>UserDuckingPreference>>D>>3
shake|input|0|0|Disable Aero Shake|Shaking a window no longer minimises all the others.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>DisallowShaking>>D>>1
snap|input|1|0|Disable window snapping|Stops windows snapping to screen edges while you drag them.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>SnapAssist>>D>>0;;HKCU\Control Panel\Desktop>>WindowArrangementActive>>S>>0
snapflyout|input|1|0|Disable Snap Layouts hover flyout|Hides the Windows 11 snap layout popup on the maximise button.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>EnableSnapAssistFlyout>>D>>0
alttab|input|1|0|Alt+Tab shows open windows only|Removes Edge browser tabs from the Alt+Tab switcher.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>MultiTaskingAltTabFilter>>D>>3
kbspeed|input|1|0|Fastest keyboard repeat rate|Shortest repeat delay and fastest repeat speed for held keys.|HKCU\Control Panel\Keyboard>>KeyboardSpeed>>S>>31;;HKCU\Control Panel\Keyboard>>KeyboardDelay>>S>>0
touchfb|input|1|0|Disable touch feedback visuals|Turns off the touch and gesture visualisation overlays.|HKCU\Control Panel\Cursors>>ContactVisualization>>D>>0;;HKCU\Control Panel\Cursors>>GestureVisualization>>D>>0
narrator|input|1|0|Disable the Narrator shortcut|Stops Win+Ctrl+Enter launching Narrator by accident.|HKCU\Software\Microsoft\Narrator\NoRoam>>WinEnterLaunchEnabled>>D>>0
inkws|input|2|0|Disable Windows Ink Workspace|Turns off the pen workspace and its background components.|HKLM\SOFTWARE\Policies\Microsoft\WindowsInkWorkspace>>AllowWindowsInkWorkspace>>D>>0
menudelay|vis|0|1|Open menus instantly|Removes the short delay before menus appear (applies after you sign out).|HKCU\Control Panel\Desktop>>MenuShowDelay>>S>>0
startdelay|vis|0|1|Remove startup app delay|Startup apps launch right after sign-in instead of waiting several seconds.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize>>StartupDelayInMSec>>D>>0
minanim|vis|0|1|Disable minimize and maximize animations|Windows snap open and shut instantly (applies after you sign out).|HKCU\Control Panel\Desktop\WindowMetrics>>MinAnimate>>S>>0
taskbaranim|vis|0|1|Disable taskbar animations|Taskbar buttons skip their animation (applies after Explorer restarts).|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>TaskbarAnimations>>D>>0
shadows|vis|0|0|Disable desktop icon label shadows|Small rendering saving on the desktop (applies after Explorer restarts).|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>ListviewShadow>>D>>0
aeropeek|vis|0|0|Disable Aero Peek previews|No live window previews when you hover the taskbar (applies after sign-out).|HKCU\Software\Microsoft\Windows\DWM>>EnableAeroPeek>>D>>0
dragfull|vis|0|0|Do not show window contents while dragging|Dragging a window draws only an outline (applies after sign-out).|HKCU\Control Panel\Desktop>>DragFullWindows>>S>>0
transp|vis|0|1|Disable Windows transparency effects|Small GPU saving from the Windows blur and transparency effects.|HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize>>EnableTransparency>>D>>0
darkmode|vis|0|0|Dark mode for Windows and apps|Switches the system and app theme to dark.|HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize>>AppsUseLightTheme>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize>>SystemUsesLightTheme>>D>>0
taskleft|vis|1|0|Align taskbar icons to the left|Windows 11: puts the Start button and icons on the left.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>TaskbarAl>>D>>0
taskview|vis|1|0|Hide the Task View button|Removes the Task View button from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>ShowTaskViewButton>>D>>0
chatbtn|vis|1|0|Hide the Chat button|Removes the Chat and Teams button from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>TaskbarMn>>D>>0
searchbox|vis|1|0|Hide the taskbar search box|Removes the search box or icon from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Search>>SearchboxTaskbarMode>>D>>0
newsfeed|vis|1|1|Hide News and Interests|Removes the news and weather feed from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Feeds>>ShellFeedsTaskbarViewMode>>D>>2
vfx|vis|1|0|Windows visual effects: best performance preset|Switches Visual Effects to Adjust for best performance (sign out and in).|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects>>VisualFXSetting>>D>>2
startsound|vis|1|0|Disable the Windows startup sound|Silences the sound played at sign-in.|HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\BootAnimation>>DisableStartupSound>>D>>1
lockspot|vis|1|0|Disable lock screen Spotlight rotation|Stops rotating lock screen images and the overlay tips.|HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>RotatingLockScreenEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>RotatingLockScreenOverlayEnabled>>D>>0
seconds|vis|1|0|Show seconds in the taskbar clock|Adds seconds to the system tray clock.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>ShowSecondsInSystemClock>>D>>1
nolock|vis|2|0|Skip the lock screen|Goes straight to the sign-in screen when you start or wake the PC.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization>>NoLockScreen>>D>>1
acrylic|vis|2|0|Remove sign-in screen blur|Turns off the acrylic blur on the sign-in background.|HKLM\SOFTWARE\Policies\Microsoft\Windows\System>>DisableAcrylicBackgroundOnLogon>>D>>1
lockcam|vis|2|0|Disable the lock screen camera|Removes the camera shortcut from the lock screen.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization>>NoLockScreenCamera>>D>>1
firstlogon|vis|2|0|Disable the first sign-in animation|Skips the welcome animation the first time a user signs in.|HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System>>EnableFirstLogonAnimation>>D>>0
recentapps|vis|2|0|Hide recently added apps in Start|Removes the Recently added list from the Start menu.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer>>HideRecentlyAddedApps>>D>>1
fileext|expl|0|0|Show file extensions|Always shows extensions like .exe and .txt in Explorer.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>HideFileExt>>D>>0
hidden|expl|0|0|Show hidden files and folders|Makes hidden items visible in Explorer.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>Hidden>>D>>1
launchto|expl|0|0|Open Explorer to This PC|Explorer starts on This PC instead of Home or Quick access.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>LaunchTo>>D>>1
fullpath|expl|0|0|Show full path in the title bar|Explorer windows show the complete folder path.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\CabinetState>>FullPath>>D>>1
navpane|expl|0|0|Expand navigation pane to current folder|The left pane follows the folder you are in.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>NavPaneExpandToCurrentFolder>>D>>1
enthusiast|expl|0|0|Always show details in copy dialogs|File copy windows open with the speed graph and details expanded.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager>>EnthusiastMode>>D>>1
syncnotif|expl|0|1|Hide sync provider notifications|Removes OneDrive and Microsoft 365 promotions from Explorer.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>ShowSyncProviderNotifications>>D>>0
autocheck|expl|1|0|Show checkboxes to select items|Adds checkboxes for easier multi-select in Explorer.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>AutoCheckSelect>>D>>1
sepproc|expl|1|0|Run folder windows in separate processes|A crashing folder window no longer takes the others with it.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>SeparateProcess>>D>>1
sharingwiz|expl|1|0|Disable the Sharing Wizard|Uses the classic sharing dialog instead of the wizard.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>SharingWizardOn>>D>>0
compact|expl|1|0|Use compact view in Explorer|Windows 11: reduces spacing between items.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>UseCompactMode>>D>>1
confirmdel|expl|1|0|Ask before deleting files|Shows a confirmation prompt when you delete to the Recycle Bin.|HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer>>ConfirmFileDelete>>D>>1
iconsonly|expl|2|0|Show icons instead of thumbnails|Faster folder loading in picture-heavy folders.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>IconsOnly>>D>>1
foldertype|expl|2|0|Stop Explorer auto-guessing folder types|Avoids slow folder loads caused by automatic folder type detection.|HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell>>FolderType>>S>>NotSpecified
iconcache|expl|2|0|Larger icon cache|Raises the cached icon limit so icons redraw less often.|HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer>>Max Cached Icons>>S>>4096
onedrive|expl|2|0|Disable OneDrive file sync|Policy that turns OneDrive syncing off for all users.|HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive>>DisableFileSyncNGSC>>D>>1
telemetry|priv|0|1|Reduce Windows telemetry|Sets diagnostic data to the minimum Windows allows for your edition.|HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection>>AllowTelemetry>>D>>0
adid|priv|0|1|Turn off the advertising ID|Stops apps using a personal advertising ID to profile you.|HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo>>Enabled>>D>>0
suggest|priv|0|1|Turn off Start menu suggestions and tips|Removes promoted apps, tips and suggested content from Windows.|HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SystemPaneSuggestionsEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SubscribedContent-338388Enabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SubscribedContent-338389Enabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SoftLandingEnabled>>D>>0
websearch|priv|0|1|Disable web results in Start search|Start search only looks at your PC, so it is faster and no Bing results appear.|HKCU\Software\Policies\Microsoft\Windows\Explorer>>DisableSearchBoxSuggestions>>D>>1
tailored|priv|0|1|Turn off tailored experiences|Stops Microsoft using your diagnostic data for personalised tips.|HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy>>TailoredExperiencesWithDiagnosticDataEnabled>>D>>0
langopt|priv|0|0|Hide your language list from websites|Stops websites reading your installed language list.|HKCU\Control Panel\International\User Profile>>HttpAcceptLanguageOptOut>>D>>1
trackprogs|priv|0|1|Do not track app launches|Stops Windows tracking which apps you launch to improve Start.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>Start_TrackProgs>>D>>0
trackdocs|priv|0|0|Do not track recent documents|Stops Windows keeping a list of recently opened files.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>Start_TrackDocs>>D>>0
feedback|priv|0|1|Never ask for feedback|Sets the Windows feedback frequency to never.|HKCU\Software\Microsoft\Siuf\Rules>>NumberOfSIUFInPeriod>>D>>0;;HKCU\Software\Microsoft\Siuf\Rules>>PeriodInNanoSeconds>>D>>0
silentinst|priv|0|1|Stop silent installs of promoted apps|Prevents Windows quietly installing suggested apps and games.|HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SilentInstalledAppsEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>PreInstalledAppsEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>OemPreInstalledAppsEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>ContentDeliveryAllowed>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>PreInstalledAppsEverEnabled>>D>>0
feedbacknotif|priv|0|1|Hide feedback notifications|Stops Windows asking you to rate features.|HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection>>DoNotShowFeedbackNotifications>>D>>1
loc|priv|0|0|Turn off location access|Denies location access to apps by default.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location>>Value>>S>>Deny
bingsearch|priv|0|0|Turn off Bing in Start search (per user)|Per-user switch that keeps web results out of the Start menu.|HKCU\Software\Microsoft\Windows\CurrentVersion\Search>>BingSearchEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\Search>>CortanaConsent>>D>>0
activity|priv|1|1|Turn off Activity History|Stops Windows recording and uploading your app and file activity timeline.|HKLM\SOFTWARE\Policies\Microsoft\Windows\System>>EnableActivityFeed>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\System>>PublishUserActivities>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\System>>UploadUserActivities>>D>>0
contacts|priv|1|0|Deny app access to contacts|Blocks Store apps from reading your contacts.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\contacts>>Value>>S>>Deny
calendar|priv|1|0|Deny app access to calendar|Blocks Store apps from reading your calendar.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appointments>>Value>>S>>Deny
email|priv|1|0|Deny app access to email|Blocks Store apps from reading your email.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\email>>Value>>S>>Deny
acctinfo|priv|1|0|Deny app access to account info|Blocks Store apps from reading your name and picture.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation>>Value>>S>>Deny
callhist|priv|1|0|Deny app access to call history|Blocks Store apps from reading your call history.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCallHistory>>Value>>S>>Deny
messaging|priv|1|0|Deny app access to messaging|Blocks Store apps from reading and sending messages.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\chat>>Value>>S>>Deny
appdiag|priv|1|0|Deny app access to other apps' diagnostics|Blocks apps from seeing what other apps are doing.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics>>Value>>S>>Deny
notiflisten|priv|1|0|Deny app access to your notifications|Blocks apps from reading notifications from other apps.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener>>Value>>S>>Deny
showrecent|priv|1|0|Hide recent and frequent files in Explorer|Quick access stops listing recent and frequent items.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer>>ShowRecent>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer>>ShowFrequent>>D>>0
inkpriv|priv|1|1|Stop typing and inking data collection|Stops Windows learning from your typing and handwriting.|HKCU\Software\Microsoft\InputPersonalization>>RestrictImplicitTextCollection>>D>>1;;HKCU\Software\Microsoft\InputPersonalization>>RestrictImplicitInkCollection>>D>>1;;HKCU\Software\Microsoft\InputPersonalization\TrainedDataStore>>HarvestContacts>>D>>0
speech|priv|1|0|Turn off online speech recognition|Stops voice data being sent to Microsoft for recognition.|HKCU\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy>>HasAccepted>>D>>0
clipsync|priv|1|0|Turn off cloud clipboard sync|Stops your clipboard syncing between devices.|HKLM\SOFTWARE\Policies\Microsoft\Windows\System>>AllowCrossDeviceClipboard>>D>>0
wer|priv|1|1|Disable Windows Error Reporting|Stops crash reports being sent to Microsoft.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting>>Disabled>>D>>1
ceip|priv|1|1|Opt out of the Customer Experience program|Stops usage statistics being collected for Microsoft.|HKLM\SOFTWARE\Policies\Microsoft\SQMClient\Windows>>CEIPEnable>>D>>0
appinv|priv|1|1|Stop application inventory telemetry|Stops Windows reporting which apps are installed.|HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat>>DisableInventory>>D>>1;;HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat>>AITEnable>>D>>0
cortana|priv|1|0|Disable Cortana and cloud search|Turns off Cortana and web-connected search through policy.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search>>AllowCortana>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search>>AllowCloudSearch>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search>>ConnectedSearchUseWeb>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search>>DisableWebSearch>>D>>1
searchloc|priv|1|0|Stop search using your location|Prevents Windows Search using your location.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search>>AllowSearchToUseLocation>>D>>0
consumer|priv|1|1|Disable Windows consumer features|Stops Windows installing promoted apps for new users.|HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent>>DisableWindowsConsumerFeatures>>D>>1
cdp|priv|1|0|Turn off shared experiences|Stops apps sharing and continuing tasks across your devices.|HKCU\Software\Microsoft\Windows\CurrentVersion\CDP>>RomeSdkChannelUserAuthzPolicy>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\CDP>>CdpSessionUserAuthzPolicy>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\CDP>>NearShareChannelUserAuthzPolicy>>D>>0
radios|priv|2|0|Deny app access to radios|Blocks apps from switching Bluetooth and Wi-Fi radios.|HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\radios>>Value>>S>>Deny
syncsettings|priv|2|0|Turn off Windows settings sync|Stops syncing your Windows settings to the cloud.|HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync>>DisableSettingSync>>D>>2;;HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync>>DisableSettingSyncUserOverride>>D>>1
handwriteerr|priv|2|0|Stop handwriting error reports|Stops handwriting recognition error reports being sent.|HKLM\SOFTWARE\Policies\Microsoft\Windows\HandwritingErrorReports>>PreventHandwritingErrorReports>>D>>1
tabletshare|priv|2|0|Stop handwriting data sharing|Stops handwriting personalisation data being shared.|HKLM\SOFTWARE\Policies\Microsoft\Windows\TabletPC>>PreventHandwritingDataSharing>>D>>1
findmydev|priv|2|0|Turn off Find My Device|Stops the device location reporting feature.|HKLM\SOFTWARE\Policies\Microsoft\FindMyDevice>>AllowFindMyDevice>>D>>0
mrt|priv|2|0|Stop malware removal tool reporting|Stops the Malicious Software Removal Tool sending reports.|HKLM\SOFTWARE\Policies\Microsoft\MRT>>DontReportInfectionInformation>>D>>1
spotlight|priv|2|1|Disable Windows Spotlight features|Policy that turns off Spotlight and soft-landing suggestions.|HKCU\Software\Policies\Microsoft\Windows\CloudContent>>DisableWindowsSpotlightFeatures>>D>>1;;HKCU\Software\Policies\Microsoft\Windows\CloudContent>>DisableSoftLanding>>D>>1
uar|priv|2|0|Disable Steps Recorder|Turns off the Problem Steps Recorder.|HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat>>DisableUAR>>D>>1
insider|priv|2|1|Block Windows Insider and experimentation|Stops preview builds and experiment enrolment.|HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds>>AllowBuildPreview>>D>>0
difflogs|priv|2|1|Limit diagnostic log collection|Limits diagnostic logs and dumps collected for Microsoft.|HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection>>LimitDiagnosticLogCollection>>D>>1;;HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection>>LimitDumpCollection>>D>>1;;HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection>>DisableOneSettingsDownloads>>D>>1
onlinetips|priv|2|1|Disable online tips in Settings|Stops Settings fetching tips from Microsoft online.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer>>AllowOnlineTips>>D>>0
autoreboot|sys|0|1|No forced restart while you are signed in|Stops Windows Update rebooting your PC mid-session, like during a match.|HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU>>NoAutoRebootWithLoggedOnUsers>>D>>1
werui|sys|0|0|Hide error reporting dialogs|Stops the Windows Error Reporting popup after a crash.|HKCU\Software\Microsoft\Windows\Windows Error Reporting>>DontShowUI>>D>>1
bsodinfo|sys|0|0|Show detailed blue screen information|Displays the technical parameters on a blue screen.|HKLM\SYSTEM\CurrentControlSet\Control\CrashControl>>DisplayParameters>>D>>1
fastshut|sys|0|1|Faster shutdown|Reduces how long Windows waits for services to stop at shutdown.|HKLM\SYSTEM\CurrentControlSet\Control>>WaitToKillServiceTimeout>>S>>2000
mapsupd|sys|0|0|Stop automatic offline maps updates|Stops Windows downloading map updates in the background.|HKLM\SYSTEM\Maps>>AutoUpdateEnabled>>D>>0
faststart|sys|1|0|Disable Fast Startup|Makes Shut down a true full shutdown, which clears driver and memory glitches.|HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power>>HiberbootEnabled>>D>>0
endtasks|sys|1|1|Close hung apps faster|Ends unresponsive apps sooner when you sign out or shut down.|HKCU\Control Panel\Desktop>>AutoEndTasks>>S>>1;;HKCU\Control Panel\Desktop>>HungAppTimeout>>S>>2000;;HKCU\Control Panel\Desktop>>WaitToKillAppTimeout>>S>>2000
smalldump|sys|1|0|Use small crash dumps|Writes small memory dumps after a crash to save disk space.|HKLM\SYSTEM\CurrentControlSet\Control\CrashControl>>CrashDumpEnabled>>D>>3
nocrashreboot|sys|1|0|Do not auto-restart after a crash|Stays on the blue screen so you can read the error.|HKLM\SYSTEM\CurrentControlSet\Control\CrashControl>>AutoReboot>>D>>0
verbose|sys|1|0|Show detailed sign-in and shutdown messages|Shows what Windows is doing while it starts and shuts down.|HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System>>VerboseStatus>>D>>1
storeauto|sys|1|0|Stop automatic Store app updates|Store apps update only when you choose.|HKLM\SOFTWARE\Policies\Microsoft\WindowsStore>>AutoDownload>>D>>2
nodrivers_wu|sys|1|1|Keep drivers out of Windows Update|Stops Windows replacing your GPU driver with an older version.|HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate>>ExcludeWUDriversInQualityUpdate>>D>>1
widgets|sys|1|1|Disable Widgets and News feed|Stops the Windows 11 Widgets process running in the background.|HKLM\SOFTWARE\Policies\Microsoft\Dsh>>AllowNewsAndInterests>>D>>0
copilot|sys|1|1|Turn off Windows Copilot|Disables the Copilot assistant where it is present.|HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot>>TurnOffWindowsCopilot>>D>>1
hibernate|power|1|0|Disable hibernation|Frees disk space used by the hibernation file. Needs restart.|HKLM\SYSTEM\CurrentControlSet\Control\Power>>HibernateEnabled>>D>>0
wunotify|sys|2|0|Ask before downloading Windows updates|You choose when to download updates. You must update manually to stay secure.|HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU>>NoAutoUpdate>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU>>AUOptions>>D>>2
wudefer|sys|2|0|Defer feature updates for a year|Delays big Windows version upgrades by up to 365 days.|HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate>>DeferFeatureUpdates>>D>>1;;HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate>>DeferFeatureUpdatesPeriodInDays>>D>>365
svc_diag|sys|1|1|Disable telemetry service (DiagTrack)|Stops the Connected User Experiences and Telemetry service. Takes effect after restart.|HKLM\SYSTEM\CurrentControlSet\Services\DiagTrack>>Start>>D>>4
svc_wap|sys|1|0|Disable WAP push service|Stops the device management push routing service.|HKLM\SYSTEM\CurrentControlSet\Services\dmwappushservice>>Start>>D>>4
svc_maps|sys|1|0|Disable Downloaded Maps Manager|Stops the offline maps background service.|HKLM\SYSTEM\CurrentControlSet\Services\MapsBroker>>Start>>D>>4
svc_geo|sys|1|0|Disable Geolocation service|Stops the service that tracks your device location.|HKLM\SYSTEM\CurrentControlSet\Services\lfsvc>>Start>>D>>4
svc_phone|sys|1|0|Disable Phone service|Stops the phone and device pairing service.|HKLM\SYSTEM\CurrentControlSet\Services\PhoneSvc>>Start>>D>>4
svc_remotereg|sys|2|1|Disable Remote Registry|Stops other PCs reading your registry. Good hardening.|HKLM\SYSTEM\CurrentControlSet\Services\RemoteRegistry>>Start>>D>>4
svc_retail|sys|2|1|Disable Retail Demo service|Stops the in-store demo mode service.|HKLM\SYSTEM\CurrentControlSet\Services\RetailDemo>>Start>>D>>4
svc_wer|sys|2|0|Disable Error Reporting service|Stops the Windows Error Reporting service.|HKLM\SYSTEM\CurrentControlSet\Services\WerSvc>>Start>>D>>4
svc_sysmain|sys|2|0|Disable SysMain (Superfetch)|Stops memory pre-loading. Best on SSD systems.|HKLM\SYSTEM\CurrentControlSet\Services\SysMain>>Start>>D>>4
svc_wsearch|sys|2|0|Disable Windows Search indexing|Stops the indexer. Start menu and Explorer search will be slower.|HKLM\SYSTEM\CurrentControlSet\Services\WSearch>>Start>>D>>4
svc_xbox|sys|2|0|Disable Xbox services|Stops Xbox Live services. Do not use if you play Game Pass or Xbox apps.|HKLM\SYSTEM\CurrentControlSet\Services\XblAuthManager>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\XblGameSave>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\XboxNetApiSvc>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\XboxGipSvc>>Start>>D>>4
svc_parental|sys|2|0|Disable Parental Controls service|Stops the family safety monitoring service.|HKLM\SYSTEM\CurrentControlSet\Services\WpcMonSvc>>Start>>D>>4
svc_hotspot|sys|2|0|Disable Mobile Hotspot service|Stops Internet Connection Sharing. Do not use if you share your connection.|HKLM\SYSTEM\CurrentControlSet\Services\icssvc>>Start>>D>>4
svc_wia|sys|2|0|Disable Image Acquisition service|Stops scanner and camera import. Do not use if you scan documents.|HKLM\SYSTEM\CurrentControlSet\Services\stisvc>>Start>>D>>4
svc_spooler|sys|2|0|Disable Print Spooler|Stops all printing. Only use if you never print.|HKLM\SYSTEM\CurrentControlSet\Services\Spooler>>Start>>D>>4
svc_scard|sys|2|0|Disable Smart Card services|Stops smart card readers. Only if you do not use them.|HKLM\SYSTEM\CurrentControlSet\Services\SCardSvr>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\ScDeviceEnum>>Start>>D>>4
svc_wcn|sys|2|0|Disable Windows Connect Now|Stops the Wi-Fi setup via USB or WPS service.|HKLM\SYSTEM\CurrentControlSet\Services\wcncsvc>>Start>>D>>4
svc_trk|sys|2|0|Disable Distributed Link Tracking|Stops tracking of file links across NTFS volumes.|HKLM\SYSTEM\CurrentControlSet\Services\TrkWks>>Start>>D>>4
svc_insider|sys|2|0|Disable Windows Insider service|Stops the Insider preview enrolment service.|HKLM\SYSTEM\CurrentControlSet\Services\wisvc>>Start>>D>>4
svc_pca|sys|2|0|Disable Program Compatibility Assistant|Stops compatibility pop-ups for older programs.|HKLM\SYSTEM\CurrentControlSet\Services\PcaSvc>>Start>>D>>4
svc_alljoyn|sys|2|0|Disable AllJoyn Router|Stops the IoT device discovery service.|HKLM\SYSTEM\CurrentControlSet\Services\AJRouter>>Start>>D>>4
svc_csc|sys|2|0|Disable Offline Files|Stops network file caching. Only if you do not use Offline Files.|HKLM\SYSTEM\CurrentControlSet\Services\CscService>>Start>>D>>4
svc_winrm|sys|2|0|Disable Windows Remote Management|Stops remote PowerShell and WinRM access.|HKLM\SYSTEM\CurrentControlSet\Services\WinRM>>Start>>D>>4
autoplay|sec|0|1|Turn off AutoPlay|Stops Windows automatically opening USB drives and discs.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers>>DisableAutoplay>>D>>1
remoteassist|sec|0|1|Disable Remote Assistance|Blocks Remote Assistance invitations.|HKLM\SYSTEM\CurrentControlSet\Control\Remote Assistance>>fAllowToGetHelp>>D>>0
autorun|sec|0|0|Disable AutoRun on all drives|Stops programs on drives starting automatically.|HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer>>NoDriveTypeAutoRun>>D>>255
smb1|sec|1|0|Disable SMB version 1|Turns off the old, insecure file sharing protocol.|HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters>>SMB1>>D>>0
rdpoff|sec|1|0|Disable Remote Desktop connections|Blocks incoming Remote Desktop. Do not use if you remote in.|HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server>>fDenyTSConnections>>D>>1
cad|sec|1|0|Require Ctrl+Alt+Del at sign-in|Adds a secure attention sequence before the sign-in prompt.|HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System>>DisableCAD>>D>>0
lastuser|sec|1|0|Hide the last signed-in user name|Sign-in screen no longer shows who used the PC last.|HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System>>DontDisplayLastUserName>>D>>1
restrictanon|sec|2|0|Restrict anonymous network enumeration|Blocks anonymous listing of accounts and shares.|HKLM\SYSTEM\CurrentControlSet\Control\Lsa>>RestrictAnonymous>>D>>1;;HKLM\SYSTEM\CurrentControlSet\Control\Lsa>>RestrictAnonymousSAM>>D>>1
wdigest|sec|2|0|Stop WDigest caching passwords|Prevents plain-text credentials being held in memory.|HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest>>UseLogonCredential>>D>>0
wsh|sec|2|0|Disable Windows Script Host|Blocks .vbs and .js scripts. Some installers and tools need it.|HKLM\SOFTWARE\Microsoft\Windows Script Host\Settings>>Enabled>>D>>0
adminshares|sec|2|0|Disable default admin shares|Removes the hidden C$ and ADMIN$ network shares on workstations.|HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters>>AutoShareWks>>D>>0
edgeboost|edge|0|1|Stop Edge running in the background|Turns off Edge startup boost and background mode.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>StartupBoostEnabled>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Edge>>BackgroundModeEnabled>>D>>0
edgesidebar|edge|1|0|Disable the Edge sidebar|Hides the Edge sidebar and its Copilot hub.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>HubsSidebarEnabled>>D>>0
edgeshop|edge|1|1|Disable the Edge shopping assistant|Stops Edge showing coupons and price comparison popups.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>EdgeShoppingAssistantEnabled>>D>>0
edgerewards|edge|1|1|Disable Microsoft Rewards in Edge|Hides the Rewards prompts in Edge.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>ShowMicrosoftRewards>>D>>0
edgetele|edge|1|1|Reduce Edge data collection|Turns off Edge usage reporting and personalisation.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>MetricsReportingEnabled>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Edge>>PersonalizationReportingEnabled>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Edge>>SendSiteInfoToImproveServices>>D>>0
edgesuggest|edge|1|0|Turn off Edge search suggestions|Stops Edge sending what you type to search for suggestions.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>SearchSuggestEnabled>>D>>0
edgecollect|edge|2|0|Disable Edge Collections|Hides the Collections feature.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>EdgeCollectionsEnabled>>D>>0
edgefollow|edge|2|0|Disable Follow creators in Edge|Hides the Follow creators feature.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>EdgeFollowEnabled>>D>>0
edgereco|edge|2|0|Hide Edge recommendations|Hides recommended content and Spotlight tips in Edge.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>ShowRecommendationsEnabled>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Edge>>SpotlightExperiencesAndRecommendationsEnabled>>D>>0
edgefirst|edge|2|0|Skip the Edge first-run experience|Skips the welcome and sign-in pages in Edge.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>HideFirstRunExperience>>D>>1
edgesync|edge|2|0|Disable Edge sync|Stops Edge syncing favourites, history and passwords.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>SyncDisabled>>D>>1
edgeautofill|edge|2|0|Disable Edge autofill and password manager|Turns off saved addresses, cards and passwords in Edge.|HKLM\SOFTWARE\Policies\Microsoft\Edge>>AutofillAddressEnabled>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Edge>>AutofillCreditCardEnabled>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Edge>>PasswordManagerEnabled>>D>>0
toast|notif|0|0|Turn off notification popups|No Windows toast notifications appearing over your game.|HKCU\Software\Microsoft\Windows\CurrentVersion\PushNotifications>>ToastEnabled>>D>>0
toastlock|notif|0|0|Hide notifications on the lock screen|Keeps notifications off the lock screen.|HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings>>NOC_GLOBAL_SETTING_ALLOW_TOASTS_ABOVE_LOCK>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings>>NOC_GLOBAL_SETTING_ALLOW_CRITICAL_TOASTS_ABOVE_LOCK>>D>>0
notifsound|notif|0|0|Mute notification sounds|Notifications arrive silently.|HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings>>NOC_GLOBAL_SETTING_ALLOW_NOTIFICATION_SOUND>>D>>0
welcome|notif|0|1|Hide the welcome experience after updates|Stops the Windows welcome screen showing after updates.|HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SubscribedContent-310093Enabled>>D>>0
finishsetup|notif|0|1|Hide finish-setting-up-your-device prompts|Stops the setup reminder screens.|HKCU\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement>>ScoobeSystemSettingEnabled>>D>>0
balloon|notif|1|0|Turn off balloon tips|Stops legacy tray balloon tip popups.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>EnableBalloonTips>>D>>0
nocenter|notif|2|0|Disable the notification center|Removes the notification center and calendar flyout panel.|HKCU\Software\Policies\Microsoft\Windows\Explorer>>DisableNotificationCenter>>D>>1
u_fth|perf|2|0|Disable Fault Tolerant Heap|Stops Windows silently applying slower crash-mitigation memory settings to games that crashed before.|HKLM\SOFTWARE\Microsoft\FTH>>Enabled>>D>>0
u_dvrcapture|perf|2|1|Disable Game DVR audio and cursor capture|Turns off the leftover audio and cursor capture hooks used by Game Bar recording.|HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR>>AudioCaptureEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR>>CursorCaptureEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR>>HistoricalCaptureEnabled>>D>>0
u_nexus|perf|2|0|Stop the controller Xbox button opening Game Bar|The Guide button on your controller no longer pops up Game Bar mid-game.|HKCU\Software\Microsoft\GameBar>>UseNexusForGameBarEnabled>>D>>0
u_mpo|perf|2|0|Disable Multiplane Overlay (MPO)|Fixes flicker, black screens and stutter some GPUs get in borderless games. Needs restart.|HKLM\SOFTWARE\Microsoft\Windows\Dwm>>OverlayTestMode>>D>>5
u_tdr|perf|2|0|Give the GPU more time before a driver reset|Raises the GPU timeout from 2 to 10 seconds. Fewer driver stopped responding crashes. Needs restart.|HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers>>TdrDelay>>D>>10;;HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers>>TdrDdiDelay>>D>>10
u_8dot3|perf|2|0|Disable 8.3 short file name creation|Removes an extra legacy name write for every new file. Needs restart.|HKLM\SYSTEM\CurrentControlSet\Control\FileSystem>>NtfsDisable8dot3NameCreation>>D>>1
u_mmcssfull|perf|2|1|Full MMCSS scheduling for games|Removes the background-only clock rate limit and latency-sensitive flags for the Games task.|HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games>>Clock Rate>>D>>10000;;HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games>>Affinity>>D>>0;;HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games>>Background Only>>S>>False
u_lowlatencyaudio|perf|2|1|Boost the Pro Audio scheduler task|Gives low-latency audio apps and voice chat high scheduler priority.|HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio>>Priority>>D>>1;;HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio>>Scheduling Category>>S>>High
u_vbs|perf|2|0|Disable Virtualization-Based Security (VBS)|Can give a real FPS boost on Windows 11. Lowers security and some anti-cheats need it on. Restart.|HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard>>EnableVirtualizationBasedSecurity>>D>>0;;HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity>>Enabled>>D>>0
u_nvtele|perf|2|1|Disable NVIDIA driver telemetry|Opts out of NVIDIA usage reporting (only if an NVIDIA driver is installed).|HKLM\SOFTWARE\NVIDIA Corporation\NvControlPanel2\Client>>OptInOrOutPreference>>D>>0;;HKLM\SYSTEM\CurrentControlSet\Services\NvTelemetryContainer>>Start>>D>>4
u_maxport|net|2|0|More ports and faster socket recycling|Raises the dynamic port limit and frees closed connections after 30 seconds.|HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters>>MaxUserPort>>D>>65534;;HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters>>TcpTimedWaitDelay>>D>>30
u_hostprio|net|2|0|Faster host name resolution order|Checks the local cache and hosts file before DNS and NetBIOS.|HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider>>LocalPriority>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider>>HostsPriority>>D>>5;;HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider>>DnsPriority>>D>>6;;HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider>>NetbtPriority>>D>>7
u_teredo|net|2|0|Disable Teredo tunneling|Removes an IPv6 tunnel adapter. Do not use if Xbox party chat says Teredo is needed.|HKLM\SOFTWARE\Policies\Microsoft\Windows\TCPIP\v6Transition>>Teredo_State>>S>>Disabled
u_wpad|net|2|0|Disable proxy auto-discovery (WPAD)|Stops Windows searching the network for a proxy script on every connection.|HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp>>DisableWpad>>D>>1
u_mdns|net|2|0|Disable multicast DNS (mDNS)|Cuts local network discovery chatter. Casting to some devices may need it.|HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters>>EnableMDNS>>D>>0
u_doh|net|2|0|Enable automatic DNS over HTTPS|Encrypts DNS lookups when your DNS server supports it (Cloudflare, Google, Quad9).|HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters>>EnableAutoDoh>>D>>2
u_wifisense|net|2|0|Stop auto-connecting to suggested hotspots|Windows no longer joins open hotspots it suggests on its own.|HKLM\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\config>>AutoConnectAllowedOEM>>D>>0
u_bgnet|net|2|0|Stop background network use by Windows apps|Policy that blocks Store apps from syncing in the background.|HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync>>DisableSettingSync>>D>>2;;HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync>>DisableSettingSyncUserOverride>>D>>1
u_hover|input|2|1|Instant hover response|Tooltips and hover previews appear right away.|HKCU\Control Panel\Mouse>>MouseHoverTime>>S>>10
u_mousekeys|input|2|0|Disable the Mouse Keys shortcut|Stops Left Alt+Shift+Num Lock turning your numpad into a mouse.|HKCU\Control Panel\Accessibility\MouseKeys>>Flags>>S>>0
u_contrastkey|input|2|0|Disable the High Contrast shortcut|Stops Left Alt+Shift+Print Screen switching your screen to high contrast.|HKCU\Control Panel\Accessibility\HighContrast>>Flags>>S>>0
u_prtscn|input|2|0|Print Screen takes a normal screenshot|Stops Print Screen opening the Snipping Tool overlay over your game.|HKCU\Control Panel\Keyboard>>PrintScreenKeyForSnippingEnabled>>D>>0
u_wing|input|2|0|Disable the Win+G Game Bar shortcut|Stops Win+G opening Game Bar by accident.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>DisabledHotkeys>>S>>G
u_numlock|input|2|0|Turn Num Lock on at sign-in|Your numpad is ready as soon as you sign in.|HKCU\Control Panel\Keyboard>>InitialKeyboardIndicators>>S>>2
u_typing|input|2|0|Disable typing insights and autocorrect|Turns off typing insights plus touch keyboard autocorrect and spell check.|HKCU\Software\Microsoft\Input\Settings>>InsightsEnabled>>D>>0;;HKCU\Software\Microsoft\TabletTip\1.7>>EnableAutocorrection>>D>>0;;HKCU\Software\Microsoft\TabletTip\1.7>>EnableSpellchecking>>D>>0
u_jpeg|vis|2|0|Full quality desktop wallpaper|Stops Windows compressing your wallpaper to 85 percent JPEG quality.|HKCU\Control Panel\Desktop>>JPEGImportQuality>>D>>100
u_endtask|vis|2|0|Add End task to taskbar right-click|Windows 11: kill a frozen game straight from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDeveloperSettings>>TaskbarEndTask>>D>>1
u_startrec|vis|2|1|Hide Start menu recommendations|Windows 11: removes recommended files and promoted apps from Start.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>Start_IrisRecommendations>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>Start_AccountNotifications>>D>>0
u_startpins|vis|2|0|Show more pins in Start|Windows 11: bigger pinned area, smaller recommended area.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>Start_Layout>>D>>1
u_copilotbtn|vis|2|1|Hide the Copilot taskbar button|Removes the Copilot button from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>ShowCopilotButton>>D>>0
u_meetnow|vis|2|0|Hide Meet Now and People|Windows 10: removes the Meet Now and People icons from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer>>HideSCAMeetNow>>D>>1;;HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People>>PeopleBand>>D>>0
u_home|expl|2|0|Hide Home from the Explorer sidebar|Windows 11: removes the Home entry from the navigation pane.|HKCU\Software\Classes\CLSID\{f874310e-b6b7-47dc-bc84-b9e6b38f5903}>>System.IsPinnedToNameSpaceTree>>D>>0
u_gallery|expl|2|0|Hide Gallery from the Explorer sidebar|Windows 11: removes the Gallery entry from the navigation pane.|HKCU\Software\Classes\CLSID\{e88865ea-0e1c-4e20-9aa6-edcd0212c87c}>>System.IsPinnedToNameSpaceTree>>D>>0
u_shortcut|expl|2|0|No - Shortcut text on new shortcuts|New shortcuts are named just like the original file.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\NamingTemplates>>ShortcutNameTemplate>>S>>%s.lnk
u_netthumbs|expl|2|0|No thumbnail cache files on network folders|Stops Thumbs.db files locking folders on network shares.|HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer>>DisableThumbsDBOnNetworkFolders>>D>>1
u_longpath|sys|2|0|Enable long file paths|Lets apps use paths longer than 260 characters. Fixes some mod and game installer errors.|HKLM\SYSTEM\CurrentControlSet\Control\FileSystem>>LongPathsEnabled>>D>>1
u_wurestart|sys|2|0|Hide Windows Update restart notifications|Stops restart-required popups while you play.|HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings>>RestartNotificationsAllowed2>>D>>0
u_cortana|priv|2|0|Disable Cortana|Policy that turns off Cortana in search.|HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search>>AllowCortana>>D>>0
u_recall|priv|2|1|Disable Windows Recall snapshots|Stops Copilot+ PCs saving screenshots of your activity.|HKCU\Software\Policies\Microsoft\Windows\WindowsAI>>DisableAIDataAnalysis>>D>>1;;HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI>>DisableAIDataAnalysis>>D>>1
u_settingsads|priv|2|1|Hide suggested content in Settings|Removes promoted suggestions from the Settings app.|HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SubscribedContent-338393Enabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SubscribedContent-353694Enabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SubscribedContent-353696Enabled>>D>>0
u_devtele|priv|2|1|Opt out of PowerShell and .NET telemetry|Stops PowerShell 7 and the .NET SDK sending usage data.|HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment>>POWERSHELL_TELEMETRY_OPTOUT>>S>>1;;HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment>>DOTNET_CLI_TELEMETRY_OPTOUT>>S>>1
u_office|priv|2|1|Disable Microsoft Office telemetry|Stops Office 2016 and later sending usage data.|HKCU\Software\Policies\Microsoft\Office\16.0\Common\ClientTelemetry>>DisableTelemetry>>D>>1;;HKCU\Software\Policies\Microsoft\Office\16.0\Common\ClientTelemetry>>SendTelemetry>>D>>3
u_kms|priv|2|0|Stop sending activation telemetry|Stops the Software Protection platform sending usage data after activation.|HKLM\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\Software Protection Platform>>NoGenTicket>>D>>1
u_msacct|priv|2|0|Stop Microsoft account sign-in nags|Stops Windows nagging you to sign in with a Microsoft account.|HKLM\SOFTWARE\Microsoft\PolicyManager\default\Settings\AllowYourAccount>>value>>D>>0
u_lmhash|sec|2|0|Do not store LM password hashes|Stops Windows saving the weak legacy LAN Manager password hash.|HKLM\SYSTEM\CurrentControlSet\Control\Lsa>>NoLMHash>>D>>1
u_sehop|sec|2|0|Enable SEHOP exploit protection|Blocks a common exploit technique system-wide.|HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel>>DisableExceptionChainValidation>>D>>0
u_rdpnla|sec|2|0|Require network level auth for Remote Desktop|Remote Desktop users must sign in before a session starts.|HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp>>UserAuthentication>>D>>1
u_pua|sec|2|0|Block potentially unwanted apps|Microsoft Defender blocks adware, bundleware and crypto miners.|HKLM\SOFTWARE\Policies\Microsoft\Windows Defender>>PUAProtection>>D>>1
u_lsappl|sec|2|0|Turn on LSA protection|Protects stored credentials from being read by other programs. Needs restart.|HKLM\SYSTEM\CurrentControlSet\Control\Lsa>>RunAsPPL>>D>>1
u_chrome|edge|2|1|Stop Chrome running in the background|Chrome fully closes when you close its last window.|HKLM\SOFTWARE\Policies\Google\Chrome>>BackgroundModeEnabled>>D>>0;;HKLM\SOFTWARE\Policies\Google\Chrome>>MetricsReportingEnabled>>D>>0
u_edgeprelaunch|edge|2|1|Block Edge prelaunch and tab preloading|Stops Edge loading itself in the background when Windows starts.|HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main>>AllowPrelaunch>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\MicrosoftEdge\TabPreloader>>AllowTabPreloading>>D>>0
u_edgeupdate|edge|2|0|Disable Edge desktop shortcut on updates|Stops Edge updates creating a new desktop shortcut.|HKLM\SOFTWARE\Policies\Microsoft\EdgeUpdate>>CreateDesktopShortcutDefault>>D>>0
u_lowdisk|notif|2|0|Disable low disk space warnings|Stops the low disk space popup.|HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer>>NoLowDiskSpaceChecks>>D>>1
u_secnotif|notif|2|0|Hide non-critical Defender notifications|Keeps only important Windows Security alerts.|HKLM\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications>>DisableEnhancedNotifications>>D>>1
u_tipsnotif|notif|2|1|Stop Windows tips notifications|Stops tips and suggestions arriving as notifications.|HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.Suggested>>Enabled>>D>>0
u_vrr|perf|2|0|Variable refresh rate for all games|Turns on Windows VRR so older DirectX 11 games also use G-Sync or FreeSync.|HKCU\Software\Microsoft\DirectX\GraphicsSettings>>SwapEffectUpgradeCache>>D>>1;;HKCU\Software\Microsoft\DirectX\UserGpuPreferences>>VRROptimizeEnable>>D>>1
u_largecache|perf|2|0|Larger file system cache|Keeps more recently used files in RAM. Best with 16 GB or more. Needs restart.|HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management>>LargeSystemCache>>D>>1
u_storsense|perf|2|0|Disable Storage Sense background runs|Stops automatic disk cleanup starting while you play.|HKCU\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy>>01>>D>>0
u_netcrawl|expl|2|0|Stop searching for network folders and printers|Explorer no longer scans your network in the background.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>NoNetCrawling>>D>>1
u_advid|priv|2|1|Disable advertising ID|Apps can no longer track you with an ad ID.|HKLM\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo>>DisabledByGroupPolicy>>D>>1
u_location|priv|2|0|Disable location services|Policy that turns off Windows location for all apps.|HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors>>DisableLocation>>D>>1
u_thumbdelay|vis|1|0|Instant taskbar thumbnails|Window previews show right away when you hover the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>ExtendedUIHoverTime>>D>>1
u_ttl|net|2|0|Default TTL 64|Uses the common packet lifetime of 64 hops.|HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters>>DefaultTTL>>D>>64
u_smbthrottle|net|2|0|Disable SMB bandwidth throttling|Faster copies to and from network drives and NAS.|HKLM\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters>>DisableBandwidthThrottling>>D>>1
u_ntfsmem|perf|2|0|More memory for NTFS|Raises the NTFS paged pool for faster access to many small files. Restart.|HKLM\SYSTEM\CurrentControlSet\Control\FileSystem>>NtfsMemoryUsage>>D>>2
u_usbsuspend|input|2|1|Disable USB selective suspend|Stops USB mice, keyboards and headsets sleeping and dropping inputs.|HKLM\SYSTEM\CurrentControlSet\Services\USB>>DisableSelectiveSuspend>>D>>1
u_sedgeupd|sys|2|0|Set Edge updater services to manual|Edge updaters stop running all the time. Edge still updates when you open it. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\edgeupdate>>Start>>D>>3;;HKLM\SYSTEM\CurrentControlSet\Services\edgeupdatem>>Start>>D>>3;;HKLM\SYSTEM\CurrentControlSet\Services\MicrosoftEdgeElevationService>>Start>>D>>3
u_sgupd|sys|2|0|Set Chrome updater services to manual|Google updaters only run when needed instead of on every boot. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\gupdate>>Start>>D>>3;;HKLM\SYSTEM\CurrentControlSet\Services\gupdatem>>Start>>D>>3;;HKLM\SYSTEM\CurrentControlSet\Services\GoogleChromeElevationService>>Start>>D>>3
u_sfax|sys|2|0|Disable Fax service|Nobody needs to send a fax from a gaming PC. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\Fax>>Start>>D>>4
u_swallet|sys|2|0|Disable Wallet and NFC payments services|Turns off Windows payment services you never use on a desktop. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\WalletService>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\SEMgrSvc>>Start>>D>>4
u_sdiag|sys|2|0|Disable diagnostic policy services|Stops background problem detection. Windows troubleshooters will not work. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\DPS>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\WdiServiceHost>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\WdiSystemHost>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\diagsvc>>Start>>D>>4
u_swercpl|sys|2|0|Disable problem reports and auto troubleshooting|Stops the problem reports control panel and recommended troubleshooting service. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\wercplsupport>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\TroubleshootingSvc>>Start>>D>>4
u_sics|sys|2|0|Disable Internet Connection Sharing|Turns off sharing your connection to other devices. Mobile hotspot stops working. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\ALG>>Start>>D>>4
u_supnp|sys|2|0|Disable UPnP device discovery|Stops scanning for smart TVs and media devices on your network. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\upnphost>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\SSDPSRV>>Start>>D>>4
u_swmpnet|sys|2|0|Disable Windows Media Player sharing|Stops the old media library sharing service. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\WMPNetworkSvc>>Start>>D>>4
u_sworkf|sys|2|0|Disable Work Folders|Removes a corporate file sync service home PCs do not use. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\workfolderssvc>>Start>>D>>4
u_ssensors|sys|2|0|Disable sensor services|Stops light, motion and orientation sensors. Keep on laptops and tablets with auto-rotate. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\SensorService>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\SensrSvc>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\SensorDataService>>Start>>D>>4
u_sshpam|sys|2|0|Disable shared PC and mixed reality simulation|Turns off two services only used on shared or VR test PCs. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\shpamsvc>>Start>>D>>4;;HKLM\SYSTEM\CurrentControlSet\Services\perceptionsimulation>>Start>>D>>4
u_slmhosts|sys|2|0|Disable NetBIOS helper|Stops old NetBIOS name lookups. Leave on if you use old network shares. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\lmhosts>>Start>>D>>4
u_sscpol|sys|2|0|Disable smart card removal policy|Only used with smart card sign-in. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\SCPolicySvc>>Start>>D>>4
u_sprintnot|sys|2|0|Disable printer extensions and notifications|Removes printer pop-ups. Leave on if you print often. Undo puts it back.|HKLM\SYSTEM\CurrentControlSet\Services\PrintNotify>>Start>>D>>4
menuanim|vis|0|1|Disable menu show delay|Context menus open instantly.|HKCU\Control Panel\Desktop>>MenuShowDelay>>S>>0
aeropeek|vis|0|1|Disable Aero Peek|Stops desktop peek on taskbar hover.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>DisablePreviewDesktop>>D>>1
suggestapps|priv|0|1|Disable suggested apps in Start|Stops suggested apps in Start.|HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SystemPaneSuggestionsEnabled>>D>>0;;HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SubscribedContent-338388Enabled>>D>>0
silentinst|priv|0|1|Disable silent app installs|Blocks silent suggested app installs.|HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager>>SilentInstalledAppsEnabled>>D>>0
widgetsbtn|vis|0|1|Hide Widgets button|Removes Widgets from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>TaskbarDa>>D>>0
searchhighlights|vis|0|1|Disable search highlights|Removes search box highlights.|HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings>>IsDynamicSearchBoxEnabled>>D>>0
activityhist|priv|1|1|Disable activity history|Stops Windows timeline activity upload.|HKLM\SOFTWARE\Policies\Microsoft\Windows\System>>EnableActivityFeed>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\System>>PublishUserActivities>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\System>>UploadUserActivities>>D>>0
telemetrybasic|priv|1|1|Limit diagnostic data|Lowest telemetry level policy.|HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection>>AllowTelemetry>>D>>0
autoplayoff|expl|0|1|Disable AutoPlay|Stops AutoPlay on USB insert.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers>>DisableAutoplay>>D>>1
errorreport|priv|0|1|Disable Error Reporting UI|Stops error reporting dialogs.|HKCU\Software\Microsoft\Windows\Windows Error Reporting>>Disabled>>D>>1
dnsmaxcache|net|0|1|Larger DNS cache|Keeps DNS answers longer.|HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters>>MaxCacheTtl>>D>>86400;;HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters>>MaxNegativeCacheTtl>>D>>0
gamebarfull|perf|0|1|Fully disable Game Bar hooks|Turns off Game Bar and DVR switches.|HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR>>AppCaptureEnabled>>D>>0;;HKCU\System\GameConfigStore>>GameDVR_Enabled>>D>>0;;HKCU\Software\Microsoft\GameBar>>UseNexusForGameBarEnabled>>D>>0;;HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR>>AllowGameDVR>>D>>0
copilotbtn|vis|1|0|Hide Copilot taskbar button|Removes Copilot from the taskbar.|HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced>>ShowCopilotButton>>D>>0
remoteassist|sys|1|0|Disable Remote Assistance|Turns off Remote Assistance.|HKLM\SYSTEM\CurrentControlSet\Control\Remote Assistance>>fAllowToGetHelp>>D>>0
'@

# ---------- Parse the tweak table ----------
$tweaks = New-Object System.Collections.ArrayList
foreach ($line in ($tweakData -split "`r?`n")) {
    if (-not $line.Trim() -or $line.StartsWith("#")) { continue }
    $f = $line -split "\|"
    $t = @{ Id = $f[0]; Cat = $f[1]; Plan = [int]$f[2]; Rec = ($f[3] -eq "1"); Name = $f[4]; Desc = $f[5]; Regs = @() }
    if ($f.Count -gt 6 -and $f[6]) {
        foreach ($e in ($f[6] -split ";;")) {
            $p = $e -split ">>"
            if ($p[2] -eq "S") { $type = "String"; $val = [string]$p[3] } else { $type = "DWord"; $val = [int]$p[3] }
            $t.Regs += @{ P = ($p[0] -replace '^(HK[A-Z]{2})\\', '$1:\'); N = $p[1]; T = $type; V = $val }
        }
    }
    [void]$tweaks.Add($t)
}

# ---------- Special tweaks (commands, not plain registry values) ----------
[void]$tweaks.Add(@{ Id = "power"; Cat = "perf"; Plan = 0; Rec = $true; Name = "High Performance power plan"
    Desc = "Keeps your CPU boosted instead of down-clocking mid-fight."
    Apply = {
        $cur = (powercfg /getactivescheme) -join " "
        $prev = $balanced
        if ($cur -match $guidRx) { $prev = $Matches[0] }
        if (-not $script:backup.ContainsKey("power")) { $script:backup["power"] = @{ Guid = $prev }; Save-Backup }
        powercfg /setactive $highPerf 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) {
            $out = (powercfg /duplicatescheme $highPerf 2>&1) -join " "
            if ($out -match $guidRx) { powercfg /setactive $Matches[0] | Out-Null }
        }
    }
    Undo = {
        $g = $script:backup["power"].Guid
        if (-not $g) { $g = $balanced }
        powercfg /setactive $g | Out-Null
    } })
[void]$tweaks.Add(@{ Id = "ultperf"; Cat = "power"; Plan = 2; Rec = $true; Name = "Ultimate Performance power plan"
    Desc = "Hidden maximum-performance Windows plan. Uses more power, best on desktops."
    Apply = {
        $cur = (powercfg /getactivescheme) -join " "
        $prev = $balanced
        if ($cur -match $guidRx) { $prev = $Matches[0] }
        $out = (powercfg /duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>&1) -join " "
        $new = $null
        if ($out -match $guidRx) { $new = $Matches[0] }
        if (-not $new) { throw "Ultimate Performance plan is not available on this PC" }
        powercfg /setactive $new | Out-Null
        if (-not $script:backup.ContainsKey("ultperf")) { $script:backup["ultperf"] = @{ Prev = $prev; New = $new }; Save-Backup }
    }
    Undo = {
        $b = $script:backup["ultperf"]
        if ($b.Prev) { powercfg /setactive $b.Prev | Out-Null }
        if ($b.New) { powercfg /delete $b.New | Out-Null }
    } })
[void]$tweaks.Add(@{ Id = "fngpu"; Cat = "perf"; Plan = 1; Rec = $false; Name = "Fortnite: force high-performance GPU"
    Desc = "Windows setting for Fortnite only. Mainly helps laptops with two GPUs."
    RegsFn = { $e = Get-FortniteExe; if ($e) { @( @{ P = "HKCU:\Software\Microsoft\DirectX\UserGpuPreferences"; N = $e; V = "GpuPreference=2;"; T = "String" } ) } } })
[void]$tweaks.Add(@{ Id = "fnfso"; Cat = "perf"; Plan = 1; Rec = $false; Name = "Fortnite: disable fullscreen optimizations"
    Desc = "Windows compatibility flag for Fortnite only. Some PCs get steadier frametimes."
    RegsFn = { $e = Get-FortniteExe; if ($e) { @( @{ P = "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"; N = $e; V = "~ DISABLEDXMAXIMIZEDWINDOWEDMODE"; T = "String" } ) } } })
[void]$tweaks.Add(@{ Id = "u_amdulps"; Cat = "perf"; Plan = 1; Rec = $false; Name = "AMD: disable ULPS power saving"
    Desc = "Stops AMD cards dropping into ultra-low power state. Fixes clock drops and stutter, mostly with two GPUs. Only changes AMD cards."
    RegsFn = {
        $cls = "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        @(Get-ChildItem -LiteralPath $cls -ErrorAction SilentlyContinue | Where-Object {
            $_.PSChildName -match '^\d{4}$' -and "$((Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue).ProviderName)" -match 'AMD|ATI|Advanced Micro'
        } | ForEach-Object { @{ P = "$cls\$($_.PSChildName)"; N = "EnableUlps"; V = 0; T = "DWord" } })
    } })
[void]$tweaks.Add(@{ Id = "nicpm"; Cat = "net"; Plan = 0; Rec = $true; Name = "Disable network adapter power saving"
    Desc = "Stops Windows sleeping your Wi-Fi or Ethernet card. Helps with ping spikes."
    Apply = {
        $names = @()
        foreach ($a in @(Get-NetAdapter -Physical | Where-Object Status -eq "Up")) {
            $pm = Get-NetAdapterPowerManagement -Name $a.Name
            if ($pm.AllowComputerToTurnOffDevice -eq "Enabled") {
                $names += $a.Name
                Disable-NetAdapterPowerManagement -Name $a.Name -NoRestart
            }
        }
        if (-not $script:backup.ContainsKey("nicpm")) { $script:backup["nicpm"] = @{ Names = $names }; Save-Backup }
    }
    Undo = { foreach ($n in @($script:backup["nicpm"].Names)) { Enable-NetAdapterPowerManagement -Name $n -NoRestart } } })
[void]$tweaks.Add(@{ Id = "dnsflush"; Cat = "net"; Plan = 0; Rec = $true; Name = "Flush DNS cache (one-time)"
    Desc = "Clears cached lookups. Can make the first connections slower, so it is optional."
    Apply = { Clear-DnsClientCache; ipconfig /flushdns | Out-Null } })

[void]$tweaks.Add(@{ Id = "u_nagle"; Cat = "net"; Plan = 2; Rec = $false; Name = "Disable Nagle's algorithm"
    Desc = "Sends small game packets right away instead of bundling them. Can lower ping in some games."
    RegsFn = {
        foreach ($k in @(Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces")) {
            $p = Get-ItemProperty -LiteralPath $k.PSPath
            if ("$($p.DhcpIPAddress)$($p.IPAddress)" -match '\d+\.\d+\.\d+\.\d+') {
                $kp = $k.PSPath -replace '^.*::HKEY_LOCAL_MACHINE', 'HKLM:'
                @{ P = $kp; N = "TcpAckFrequency"; T = "DWord"; V = 1 }
                @{ P = $kp; N = "TCPNoDelay"; T = "DWord"; V = 1 }
            }
        }
    } })
[void]$tweaks.Add(@{ Id = "u_svchost"; Cat = "perf"; Plan = 2; Rec = $false; Name = "Group service hosts by your RAM size"
    Desc = "Fewer svchost processes on PCs with plenty of RAM. Lower background overhead. Needs restart."
    RegsFn = {
        $kb = [int][math]::Min(2147483647, (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1KB)
        @( @{ P = "HKLM:\SYSTEM\CurrentControlSet\Control"; N = "SvcHostSplitThresholdInKB"; T = "DWord"; V = $kb } )
    } })
[void]$tweaks.Add(@{ Id = "u_classicmenu"; Cat = "vis"; Plan = 2; Rec = $false; Name = "Classic right-click menu (Windows 11)"
    Desc = "Brings back the full right-click menu without Show more options. Applies after Explorer restarts."
    Apply = {
        $k = "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}"
        if (-not $script:backup.ContainsKey("u_classicmenu")) { $script:backup["u_classicmenu"] = @{ Existed = (Test-Path -LiteralPath $k) }; Save-Backup }
        New-Item -Path "$k\InprocServer32" -Force | Out-Null
        Set-Item -LiteralPath "$k\InprocServer32" -Value ""
    }
    Undo = {
        $k = "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}"
        if (-not $script:backup["u_classicmenu"].Existed) { Remove-Item -LiteralPath $k -Recurse -Force }
    } })
[void]$tweaks.Add(@{ Id = "u_memcomp"; Cat = "perf"; Plan = 2; Rec = $false; Name = "Disable memory compression"
    Desc = "Saves CPU time spent compressing RAM. Best with 16 GB or more. Needs restart."
    Apply = {
        $on = [bool](Get-MMAgent).MemoryCompression
        if (-not $script:backup.ContainsKey("u_memcomp")) { $script:backup["u_memcomp"] = @{ On = $on }; Save-Backup }
        Disable-MMAgent -MemoryCompression -ErrorAction Stop
    }
    Undo = { if ($script:backup["u_memcomp"].On) { Enable-MMAgent -MemoryCompression } } })
[void]$tweaks.Add(@{ Id = "u_dyntick"; Cat = "perf"; Plan = 2; Rec = $false; Name = "Disable dynamic timer tick"
    Desc = "Keeps the system timer ticking steadily. Some PCs get smoother frame pacing. Uses more idle power. Restart."
    Apply = {
        bcdedit /set disabledynamictick yes | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "bcdedit failed" }
        if (-not $script:backup.ContainsKey("u_dyntick")) { $script:backup["u_dyntick"] = @{ Set = $true }; Save-Backup }
    }
    Undo = { bcdedit /deletevalue disabledynamictick | Out-Null } })
$script:teleTasks = @(
    "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
    "\Microsoft\Windows\Application Experience\ProgramDataUpdater",
    "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
    "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip",
    "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector",
    "\Microsoft\Windows\Feedback\Siuf\DmClient",
    "\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload",
    "\Microsoft\Windows\Windows Error Reporting\QueueReporting",
    "\Microsoft\Windows\Maps\MapsUpdateTask"
)
[void]$tweaks.Add(@{ Id = "u_tasks"; Cat = "priv"; Plan = 2; Rec = $true; Name = "Disable telemetry scheduled tasks"
    Desc = "Turns off 9 background data-collection tasks that can wake up while you play."
    Apply = {
        $done = @()
        foreach ($full in $script:teleTasks) {
            $path = $full.Substring(0, $full.LastIndexOf("\") + 1); $name = $full.Substring($full.LastIndexOf("\") + 1)
            $t = Get-ScheduledTask -TaskPath $path -TaskName $name -ErrorAction SilentlyContinue
            if ($t -and $t.State -ne "Disabled") { Disable-ScheduledTask -InputObject $t | Out-Null; $done += $full }
        }
        if (-not $script:backup.ContainsKey("u_tasks")) { $script:backup["u_tasks"] = @{ Tasks = $done }; Save-Backup }
    }
    Undo = {
        foreach ($full in @($script:backup["u_tasks"].Tasks)) {
            $path = $full.Substring(0, $full.LastIndexOf("\") + 1); $name = $full.Substring($full.LastIndexOf("\") + 1)
            Enable-ScheduledTask -TaskPath $path -TaskName $name | Out-Null
        }
    } })
[void]$tweaks.Add(@{ Id = "u_trim"; Cat = "sys"; Plan = 2; Rec = $false; Name = "TRIM all SSDs now (one-time)"
    Desc = "Tells your SSDs which blocks are free so writes stay fast."
    Apply = { foreach ($v in @(Get-Volume | Where-Object { $_.DriveLetter -and $_.DriveType -eq "Fixed" })) { Optimize-Volume -DriveLetter $v.DriveLetter -ReTrim } } })
[void]$tweaks.Add(@{ Id = "u_wucache"; Cat = "sys"; Plan = 2; Rec = $false; Name = "Clear Windows Update download cache (one-time)"
    Desc = "Deletes old downloaded update files. Frees space and fixes stuck updates."
    Apply = {
        Stop-Service wuauserv, bits -Force
        Remove-Item "$env:SystemRoot\SoftwareDistribution\Download\*" -Recurse -Force
        Start-Service wuauserv, bits
    } })

# Power-plan settings (applied to the active plan while plugged in)
$powDefs = @(
    @("usbsusp", 2, "Disable USB selective suspend", "Keeps USB devices powered so mice and keyboards never sleep (plugged in).", "2a737441-1930-4402-8d77-b2bebba308a3", "48e6b7a6-50f5-4782-a5d4-53bb8f07e226", 0),
    @("aspm", 2, "Turn off PCIe link power saving", "Keeps the GPU and SSD links at full speed (plugged in).", "501a4d13-42af-4429-9fd1-a8218c268e20", "ee12f906-d277-404b-b6da-e5fa1a576df5", 0),
    @("cpumin", 2, "Never let the CPU drop below full speed", "Sets minimum processor state to 100 percent (plugged in). Runs hotter.", "54533251-82be-4824-96c1-47b60b740d00", "893dee8e-2bef-41e0-89c6-b55d0929964c", 100),
    @("hddoff", 1, "Never turn off hard disks", "Stops drives spinning down when idle (plugged in).", "0012ee47-9041-4b5d-9b77-535fba8b1442", "6738e2c4-e8a5-4a42-b16a-e040e769756e", 0),
    @("nosleep", 1, "Never sleep while plugged in", "Disables automatic sleep on AC power.", "238c9fa8-0aad-41ed-83f4-97be242c8f20", "29f6c1db-86da-48c5-9fdb-f2b67b1f44da", 0),
    @("displaynever", 1, "Never turn off the display while plugged in", "Keeps the screen on when idle on AC power.", "7516b95f-f776-4464-8c53-06167f40cc99", "3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e", 0),
    @("wake", 1, "Block wake timers", "Stops scheduled tasks waking the PC from sleep (plugged in).", "238c9fa8-0aad-41ed-83f4-97be242c8f20", "bd3b718a-0680-4d9d-8ab2-e1d2b4ac806d", 0),
    @("u_corepark", 2, "Disable CPU core parking", "Keeps every CPU core awake so games never wait for one to wake up (plugged in).", "54533251-82be-4824-96c1-47b60b740d00", "0cc5b647-c1df-4637-891a-dec35c318583", 100),
    @("u_boost", 2, "Aggressive CPU boost mode", "Lets the CPU boost clocks as hard and as often as it can (plugged in).", "54533251-82be-4824-96c1-47b60b740d00", "be337238-0d82-4146-a960-4f3749d470c7", 2),
    @("u_cooling", 2, "Active cooling policy", "Speeds up fans before slowing the CPU down (plugged in).", "54533251-82be-4824-96c1-47b60b740d00", "94d3a615-a899-4ac5-ae2b-e4d8f634367f", 1),
    @("u_wifipow", 2, "Wi-Fi adapter maximum performance", "Stops Wi-Fi power saving that causes ping spikes (plugged in).", "19cbb8fa-5279-450e-9fac-8a3d5fedd0c1", "12bbebe6-58d6-4636-95bb-3217ef867c1a", 0)
)
foreach ($pd in $powDefs) {
    [void]$tweaks.Add(@{ Id = $pd[0]; Cat = "power"; Plan = [int]$pd[1]; Rec = $false; Name = $pd[2]; Desc = $pd[3]
        Pow = @{ Sub = $pd[4]; Set = $pd[5]; Val = [int]$pd[6] } })
}

$script:tweakById = @{}
foreach ($t in $tweaks) { $script:tweakById[$t.Id] = $t }

# Extra work after a tweak is applied or undone
$afterHooks = @{
    mouse = { $m = Get-ItemProperty "HKCU:\Control Panel\Mouse"; [Native]::SetMouse([int]$m.MouseThreshold1, [int]$m.MouseThreshold2, [int]$m.MouseSpeed) }
}

# ---------- Power-setting engine ----------
function Get-PowerIdx($sub, $set) {
    $o = (powercfg /query SCHEME_CURRENT $sub $set) -join "`n"
    $m = [regex]::Matches($o, "0x([0-9a-fA-F]{8})")
    if ($m.Count -ge 2) { return [Convert]::ToInt32($m[$m.Count - 2].Groups[1].Value, 16) }
    return $null
}
function Apply-Pow($t) {
    $p = $t.Pow
    $prev = Get-PowerIdx $p.Sub $p.Set
    if (-not $script:backup.ContainsKey($t.Id)) { $script:backup[$t.Id] = @{ Prev = $prev; Sub = $p.Sub; Set = $p.Set }; Save-Backup }
    powercfg /setacvalueindex SCHEME_CURRENT $p.Sub $p.Set $p.Val | Out-Null
    powercfg /setactive SCHEME_CURRENT | Out-Null
}
function Undo-Pow($t) {
    $b = $script:backup[$t.Id]
    if ($b.Prev -ne $null) {
        powercfg /setacvalueindex SCHEME_CURRENT $b.Sub $b.Set $b.Prev | Out-Null
        powercfg /setactive SCHEME_CURRENT | Out-Null
    }
}

# ---------- Apply / undo one tweak ----------
function Invoke-TweakApply($t) {
    if ($t.Pow) { Apply-Pow $t }
    elseif ($t.Regs -or $t.RegsFn) {
        $regs = @(if ($t.RegsFn) { & $t.RegsFn } else { $t.Regs })
        $regs = @($regs | Where-Object { $_.P -notlike "*\CurrentControlSet\Services\*" -or (Test-Path -LiteralPath $_.P) })
        if ($regs.Count -eq 0) { Log "  Skipped: $($t.Name) (not present on this PC)"; return }
        Apply-RegList $t.Id $regs
    }
    else { $null = & $t.Apply }
    if ($afterHooks.ContainsKey($t.Id)) { $null = & $afterHooks[$t.Id] }
    Log "  Applied: $($t.Name)"
}
function Invoke-TweakUndo($t) {
    if (-not $script:backup.ContainsKey($t.Id)) { return $false }
    if ($t.Pow) { Undo-Pow $t }
    elseif ($t.Regs -or $t.RegsFn) { Undo-RegList $t.Id }
    elseif ($t.Undo) { $null = & $t.Undo }
    if ($afterHooks.ContainsKey($t.Id)) { $null = & $afterHooks[$t.Id] }
    $script:backup.Remove($t.Id)
    Save-Backup
    Log "  Restored: $($t.Name)"
    return $true
}

# ---------- Themes ----------
$themes = [ordered]@{
    "Purple Haze" = @{ B1A = @(16,14,38);  B1B = @(30,16,62);  B2A = @(8,26,50);  B2B = @(12,10,34); O1 = @(124,92,255); O2 = @(40,200,255); Dot = @(190,175,255); Acc = @(124,92,255); Acc2 = @(90,215,255) }
    "Ocean"       = @{ B1A = @(6,18,38);   B1B = @(8,40,70);   B2A = @(4,30,52);  B2B = @(6,14,30);  O1 = @(30,150,230);  O2 = @(40,220,200); Dot = @(150,220,255); Acc = @(30,150,230);  Acc2 = @(80,230,210) }
    "Sunset"      = @{ B1A = @(36,12,30);  B1B = @(64,18,44);  B2A = @(40,16,26); B2B = @(20,8,24);  O1 = @(255,100,90);  O2 = @(255,170,60); Dot = @(255,190,160); Acc = @(240,95,85);  Acc2 = @(255,180,80) }
    "Matrix"      = @{ B1A = @(4,14,8);    B1B = @(6,30,16);   B2A = @(3,18,10);  B2B = @(2,8,6);    O1 = @(40,200,110);  O2 = @(20,140,80);  Dot = @(120,255,170); Acc = @(36,170,95);  Acc2 = @(140,255,190) }
    "Crimson"     = @{ B1A = @(22,8,10);   B1B = @(50,12,20);  B2A = @(30,10,14); B2B = @(12,6,8);   O1 = @(230,50,70);   O2 = @(150,30,60);  Dot = @(255,150,160); Acc = @(215,45,65);  Acc2 = @(255,130,100) }
    "Obsidian"    = @{ B1A = @(10,8,9);   B1B = @(28,12,15);  B2A = @(18,8,10); B2B = @(6,5,6);   O1 = @(232,38,63);   O2 = @(255,110,70);  Dot = @(255,150,140); Acc = @(226,36,62);  Acc2 = @(255,112,80) }
    "Midnight"    = @{ B1A = @(8,10,24);   B1B = @(14,18,44);  B2A = @(6,12,30);  B2B = @(4,6,16);   O1 = @(70,90,220);   O2 = @(120,60,200); Dot = @(170,185,255); Acc = @(88,110,240);  Acc2 = @(160,120,255) }
    "Synthwave"   = @{ B1A = @(26,8,40);   B1B = @(48,10,64);  B2A = @(14,8,44);  B2B = @(10,4,24);  O1 = @(255,60,170);  O2 = @(60,200,255); Dot = @(255,150,230); Acc = @(240,60,170);  Acc2 = @(70,210,255) }
    "Emerald"     = @{ B1A = @(6,22,20);   B1B = @(8,40,34);   B2A = @(4,26,28);  B2B = @(4,12,12);  O1 = @(30,200,150);  O2 = @(40,170,210); Dot = @(150,255,220); Acc = @(24,170,125);  Acc2 = @(90,230,200) }
    "Gold Rush"   = @{ B1A = @(26,18,6);   B1B = @(44,30,8);   B2A = @(30,20,8);  B2B = @(14,10,4);  O1 = @(255,190,60);  O2 = @(255,120,40); Dot = @(255,220,150); Acc = @(210,145,30);  Acc2 = @(255,215,110) }
    "Arctic"      = @{ B1A = @(10,24,36);  B1B = @(18,40,58);  B2A = @(8,28,44);  B2B = @(6,14,24);  O1 = @(120,200,255); O2 = @(200,230,255); Dot = @(220,240,255); Acc = @(60,150,225);  Acc2 = @(180,230,255) }
    "Toxic"       = @{ B1A = @(14,20,4);   B1B = @(26,38,6);   B2A = @(10,24,6);  B2B = @(6,10,2);   O1 = @(170,255,40);  O2 = @(60,220,90);  Dot = @(210,255,140); Acc = @(110,180,25);  Acc2 = @(200,255,90) }
    "Graphite"    = @{ B1A = @(18,19,23);  B1B = @(30,32,38);  B2A = @(14,15,19); B2B = @(10,10,13); O1 = @(150,155,175); O2 = @(90,100,130);  Dot = @(200,205,220); Acc = @(105,115,155); Acc2 = @(200,205,230) }
}
$styles = [ParticleCanvas]::Styles

# ---------- Palette ----------
$cCard    = [System.Drawing.Color]::FromArgb(28, 30, 44)
$cInner   = [System.Drawing.Color]::FromArgb(18, 19, 29)
$cText    = [System.Drawing.Color]::FromArgb(232, 234, 244)
$cMuted   = [System.Drawing.Color]::FromArgb(150, 155, 180)
$cNeutral = [System.Drawing.Color]::FromArgb(58, 62, 86)
$cGoodBtn = [System.Drawing.Color]::FromArgb(36, 150, 112)
$cGood    = [System.Drawing.Color]::FromArgb(70, 210, 140)
$cWarn    = [System.Drawing.Color]::FromArgb(245, 200, 80)
$cBad     = [System.Drawing.Color]::FromArgb(245, 95, 95)
$script:accent  = Rgb @(124, 92, 255)
$script:accent2 = Rgb @(90, 215, 255)
$fUI    = New-Object System.Drawing.Font("Segoe UI", 10.5)
$fSmall = New-Object System.Drawing.Font("Segoe UI", 8.5)
$fHead  = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
$fBig   = New-Object System.Drawing.Font("Segoe UI Semibold", 15)
$fLogo  = New-Object System.Drawing.Font("Segoe UI Semibold", 13)

$script:accentButtons = New-Object System.Collections.ArrayList
$script:accentLabels  = New-Object System.Collections.ArrayList
$script:navButtons    = New-Object System.Collections.ArrayList
$script:themeButtons  = New-Object System.Collections.ArrayList
$script:pages = @{}
foreach ($p in "dash", "tweaks", "boost", "ping", "dns", "tools", "look", "account", "macros", "log") { $script:pages[$p] = New-Object System.Collections.ArrayList }
$script:checks = @{}
$script:currentPage = ""
$script:sysLoaded = $false

# ---------- UI builders ----------
function New-Label($text, $x, $y, $w, $h, $font, $color, $back) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h); $l.Font = $font
    $l.ForeColor = $color; $l.BackColor = $back; $l.UseMnemonic = $false
    if ($back -eq $cCard) { $l.BackColor = [System.Drawing.Color]::Transparent }
    return $l
}
function New-Heading($text, $x, $y, $card) {
    $l = New-Label $text $x $y 300 18 $fHead $script:accent $cCard
    [void]$script:accentLabels.Add($l); $card.Controls.Add($l)
}
function New-Card($x, $y, $w, $h) {
    $p = New-Object Card
    $p.Location = New-Object System.Drawing.Point($x, $y)
    $p.Size = New-Object System.Drawing.Size($w, $h); $p.BackColor = $cCard
    Set-Rounded $p 16
    return $p
}
function New-Button($label, $x, $y, $w, $h, $role = "neutral") {
    $b = New-Object TButton
    $b.Text = $label
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, $h)
    # Keep radius under half height so shapes stay correct
    $rad = 10
    if ($h -ge 36) { $rad = 12 }
    if ($h -ge 44) { $rad = 14 }
    if ($h -lt 28) { $rad = 8 }
    $b.Radius = $rad
    $col = $cNeutral
    if ($role -eq "accent") { $col = $script:accent; $b.Color2 = $script:accent2 }
    elseif ($role -eq "good") { $col = $cGoodBtn }
    $b.BackColor = $col
    $b.Tag = $col
    $b.Font = $fUI
    $b.Padding = New-Object System.Windows.Forms.Padding(8, 0, 8, 0)
    if ($role -eq "accent") { [void]$script:accentButtons.Add($b) }
    return $b
}
function Add-ToPage($page, $ctrl) {
    $ctrl.Visible = $false
    $canvas.Controls.Add($ctrl)
    [void]$script:pages[$page].Add($ctrl)
}
function New-Slider($card, $label, $y, $min, $max, $val) {
    $card.Controls.Add((New-Label $label 18 ($y + 4) 170 20 $fUI $cText $cCard))
    $tb = New-Object TSlider
    $tb.Minimum = $min; $tb.Maximum = $max; $tb.Value = $val
    $tb.Location = New-Object System.Drawing.Point(190, $y); $tb.Size = New-Object System.Drawing.Size(340, 30)
    $tb.BackColor = $cCard
    $vl = New-Label "" 540 ($y + 4) 80 20 $fUI $cMuted $cCard
    $card.Controls.Add($tb); $card.Controls.Add($vl)
    return @{ Bar = $tb; Val = $vl }
}

# ---------- Window + canvas ----------
$form = New-Object TForm
$form.Text = "TKL Tweaks"
$form.ClientSize = New-Object System.Drawing.Size(880, 640)
$form.MinimumSize = New-Object System.Drawing.Size(980, 640)
$form.StartPosition = "CenterScreen"
$form.MaximizeBox = $true
$form.BackColor = [System.Drawing.Color]::FromArgb(16, 14, 38); $form.Font = $fUI

$canvas = New-Object ParticleCanvas
$canvas.Dock = "Fill"; $canvas.Border = $true
$form.Controls.Add($canvas)

# ---------- Status bar + activity log (created first so Log works) ----------
$statusCard = New-Card 212 584 652 40
$script:statusLbl = New-Label "Ready." 16 11 620 20 $fUI $cMuted $cCard
$statusCard.Controls.Add($script:statusLbl)
$canvas.Controls.Add($statusCard)

$script:logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true; $logBox.ReadOnly = $true; $logBox.ScrollBars = "Vertical"
$logBox.Location = New-Object System.Drawing.Point(14, 14); $logBox.Size = New-Object System.Drawing.Size(624, 424)
$logBox.BackColor = [System.Drawing.Color]::FromArgb(14, 15, 22)
$logBox.ForeColor = [System.Drawing.Color]::FromArgb(160, 230, 185)
$logBox.Font = New-Object System.Drawing.Font("Consolas", 9.5); $logBox.BorderStyle = "None"
$cardLog = New-Card 212 78 652 498
$cardLog.Controls.Add($logBox)
$btnClearLog = New-Button "Clear log" 14 450 120 34
$btnCopyLog  = New-Button "Copy log" 144 450 120 34
$btnClearLog.Add_Click({ $logBox.Clear() })
$btnCopyLog.Add_Click({ if ($logBox.Text) { [System.Windows.Forms.Clipboard]::SetText($logBox.Text) } })
$cardLog.Controls.AddRange(@($btnClearLog, $btnCopyLog))
Add-ToPage "log" $cardLog


# ---------- Brand fonts, plan colours, app icon ----------
$fUIb   = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
$fBrand = New-Object System.Drawing.Font("Segoe UI Black", 20)
$fHello = New-Object System.Drawing.Font("Segoe UI Semibold", 17)
$fPlanT = New-Object System.Drawing.Font("Segoe UI Semibold", 14)
$planCol  = @((Rgb @(80, 210, 140)), (Rgb @(255, 190, 55)), (Rgb @(230, 70, 80)))
$planName = @("Free", "Premium", "Ultimate")
$script:planIdx = 0

function New-AppIcon {
    $bmp = New-Object System.Drawing.Bitmap(64, 64)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = "AntiAlias"
    $rc = New-Object System.Drawing.Rectangle(0, 0, 64, 64)
    $br = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rc, $script:accent, $script:accent2, 45.0)
    $g.FillEllipse($br, 2, 2, 60, 60)
    $f = New-Object System.Drawing.Font("Segoe UI", 22, [System.Drawing.FontStyle]::Bold)
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = "Center"; $sf.LineAlignment = "Center"
    $rf = New-Object System.Drawing.RectangleF(0, 0, 64, 64)
    $g.DrawString("T", $f, [System.Drawing.Brushes]::White, $rf, $sf)
    $g.Dispose()
    return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
}
$form.Icon = New-AppIcon
$form.Add_Shown({
    [NativeUi]::DarkTitle($form.Handle)
    [NativeUi]::CaptionColor($form.Handle, $canvas.C1A.R, $canvas.C1A.G, $canvas.C1A.B)
    Layout-Main
})

# ---------- Sidebar ----------
$sidebar = New-Card 16 16 180 608
$lblBrand = New-Label "TKL" 16 10 150 38 $fBrand $script:accent $cCard
[void]$script:accentLabels.Add($lblBrand)
$sidebar.Controls.Add($lblBrand)
$sidebar.Controls.Add((New-Label ("TWEAKS   v" + $TKL.Version) 18 48 150 16 $fSmall $cMuted $cCard))
$canvas.Controls.Add($sidebar)

# Borderless window: min / maximize / close (+ F11 fullscreen)
# Caption buttons — Segoe MDL2 icons (real Windows min/max/close glyphs)
$winCard = New-Object Card
$winCard.Location = New-Object System.Drawing.Point(790, 10)
$winCard.Size = New-Object System.Drawing.Size(126, 38)
$winCard.BackColor = [System.Drawing.Color]::FromArgb(255, 24, 26, 40)
$winCard.Opacity = 255
$winCard.Radius = 10
$winCard.BorderColor = [System.Drawing.Color]::FromArgb(50, 54, 72)
Set-Rounded $winCard 10
$capBg = [System.Drawing.Color]::FromArgb(255, 24, 26, 40)
$capFg = [System.Drawing.Color]::FromArgb(230, 235, 245)
$btnMin = New-Button "" 5 3 36 32 "neutral"
$btnMin.Text = ""; $btnMin.Glyph = [string][char]0xE921
$btnMin.BackColor = $capBg; $btnMin.Tag = $capBg; $btnMin.ForeColor = $capFg
$btnMin.Radius = 8; $btnMin.TabStop = $false
$btnMax = New-Button "" 45 3 36 32 "neutral"
$btnMax.Text = ""; $btnMax.Glyph = [string][char]0xE922
$btnMax.BackColor = $capBg; $btnMax.Tag = $capBg; $btnMax.ForeColor = $capFg
$btnMax.Radius = 8; $btnMax.TabStop = $false
$btnX = New-Button "" 85 3 36 32 "neutral"
$btnX.Text = ""; $btnX.Glyph = [string][char]0xE8BB
$btnX.BackColor = $capBg; $btnX.Tag = $capBg; $btnX.ForeColor = $capFg
$btnX.Radius = 8; $btnX.TabStop = $false
$btnX.HoverColor = [System.Drawing.Color]::FromArgb(200, 48, 58)
$script:isFullscreen = $false
$script:restoreBounds = $null
$script:layoutBusy = $false
function Layout-Main {
    if ($script:layoutBusy) { return }
    if ($form.WindowState -eq "Minimized") { return }
    $script:layoutBusy = $true
    try {
        $w = $form.ClientSize.Width; $h = $form.ClientSize.Height
        if ($w -lt 400 -or $h -lt 300) { return }
        $winCard.Left = [math]::Max(0, $w - $winCard.Width - 14)
        $winCard.Top = 12
        $winCard.BringToFront()
        $sidebar.Height = [math]::Max(400, $h - 32)
        Set-Rounded $sidebar 16
        foreach ($c in @($canvas.Controls)) {
            if ($c -isnot [Card]) { continue }
            if ($c -eq $sidebar -or $c -eq $winCard) { continue }
            if ($c.Left -lt 200) { continue }
            $c.Width = [math]::Max(400, $w - $c.Left - 16)
            if ($statusCard -and [object]::ReferenceEquals($c, $statusCard)) {
                $c.Top = [math]::Max(40, $h - $c.Height - 14)
            } elseif ($c.Height -gt 250) {
                $c.Height = [math]::Max(180, $h - $c.Top - 56)
            }
            Set-Rounded $c 16
        }
        if (Get-Command Layout-PlanCards -ErrorAction SilentlyContinue) { Layout-PlanCards }
        $canvas.Invalidate($true)
    } finally { $script:layoutBusy = $false }
}
function Set-WindowNormal {
    $script:isFullscreen = $false
    if ($script:restoreBounds) {
        $form.WindowState = "Normal"
        $form.Bounds = $script:restoreBounds
    } else {
        $form.WindowState = "Normal"
    }
    $btnMax.Glyph = [string][char]0xE922
    Layout-Main
}
function Toggle-Maximize {
    if ($script:isFullscreen) {
        Set-WindowNormal
        return
    }
    if ($form.WindowState -eq "Maximized") {
        Set-WindowNormal
    } else {
        # Borderless maximize: use working area (keeps taskbar visible)
        $script:restoreBounds = $form.Bounds
        $wa = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
        $form.WindowState = "Normal"
        $form.Bounds = $wa
        $btnMax.Glyph = [string][char]0xE923
        Layout-Main
    }
}
function Toggle-Fullscreen {
    if ($script:isFullscreen) {
        Set-WindowNormal
    } else {
        if (-not $script:restoreBounds -or $form.WindowState -eq "Normal") {
            $script:restoreBounds = $form.Bounds
        }
        $script:isFullscreen = $true
        $form.WindowState = "Normal"
        $form.Bounds = [System.Windows.Forms.Screen]::FromControl($form).Bounds
        $btnMax.Glyph = [string][char]0xE923
        Layout-Main
    }
}
$btnMin.Add_Click({
    $form.WindowState = "Minimized"
})
$btnMax.Add_Click({ Toggle-Maximize })
$btnX.Add_Click({ $form.Close() })
$form.KeyPreview = $true
$form.Add_KeyDown({
    if ($_.KeyCode -eq "F11") { Toggle-Fullscreen; $_.Handled = $true }
    elseif ($_.KeyCode -eq "Escape" -and $script:isFullscreen) { Toggle-Fullscreen; $_.Handled = $true }
})
$form.Add_Resize({
    if ($form.WindowState -eq "Minimized") { return }
    Layout-Main
})
$winCard.Controls.AddRange(@($btnMin, $btnMax, $btnX))
$canvas.Controls.Add($winCard)

$pageMeta = [ordered]@{
    dash    = @{ Label = "Dashboard";        T = "Dashboard";        S = "Your plan, your tweaks and quick actions" }
    tweaks  = @{ Label = "Tweaks";           T = "Tweaks";           S = "Browse, search and apply tweaks - every one can be undone" }
    boost   = @{ Label = "Game Boost";       T = "Game Boost and GPU"; S = "Max FPS mode and NVIDIA / AMD graphics card optimizers" }
    ping    = @{ Label = "Latency Test";     T = "Latency Test";     S = "Measure ping, jitter and packet loss - test before and after tweaks" }
    dns     = @{ Label = "DNS and Repair";   T = "DNS and Repair";   S = "Switch DNS servers and fix common network problems" }
    tools   = @{ Label = "Tools and System"; T = "Tools and System"; S = "System info, quick settings and cleanup" }
    look    = @{ Label = "Appearance";       T = "Appearance";       S = "Themes, animated backgrounds and custom images" }
    account = @{ Label = "Account";          T = "Account";          S = "Sign in, manage your license and upgrade your plan" }
    macros  = @{ Label = "Macros";           T = "Macro Library";    S = "Build, run and share your own one-click macros" }
    log     = @{ Label = "Activity Log";     T = "Activity Log";     S = "Everything the app has done this session" }
}
function Update-Nav {
    foreach ($b in $script:navButtons) {
        if ($b.Name -eq $script:currentPage) { $b.Tag = $script:accent; $b.ForeColor = [System.Drawing.Color]::White }
        else { $b.Tag = $cCard; $b.ForeColor = $cMuted }
        $b.BackColor = $b.Tag
    }
}
function Select-Page($name) {
    $script:currentPage = $name
    [NativeUi]::Redraw($canvas, $false)
    try {
        foreach ($k in $script:pages.Keys) {
            foreach ($c in $script:pages[$k]) { $c.Visible = ($k -eq $name) }
        }
        $canvas.PageTitle = $pageMeta[$name].T
        $canvas.PageSubtitle = $pageMeta[$name].S
        Update-Nav
    } finally { [NativeUi]::Redraw($canvas, $true) }
    if ($name -eq "dns") { $script:dnsNow.Text = "Current DNS: " + (Get-CurrentDns) }
    if ($name -eq "tools" -and -not $script:sysLoaded) { Load-SysInfo }
    if ($name -eq "dash") { Refresh-Dashboard }
    if ($name -eq "boost") { Load-GpuInfo }
    $canvas.Invalidate()
}

$navGlyph = @{ dash = 0xE80F; tweaks = 0xE9E9; boost = 0xE7FC; ping = 0xEC05; dns = 0xE968; tools = 0xE90F; look = 0xE790; account = 0xE77B; macros = 0xE945; log = 0xE81C }
$ny = 78
foreach ($k in $pageMeta.Keys) {
    $b = New-Button $pageMeta[$k].Label 12 $ny 156 34 "neutral"
    $b.Name = $k; $b.TextAlign = "MiddleLeft"; $b.Glyph = [string][char]$navGlyph[$k]
    $b.Radius = 12
    $b.Padding = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
    $b.Add_Click({ Select-Page $this.Name })
    $sidebar.Controls.Add($b); [void]$script:navButtons.Add($b)
    $ny += 36
}

$chkRestore = New-Object TToggle
$chkRestore.Font = $fSmall; $chkRestore.Text = "Restore point first"; $chkRestore.Checked = $true; $chkRestore.AutoSize = $true
$chkRestore.Location = New-Object System.Drawing.Point(16, 412)
$chkRestore.ForeColor = $cText; $chkRestore.BackColor = $cCard; $chkRestore.Cursor = "Hand"
$sidebar.Controls.Add($chkRestore)
$script:selLbl = New-Label "0 selected" 17 440 150 16 $fSmall $cMuted $cCard
$sidebar.Controls.Add($script:selLbl)
$btnApply = New-Button "Apply Selected" 16 462 148 42 "accent"
$btnUndo  = New-Button "Undo All" 16 510 148 34 "neutral"
$sidebar.Controls.AddRange(@($btnApply, $btnUndo))
$sidebar.Controls.Add((New-Label "SIGNED IN AS" 17 554 150 14 $fSmall $cMuted $cCard))
$script:sbUser = New-Label "Guest" 17 569 150 20 $fUIb $cText $cCard
$script:sbPlan = New-Label "FREE PLAN" 17 589 150 18 $fHead $cGood $cCard
$sidebar.Controls.AddRange(@($script:sbUser, $script:sbPlan))

# ---------- Page: Dashboard ----------
$cardWelcome = New-Card 212 78 652 150
$script:dashHello = New-Label "Welcome" 22 16 430 30 $fHello $cText $cCard
$script:dashPlan  = New-Label "FREE PLAN" 22 52 430 18 $fHead $cGood $cCard
$script:dashStats = New-Label "" 22 76 420 20 $fUI $cMuted $cCard
$script:dashRatio = 0.0
$dashBar = New-Object BufferedPanel
$dashBar.Location = New-Object System.Drawing.Point(22, 108); $dashBar.Size = New-Object System.Drawing.Size(410, 12)
$dashBar.BackColor = $cCard
Set-Rounded $dashBar 6
$dashBar.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $tb = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(48, 51, 72))
    $g.FillRectangle($tb, 0, 0, $s.Width, $s.Height); $tb.Dispose()
    $w = [int]($s.Width * $script:dashRatio)
    if ($w -gt 0) {
        $fb = New-Object System.Drawing.SolidBrush($planCol[$script:planIdx])
        $g.FillRectangle($fb, 0, 0, $w, $s.Height); $fb.Dispose()
    }
})
$btnDashApply   = New-Button "Optimize Now" 460 18 170 70 "accent"
$btnDashApply.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11); $btnDashApply.Glyph = [string][char]0xE945
$btnDashBrowse  = New-Button "Tweaks" 460 96 80 34 "neutral"
$btnDashLicense = New-Button "License" 548 96 82 34 "neutral"
foreach ($rb in @($btnDashApply, $btnDashBrowse, $btnDashLicense)) { $rb.Anchor = "Top, Right" }
$script:dashChips = New-Label "" 22 126 420 16 $fSmall $cGood $cCard
$cardWelcome.Controls.AddRange(@($script:dashChips, $script:dashHello, $script:dashPlan, $script:dashStats, $dashBar, $btnDashApply, $btnDashBrowse, $btnDashLicense))
Add-ToPage "dash" $cardWelcome

$planFeatures = @(
    "Core gaming, input and Explorer tweaks`nPrivacy and notification cleanup`nLatency test, DNS and cleanup tools",
    "Everything in Free`nAdvanced GPU, scheduler and network`nDeeper privacy, Edge and system options",
    "Everything in Premium`nService tuning and power plans`nSecurity hardening and advanced policies"
)
$script:planCards = @()
for ($i = 0; $i -lt 3; $i++) {
    $pc = New-Card (212 + $i * 222) 248 208 210
    $pc.Name = "planCard$i"
    $pc.BorderColor = $planCol[$i]
    $title = New-Label $planName[$i] 16 14 176 28 $fPlanT $planCol[$i] $cCard
    $cnt = New-Label "" 16 48 176 22 $fUIb $cText $cCard
    $feat = New-Label $planFeatures[$i] 16 78 176 90 $fSmall $cMuted $cCard
    $st = New-Label "" 16 176 176 20 $fHead $cMuted $cCard
    $pc.Controls.AddRange(@($title, $cnt, $feat, $st))
    Add-ToPage "dash" $pc
    $script:planCards += @{ Card = $pc; Cnt = $cnt; Status = $st; Title = $title }
}
$cardTipsD = New-Card 212 474 652 124
New-Heading "GOOD TO KNOW" 18 12 $cardTipsD
$cardTipsD.Controls.Add((New-Label ("Every tweak is backed up before it is applied. Use Undo All to restore your original settings.`n" +
    "Restart Windows after applying for the changes to fully take effect.`n" +
    "Run a latency test before and after to measure the difference on your own PC.") 18 40 616 74 $fUI $cText $cCard))
Add-ToPage "dash" $cardTipsD

# ---------- Page: Tweaks ----------
$cardTw = New-Card 212 78 652 498
$searchBox = New-Object System.Windows.Forms.TextBox
$searchBox.Location = New-Object System.Drawing.Point(16, 16); $searchBox.Size = New-Object System.Drawing.Size(230, 26)
$searchBox.BackColor = $cInner; $searchBox.ForeColor = $cText; $searchBox.Font = $fUI; $searchBox.BorderStyle = "FixedSingle"
$catDefs = [ordered]@{ perf = "Gaming and Performance"; net = "Network"; input = "Input and Peripherals"; vis = "Visual and UI"
    expl = "Explorer and Files"; priv = "Privacy"; sys = "System and Services"; power = "Power"; sec = "Security"
    edge = "Edge and Apps"; notif = "Notifications" }
$catIds = @($catDefs.Keys)
$catCount = @{}
foreach ($t in $tweaks) { if ($catCount.ContainsKey($t.Cat)) { $catCount[$t.Cat] = $catCount[$t.Cat] + 1 } else { $catCount[$t.Cat] = 1 } }
$latRx = 'latenc|ping|\blag\b|delay|timer|nagle|interrupt|responsiv|packet|throttl|mouse|keyboard|queue|polling|stutter|input'
$latSet = New-Object 'System.Collections.Generic.Dictionary[string,bool]'
foreach ($t in $tweaks) { if ("$($t.Name) $($t.Desc)" -match $latRx) { $latSet[$t.Id] = $true } }
$catCount["lat"] = $latSet.Count
$tabDefs = @(@("all", "All"), @("perf", "FPS"), @("lat", "Latency"), @("net", "Network"), @("input", "Input"), @("vis", "Visuals"),
    @("expl", "Explorer"), @("priv", "Privacy"), @("sys", "System"), @("power", "Power"), @("sec", "Security"), @("edge", "Apps"), @("notif", "Alerts"))
$tabStrip = New-Object TabStrip
$tabStrip.Location = New-Object System.Drawing.Point(8, 52); $tabStrip.Size = New-Object System.Drawing.Size(636, 34)
$tabStrip.BackColor = $cCard; $tabStrip.ForeColor = $cText; $tabStrip.MutedColor = $cMuted; $tabStrip.Font = $fUI
foreach ($td in $tabDefs) {
    $n = $tweaks.Count; if ($td[0] -ne "all") { $n = [int]$catCount[$td[0]] }
    if ($td[0] -eq "all" -or $n -gt 0) { $tabStrip.AddTab($td[0], $td[1], $n) }
}
$planBox = New-Object DarkCombo
$planBox.DropDownStyle = "DropDownList"; $planBox.FlatStyle = "Flat"
$planBox.Location = New-Object System.Drawing.Point(486, 16); $planBox.Size = New-Object System.Drawing.Size(144, 28)
$planBox.BackColor = $cInner; $planBox.ForeColor = $cText; $planBox.Font = $fUI
[void]$planBox.Items.AddRange(@("All plans", "Free", "Premium", "Ultimate"))

$tweakList = New-Object TweakList
$tweakList.Location = New-Object System.Drawing.Point(8, 94); $tweakList.Size = New-Object System.Drawing.Size(636, 354)
$tweakList.IdSet = $latSet
$tweakList.CardBg = $cCard; $tweakList.BackColor = $cCard; $tweakList.Accent = $script:accent
foreach ($t in $tweaks) { $tweakList.Add($t.Id, $t.Cat, $t.Name, $t.Desc, [int]$t.Plan, [bool]$t.Rec) }
$tweakList.SetUserPlan($script:planIdx)
$tweakList.Refilter()

$script:listInfo = New-Label "" 380 464 254 20 $fSmall $cMuted $cCard
$script:listInfo.TextAlign = "MiddleRight"
$btnRec  = New-Button "Recommended" 16 458 130 40 "neutral"
$btnAll  = New-Button "Select all" 156 458 100 40 "neutral"
$btnNone = New-Button "Clear" 266 458 92 40 "neutral"
$btnRec.Name = "rec"; $btnAll.Name = "all"; $btnNone.Name = "none"
foreach ($mb in @($btnRec, $btnAll, $btnNone)) { $mb.Font = $fSmall; $mb.Add_Click({ $tweakList.SelectVisible($this.Name) }) }
$cardTw.Controls.AddRange(@($searchBox, $tabStrip, $planBox, $tweakList, $btnRec, $btnAll, $btnNone, $script:listInfo))
Add-ToPage "tweaks" $cardTw
[NativeUi]::Cue($searchBox.Handle, "Search tweaks...")

function Update-ListInfo {
    $script:listInfo.Text = "Showing $($tweakList.VisibleCount) of $($tweakList.TotalCount)   |   $($tweakList.CheckedCount) selected"
    $script:selLbl.Text = "$($tweakList.CheckedCount) selected"
}
function Apply-ListFilter {
    $tweakList.Search = $searchBox.Text
    $tweakList.Category = $tabStrip.SelectedKey
    $pi = [math]::Max(0, $planBox.SelectedIndex)
    $tweakList.PlanFilter = @("all", "free", "premium", "ultimate")[$pi]
    $tweakList.Refilter()
    Update-ListInfo
}
$planBox.SelectedIndex = 0
$searchBox.Add_TextChanged({ Apply-ListFilter })
$tabStrip.Add_SelectedChanged({ Apply-ListFilter })
$planBox.Add_SelectedIndexChanged({ Apply-ListFilter })
$tweakList.Add_CheckChanged({ Update-ListInfo })
$tweakList.Add_LockedClicked({
    $id = $tweakList.LastId
    $need = $tweakList.PlanOf($id); $nm = $tweakList.NameOf($id)
    Log "$nm needs the $($planName[$need]) plan."
    $r = [System.Windows.Forms.MessageBox]::Show("'$nm' is part of the $($planName[$need]) plan.`n`nOpen the Account page to enter a license key?",
        "TKL Tweaks", "YesNo", "Information")
    if ($r -eq "Yes") { Select-Page "account" }
})

# ---------- Page: DNS and Repair ----------
$cardDns = New-Card 212 78 652 170
New-Heading "DNS SERVER" 18 12 $cardDns
$dnsProviders = [ordered]@{
    "Automatic (ISP default)" = $null
    "Cloudflare (1.1.1.1)"    = @("1.1.1.1", "1.0.0.1")
    "Google (8.8.8.8)"        = @("8.8.8.8", "8.8.4.4")
    "Quad9 (9.9.9.9)"         = @("9.9.9.9", "149.112.112.112")
    "OpenDNS"                 = @("208.67.222.222", "208.67.220.220")
}
$dnsBox = New-Object DarkCombo
$dnsBox.DropDownStyle = "DropDownList"; $dnsBox.FlatStyle = "Flat"
$dnsBox.Location = New-Object System.Drawing.Point(18, 40); $dnsBox.Size = New-Object System.Drawing.Size(300, 28)
$dnsBox.BackColor = $cInner; $dnsBox.ForeColor = $cText; $dnsBox.Font = $fUI
foreach ($k in $dnsProviders.Keys) { [void]$dnsBox.Items.Add($k) }
$dnsBox.SelectedIndex = 1
$btnDns = New-Button "Apply DNS" 330 38 130 40 "accent"
$script:dnsNow = New-Label "Current DNS: ..." 18 82 600 18 $fUI $cMuted $cCard
$dnsNote = New-Label "DNS only speeds up looking up servers (sign-in, matchmaking). It does not change in-game ping. Choose Automatic to undo." 18 108 616 44 $fSmall $cMuted $cCard
$cardDns.Controls.AddRange(@($dnsBox, $btnDns, $script:dnsNow, $dnsNote))
Add-ToPage "dns" $cardDns
function Get-CurrentDns {
    $a = Get-NetAdapter -Physical | Where-Object Status -eq "Up" | Select-Object -First 1
    if (-not $a) { return "n/a" }
    $d = (Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4).ServerAddresses
    if ($d) { return ($d -join ", ") } else { return "automatic" }
}
$btnDns.Add_Click({
    $addr = $dnsProviders[$dnsBox.SelectedItem]
    foreach ($a in @(Get-NetAdapter -Physical | Where-Object Status -eq "Up")) {
        if ($addr) { Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ServerAddresses $addr }
        else { Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ResetServerAddresses }
    }
    Clear-DnsClientCache
    Log "DNS set to: $($dnsBox.SelectedItem)"
    $script:dnsNow.Text = "Current DNS: " + (Get-CurrentDns)
})

$cardRep = New-Card 212 260 652 190
New-Heading "NETWORK REPAIR" 18 12 $cardRep
$repair = [ordered]@{
    "Flush DNS cache"                      = { Clear-DnsClientCache; ipconfig /flushdns | Out-Null; "DNS cache flushed." }
    "Renew IP address"                     = { ipconfig /release | Out-Null; ipconfig /renew | Out-Null; "IP address renewed." }
    "Reset Winsock (restart needed)"       = { netsh winsock reset | Out-Null; "Winsock reset - restart Windows to finish." }
    "Reset TCP/IP stack (restart needed)"  = { netsh int ip reset | Out-Null; "TCP/IP stack reset - restart Windows to finish." }
}
$ri = 0
foreach ($k in $repair.Keys) {
    $rx = 18 + (($ri % 2) * 312); $ry = 40 + ([math]::Floor($ri / 2) * 48)
    $rb = New-Button $k $rx $ry 300 38 "neutral"
    $rb.Name = $k
    $rb.Add_Click({
        $form.Cursor = "WaitCursor"
        try { $msg = & $repair[$this.Name]; Log $msg } catch { Log "That action failed." }
        $form.Cursor = "Default"
    })
    $cardRep.Controls.Add($rb); $ri++
}
$cardRep.Controls.Add((New-Label "Renewing your IP briefly drops the connection. Use the resets only if you have network problems." 18 140 616 36 $fSmall $cMuted $cCard))
Add-ToPage "dns" $cardRep

# ---------- Page: Account ----------
$cardAcc = New-Card 212 78 652 190
New-Heading "ACCOUNT" 18 12 $cardAcc
$script:accName = New-Label "Guest" 18 40 500 28 $fPlanT $cText $cCard
$script:accPlan = New-Label "Free plan" 18 72 500 20 $fUIb $cMuted $cCard
$script:accNote = New-Label "" 18 98 616 36 $fSmall $cMuted $cCard
$btnSignIn  = New-Button "Sign in / Switch account" 18 144 210 40 "accent"
$btnSignOut = New-Button "Sign out" 238 144 120 40 "neutral"
$chkKeep = New-Object TToggle
$chkKeep.Text = "Keep me signed in"; $chkKeep.AutoSize = $true; $chkKeep.Checked = [bool]$script:acct.Auto
$chkKeep.Location = New-Object System.Drawing.Point(376, 152); $chkKeep.ForeColor = $cText; $chkKeep.BackColor = $cCard; $chkKeep.Cursor = "Hand"
$cardAcc.Controls.AddRange(@($script:accName, $script:accPlan, $script:accNote, $btnSignIn, $btnSignOut, $chkKeep))
Add-ToPage "account" $cardAcc

$cardLic = New-Card 212 280 652 170
New-Heading "LICENSE" 18 12 $cardLic
$keyBox = New-Object System.Windows.Forms.TextBox
$keyBox.Location = New-Object System.Drawing.Point(18, 44); $keyBox.Size = New-Object System.Drawing.Size(420, 28)
$keyBox.BackColor = $cInner; $keyBox.ForeColor = $cText; $keyBox.BorderStyle = "FixedSingle"
$keyBox.Font = New-Object System.Drawing.Font("Consolas", 11)
$btnAct = New-Button "Activate" 450 42 170 40 "accent"
$script:licMsg = New-Label "Enter a Premium or Ultimate license key." 18 84 616 20 $fUI $cMuted $cCard
$btnRemove = New-Button "Remove license" 18 118 150 40 "neutral"
$cardLic.Controls.AddRange(@($keyBox, $btnAct, $script:licMsg, $btnRemove))
$cardLic.Controls.Add((New-Label "Keys look like TKL-PR-XXXX-XXXX-XXXXXXXX and unlock your plan on the account you are signed in to." 180 126 456 32 $fSmall $cMuted $cCard))
Add-ToPage "account" $cardLic
[NativeUi]::Cue($keyBox.Handle, "TKL-XX-XXXX-XXXX-XXXXXXXX")

$cardAbout = New-Card 212 462 652 114
New-Heading "ABOUT" 18 12 $cardAbout
$cardAbout.Controls.Add((New-Label ($TKL.Brand + " v" + $TKL.Version + "`nSettings, backups and your account are stored in: " + $dataDir + "`nEvery tweak is backed up before it is applied and can be undone.") 18 38 616 66 $fUI $cText $cCard))
Add-ToPage "account" $cardAbout

# ---------- Session handling ----------
function Refresh-Dashboard {
    $p = $script:planIdx
    $script:dashHello.Text = "Welcome, $($script:user)"
    $script:dashPlan.Text = ($planName[$p].ToUpper() + " PLAN")
    $script:dashPlan.ForeColor = $planCol[$p]
    $tot = $tweakList.TotalCount; $unl = $tweakList.UnlockedCount
    $script:dashStats.Text = "$unl of $tot tweaks unlocked   |   $($tweakList.AppliedCount) applied"
    $recN = @($tweaks | Where-Object { $_.Rec -and $_.Plan -le $script:planIdx }).Count
    $script:dashChips.Text = "BACKUP FIRST   " + [char]0x2022 + "   100% REVERSIBLE   " + [char]0x2022 + "   $recN RECOMMENDED FOR YOUR PLAN"
    if ($tot -gt 0) { $script:dashRatio = $unl / $tot } else { $script:dashRatio = 0.0 }
    $dashBar.Invalidate()
    for ($i = 0; $i -lt 3; $i++) {
        $pc = $script:planCards[$i]
        $pc.Cnt.Text = "$($tweakList.PlanCount($i)) tweaks"
        if ($i -eq $p) { $pc.Status.Text = "YOUR PLAN"; $pc.Status.ForeColor = $planCol[$i] }
        elseif ($i -lt $p) { $pc.Status.Text = "INCLUDED"; $pc.Status.ForeColor = $cMuted }
        else { $pc.Status.Text = "LOCKED"; $pc.Status.ForeColor = $cMuted }
    }
    $script:sbUser.Text = $script:user
    $script:sbPlan.Text = ($planName[$p].ToUpper() + " PLAN"); $script:sbPlan.ForeColor = $planCol[$p]
    $script:accName.Text = $script:user
    $script:accPlan.Text = $planName[$p] + " plan"; $script:accPlan.ForeColor = $planCol[$p]
    if ($script:user -eq "Guest") { $script:accNote.Text = "Guest mode uses the Free plan. Sign in or create an account to use a license." }
    elseif ($p -eq 0) { $script:accNote.Text = "You are on the Free plan. Enter a license key below to unlock Premium or Ultimate." }
    else { $script:accNote.Text = "Your license is active. Thank you for supporting $($TKL.Brand)." }
}
function Set-Session($user, $plan) {
    $script:user = $user
    $script:planIdx = [int]$plan
    $tweakList.SetUserPlan([int]$plan)
    Refresh-Dashboard
    Update-ListInfo
}
function Complete-Login($r) {
    $script:acct.Auto = [bool]$r.Keep
    $chkKeep.Checked = [bool]$r.Keep
    Save-Account
    $script:user = $r.User
    Set-Session $r.User (Get-AccountPlan)
}
$btnSignIn.Add_Click({
    $r = Show-Login $false
    if ($r) { Complete-Login $r; Log "Signed in as $($script:user)." }
})
$btnSignOut.Add_Click({
    $script:acct.Auto = $false; Save-Account
    Set-Session "Guest" (Get-AccountPlan)
    Log "Signed out."
})
$chkKeep.Add_CheckedChanged({ if ($script:user -ne "Guest") { $script:acct.Auto = $chkKeep.Checked; Save-Account } })
$btnAct.Add_Click({
    if ($script:user -eq "Guest") { $script:licMsg.ForeColor = $cBad; $script:licMsg.Text = "Sign in or create an account first."; return }
    $res = Invoke-Activate $keyBox.Text
    if ($res.Ok) {
        $script:acct.Key = $keyBox.Text.Trim().ToUpper()
        if ($TKL.ApiUrl) { $script:acct.ServerPlan = $res.Plan }
        Save-Account
        Set-Session $script:user (Get-AccountPlan)
        $script:licMsg.ForeColor = $cGood
        $script:licMsg.Text = "$($res.Msg) You are now on the $($planName[$script:planIdx]) plan."
        Log "License activated: $($planName[$script:planIdx]) plan."
    } else { $script:licMsg.ForeColor = $cBad; $script:licMsg.Text = $res.Msg }
})
$btnRemove.Add_Click({
    $script:acct.Key = ""; $script:acct.ServerPlan = 0; Save-Account
    Set-Session $script:user (Get-AccountPlan)
    $script:licMsg.ForeColor = $cMuted; $script:licMsg.Text = "License removed."
    Log "License removed."
})
$btnDashBrowse.Add_Click({ Select-Page "tweaks" })
$btnDashLicense.Add_Click({ Select-Page "account" })

# ---------- Page: Latency Test ----------
$cardPing = New-Card 212 78 652 330
$hostBox = New-Object DarkCombo
$hostBox.DropDownStyle = "DropDown"; $hostBox.FlatStyle = "Flat"
$hostBox.Location = New-Object System.Drawing.Point(18, 20); $hostBox.Size = New-Object System.Drawing.Size(290, 28)
$hostBox.BackColor = $cInner; $hostBox.ForeColor = $cText; $hostBox.Font = $fUI
[void]$hostBox.Items.AddRange(@("1.1.1.1", "8.8.8.8", "192.168.1.1", "192.168.0.1"))
$hostBox.Text = "1.1.1.1"
$btnPing   = New-Button "Run Test" 320 18 130 40 "good"
$btnRouter = New-Button "My Router" 460 18 130 40 "neutral"
$cardPing.Controls.AddRange(@($hostBox, $btnPing, $btnRouter))
$capX = 18
foreach ($cap in @("AVERAGE", "MIN / MAX", "JITTER", "PACKET LOSS")) {
    $cardPing.Controls.Add((New-Label $cap $capX 66 150 16 $fSmall $cMuted $cCard)); $capX += 158
}
$script:statAvg    = New-Label "-" 18  84 150 30 $fBig $cText $cCard
$script:statMinMax = New-Label "-" 176 84 150 30 $fBig $cText $cCard
$script:statJitter = New-Label "-" 334 84 150 30 $fBig $cText $cCard
$script:statLoss   = New-Label "-" 492 84 150 30 $fBig $cText $cCard
$cardPing.Controls.AddRange(@($script:statAvg, $script:statMinMax, $script:statJitter, $script:statLoss))

$script:pingCount = 20
$script:sparkVals = New-Object System.Collections.ArrayList
$spark = New-Object BufferedPanel
$spark.Location = New-Object System.Drawing.Point(18, 128); $spark.Size = New-Object System.Drawing.Size(616, 184)
$spark.BackColor = $cInner
Set-Rounded $spark 10
$spark.Add_Paint({
    param($s, $e)
    $g = $e.Graphics; $g.SmoothingMode = "AntiAlias"
    $vals = $script:sparkVals
    if ($vals.Count -lt 2) {
        $br = New-Object System.Drawing.SolidBrush($cMuted)
        $g.DrawString("Run a test to see your ping graph", $fUI, $br, 16, 80)
        $br.Dispose(); return
    }
    $max = [math]::Max(50, ($vals | Measure-Object -Maximum).Maximum * 1.25)
    $w = $s.Width - 24; $h = $s.Height - 28
    $pts = New-Object 'System.Collections.Generic.List[System.Drawing.PointF]'
    for ($i = 0; $i -lt $vals.Count; $i++) {
        $x = 12 + ($w * $i / ($script:pingCount - 1))
        $y = 14 + $h - ($h * $vals[$i] / $max)
        $pts.Add((New-Object System.Drawing.PointF($x, $y)))
    }
    $area = New-Object 'System.Collections.Generic.List[System.Drawing.PointF]'
    $area.AddRange($pts)
    $area.Add((New-Object System.Drawing.PointF($pts[$pts.Count - 1].X, [single]($s.Height - 6))))
    $area.Add((New-Object System.Drawing.PointF($pts[0].X, [single]($s.Height - 6))))
    $a1 = [System.Drawing.Color]::FromArgb(45, $script:accent.R, $script:accent.G, $script:accent.B)
    $fill = New-Object System.Drawing.SolidBrush($a1)
    $g.FillPolygon($fill, $area.ToArray())
    $pen = New-Object System.Drawing.Pen($script:accent, 2.2)
    $g.DrawLines($pen, $pts.ToArray())
    $lb = New-Object System.Drawing.SolidBrush($cMuted)
    $g.DrawString(("{0:N0} ms" -f $max), $fSmall, $lb, 6, 2)
    $fill.Dispose(); $pen.Dispose(); $lb.Dispose()
})
$cardPing.Controls.Add($spark)
Add-ToPage "ping" $cardPing

$cardPingTips = New-Card 212 420 652 156
New-Heading "HOW TO READ THIS" 18 12 $cardPingTips
$pingTips = "Average: under 30 ms is excellent, 30-60 good, 60-100 noticeable, 100+ laggy.`n" +
    "Jitter: how much ping bounces between packets. Under 10 ms is smooth - spikes cause rubber-banding.`n" +
    "Packet loss: should be 0%. Any loss usually means Wi-Fi interference or a bad link.`n" +
    "Tip: test 'My Router' first. If that is slow or jumpy, the problem is your Wi-Fi, not the internet."
$cardPingTips.Controls.Add((New-Label $pingTips 18 38 616 108 $fUI $cText $cCard))
Add-ToPage "ping" $cardPingTips

# ---------- Ping engine (async - never freezes the window) ----------
$script:pingResults = New-Object System.Collections.ArrayList
$script:pingTask = $null; $script:pingSent = 0; $script:pingDone = 0; $script:pingLost = 0
$script:pingRunning = $false; $script:pinger = $null
$script:lastSend = [DateTime]::MinValue; $script:prevAvg = $null

function Get-Gateway {
    $r = Get-NetRoute -DestinationPrefix "0.0.0.0/0" | Where-Object { $_.NextHop -ne "0.0.0.0" } |
         Sort-Object RouteMetric | Select-Object -First 1
    if ($r) { return $r.NextHop }
    return $null
}
function Get-PingStats {
    $r = $script:pingResults
    if ($r.Count -eq 0) { return $null }
    $m = $r | Measure-Object -Average -Minimum -Maximum
    $j = 0.0
    if ($r.Count -gt 1) {
        $sum = 0.0
        for ($i = 1; $i -lt $r.Count; $i++) { $sum += [math]::Abs($r[$i] - $r[$i - 1]) }
        $j = $sum / ($r.Count - 1)
    }
    $loss = 0.0
    if ($script:pingDone -gt 0) { $loss = 100.0 * $script:pingLost / $script:pingDone }
    return [pscustomobject]@{ Avg = $m.Average; Min = $m.Minimum; Max = $m.Maximum; Jitter = $j; Loss = $loss }
}
function Update-PingStats {
    $s = Get-PingStats
    if ($s) {
        $script:statAvg.Text    = "{0:N0} ms" -f $s.Avg
        $script:statMinMax.Text = "{0:N0} / {1:N0}" -f $s.Min, $s.Max
        $script:statJitter.Text = "{0:N1} ms" -f $s.Jitter
        $script:statLoss.Text   = "{0:N0}%" -f $s.Loss
        if ($s.Avg -lt 40) { $script:statAvg.ForeColor = $cGood } elseif ($s.Avg -lt 80) { $script:statAvg.ForeColor = $cWarn } else { $script:statAvg.ForeColor = $cBad }
        if ($s.Loss -gt 0) { $script:statLoss.ForeColor = $cBad } else { $script:statLoss.ForeColor = $cGood }
    }
    $spark.Invalidate()
}
function Stop-Ping($msg) {
    $script:pingRunning = $false; $script:pingTask = $null
    $btnPing.Text = "Run Test"
    if ($msg) { Log $msg }
}
function Finish-Ping {
    Stop-Ping $null
    $s = Get-PingStats
    if (-not $s) { Log "No replies - check the host name / your connection."; return }
    $line = "Result: avg {0:N0} ms, jitter {1:N1} ms, loss {2:N0}%" -f $s.Avg, $s.Jitter, $s.Loss
    if ($script:prevAvg -ne $null) {
        $d = $s.Avg - $script:prevAvg
        $sign = ""; if ($d -ge 0) { $sign = "+" }
        $line += (" ({0}{1:N0} ms vs previous test)" -f $sign, $d)
    }
    Log $line
    $script:prevAvg = $s.Avg
}
$pingTimer = New-Object System.Windows.Forms.Timer
$pingTimer.Interval = 50
$pingTimer.Add_Tick({
    if (-not $script:pingRunning) { return }
    if ($script:pingTask -ne $null) {
        if ($script:pingTask.IsCompleted) {
            $res = $null
            try { $res = $script:pingTask.Result } catch { }
            $script:pingDone++
            if ($res -ne $null -and $res.Status -eq "Success") {
                [void]$script:pingResults.Add([double]$res.RoundtripTime)
                [void]$script:sparkVals.Add([double]$res.RoundtripTime)
            } else { $script:pingLost++ }
            $script:pingTask = $null
            Update-PingStats
        }
    }
    elseif ($script:pingSent -lt $script:pingCount) {
        if (((Get-Date) - $script:lastSend).TotalMilliseconds -ge 250) {
            $script:lastSend = Get-Date
            $script:pingSent++
            try { $script:pingTask = $script:pinger.SendPingAsync($hostBox.Text.Trim(), 1000) }
            catch { Stop-Ping "Could not ping that host." }
        }
    }
    else { Finish-Ping }
})
$pingTimer.Start()
$btnPing.Add_Click({
    if ($script:pingRunning) { Stop-Ping "Test stopped."; return }
    $h = $hostBox.Text.Trim()
    if (-not $h) { Log "Enter a host to ping."; return }
    $script:pingResults.Clear(); $script:sparkVals.Clear()
    $script:pingSent = 0; $script:pingDone = 0; $script:pingLost = 0; $script:pingTask = $null
    $script:pinger = New-Object System.Net.NetworkInformation.Ping
    $script:pingRunning = $true
    $btnPing.Text = "Stop"
    foreach ($l in @($script:statAvg, $script:statMinMax, $script:statJitter, $script:statLoss)) { $l.Text = "..."; $l.ForeColor = $cText }
    Log "Pinging $h ($($script:pingCount) packets)..."
})
$btnRouter.Add_Click({
    $gw = Get-Gateway
    if ($gw) { $hostBox.Text = $gw; Log "Router detected: $gw" } else { Log "Could not detect your router." }
})

# ---------- Page: Tools and System ----------
$cardSys = New-Card 212 78 652 170
New-Heading "THIS PC" 18 12 $cardSys
$script:sysVals = @{}
$sy = 40
foreach ($k in "CPU", "GPU", "Memory", "Windows", "Display") {
    $cardSys.Controls.Add((New-Label $k 18 $sy 90 20 $fUI $cMuted $cCard))
    $v = New-Label "..." 110 $sy 524 20 $fUI $cText $cCard
    $cardSys.Controls.Add($v); $script:sysVals[$k] = $v; $sy += 25
}
Add-ToPage "tools" $cardSys
function Load-SysInfo {
    $script:sysLoaded = $true
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $gpu = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch "Basic|Remote|Virtual" } | Select-Object -First 1
    $cs  = Get-CimInstance Win32_ComputerSystem
    $os  = Get-CimInstance Win32_OperatingSystem
    $script:sysVals["CPU"].Text     = "$($cpu.Name)".Trim()
    $script:sysVals["GPU"].Text     = "$($gpu.Name)".Trim()
    $script:sysVals["Memory"].Text  = "{0} GB" -f [math]::Round($cs.TotalPhysicalMemory / 1GB)
    $script:sysVals["Windows"].Text = "$($os.Caption)".Trim()
    $hz = $gpu.CurrentRefreshRate
    $script:sysVals["Display"].Text = if ($hz) { "$($gpu.CurrentHorizontalResolution) x $($gpu.CurrentVerticalResolution) @ $hz Hz" } else { "n/a" }
}

$cardAct = New-Card 212 260 652 190
New-Heading "QUICK ACTIONS" 18 12 $cardAct
$actions = [ordered]@{
    "Display settings"   = { Start-Process "ms-settings:display" }
    "Graphics settings"  = { Start-Process "ms-settings:display-advancedgraphics" }
    "Game Mode settings" = { Start-Process "ms-settings:gaming-gamemode" }
    "Task Manager"       = { Start-Process "taskmgr.exe" }
    "Power options"      = { Start-Process "powercfg.cpl" }
    "Fortnite folder"    = { $e = Get-FortniteExe; if ($e) { Start-Process explorer.exe (Split-Path $e) } else { Log "Fortnite install not found." } }
}
$ai = 0
foreach ($k in $actions.Keys) {
    $bx = 18 + (($ai % 2) * 312); $by = 40 + ([math]::Floor($ai / 2) * 48)
    $ab = New-Button $k $bx $by 300 38 "neutral"
    $ab.Name = $k
    $ab.Add_Click({ & $actions[$this.Name] })
    $cardAct.Controls.Add($ab); $ai++
}
Add-ToPage "tools" $cardAct

$cardClean = New-Card 212 462 652 114
New-Heading "CLEANUP" 18 12 $cardClean
$btnClean = New-Button "Clean temp files" 18 40 200 40 "accent"
$cleanLbl = New-Label "Removes temp files older than 1 day (safe to run)." 232 49 400 20 $fUI $cMuted $cCard
$cardClean.Controls.AddRange(@($btnClean, $cleanLbl))
Add-ToPage "tools" $cardClean
$btnClean.Add_Click({
    $btnClean.Enabled = $false; $form.Cursor = "WaitCursor"
    $freed = 0; $cnt = 0
    $cut = (Get-Date).AddDays(-1)
    foreach ($p in @($env:TEMP, "$env:SystemRoot\Temp")) {
        foreach ($f in @(Get-ChildItem -LiteralPath $p -Force -Recurse -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer -and $_.LastWriteTime -lt $cut })) {
            try { $len = $f.Length; Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; $freed += $len; $cnt++ } catch { }
            if (($cnt % 150) -eq 0) { [System.Windows.Forms.Application]::DoEvents() }
        }
    }
    $msg = "Cleaned {0:N0} files, freed {1:N1} MB." -f $cnt, ($freed / 1MB)
    $cleanLbl.Text = $msg; Log $msg
    $form.Cursor = "Default"; $btnClean.Enabled = $true
})

# ---------- Page: Game Boost and GPU ----------
$script:boost = $null
$boostApps = @("OneDrive", "Teams", "ms-teams", "Skype", "PhoneExperienceHost", "YourPhone", "Widgets", "WidgetService", "Cortana")
$boostSkip = @("explorer", "dwm", "powershell", "pwsh", "ShellExperienceHost", "SearchHost", "SearchApp", "StartMenuExperienceHost", "TextInputHost", "LockApp", "ApplicationFrameHost")
function New-Toggle($text, $x, $y, $card) {
    $t = New-Object TToggle
    $t.Font = $fUI; $t.Text = $text; $t.Checked = $true; $t.AutoSize = $true
    $t.Location = New-Object System.Drawing.Point($x, $y)
    $t.ForeColor = $cText; $t.BackColor = $cCard; $t.Cursor = "Hand"
    $card.Controls.Add($t); return $t
}
$cardBoost = New-Card 212 78 652 196
New-Heading "GAME BOOST  -  MAX FPS MODE" 18 12 $cardBoost
$btnBoost = New-Button "Start Game Boost" 18 40 200 50 "accent"
$btnBoost.Font = $fUIb; $btnBoost.Glyph = [string][char]0xE945
$script:boostLbl = New-Label "Off. Turn it on just before you start your game." 236 46 396 40 $fUI $cMuted $cCard
$cardBoost.Controls.AddRange(@($btnBoost, $script:boostLbl))
$chkBPower = New-Toggle "Max performance power plan" 18 104 $cardBoost
$chkBApps  = New-Toggle "Close background apps" 330 104 $cardBoost
$chkBPrio  = New-Toggle "High priority for your game" 18 136 $cardBoost
$chkBDvr   = New-Toggle "Pause Game Bar recording" 330 136 $cardBoost
$cardBoost.Controls.Add((New-Label "Stopping Game Boost or closing this app puts the power plan, priority and recording back. Closed apps are not reopened." 18 166 616 18 $fSmall $cMuted $cCard))
Add-ToPage "boost" $cardBoost

$boostTimer = New-Object System.Windows.Forms.Timer
$boostTimer.Interval = 3000
function Boost-Tick {
    if (-not $script:boost -or -not $chkBPrio.Checked) { return }
    $fp = [NativeUi]::ForegroundPid()
    if ($fp -le 4 -or $fp -eq $PID -or $script:boost.Prio.ContainsKey($fp)) { return }
    try {
        $pr = Get-Process -Id $fp -ErrorAction Stop
        if ($boostSkip -contains $pr.ProcessName) { return }
        $script:boost.Prio[$fp] = $pr.PriorityClass
        $pr.PriorityClass = "High"
        $script:boostLbl.Text = "On. $($pr.ProcessName) is running at high priority."
        Log "  Game Boost: $($pr.ProcessName) set to high priority"
    } catch { }
}
$boostTimer.Add_Tick({ Boost-Tick })
function Start-Boost {
    $b = @{ Scheme = $null; Dvr = @(); Prio = @{} }
    Log "Game Boost on"
    if ($chkBPower.Checked) {
        $m = [regex]::Match((powercfg /getactivescheme | Out-String), '[0-9a-fA-F]{8}-[0-9a-fA-F-]{27}')
        if ($m.Success) { $b.Scheme = $m.Value }
        $target = $highPerf
        $u = [regex]::Match((powercfg /list | Out-String), '([0-9a-fA-F]{8}-[0-9a-fA-F-]{27})\s+\(Ultimate Performance\)')
        if ($u.Success) { $target = $u.Groups[1].Value }
        else {
            $out = (powercfg /duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>&1) -join " "
            if ($out -match $guidRx) { $target = $Matches[0] }
        }
        powercfg /setactive $target 2>&1 | Out-Null
        powercfg /setacvalueindex $target SUB_PROCESSOR PROCTHROTTLEMIN 100 2>&1 | Out-Null
        powercfg /setacvalueindex $target SUB_PROCESSOR PROCTHROTTLEMAX 100 2>&1 | Out-Null
        powercfg /setactive $target 2>&1 | Out-Null
        Log "  Game Boost: max performance power plan on ($target)"
    }
    if ($chkBApps.Checked) {
        $p = @(Get-Process -Name $boostApps -ErrorAction SilentlyContinue)
        $p | Stop-Process -Force -ErrorAction SilentlyContinue
        Log "  Game Boost: closed $($p.Count) background app(s)"
    }
    if ($chkBDvr.Checked) {
        foreach ($r in @(@{ P = "HKCU:\System\GameConfigStore"; N = "GameDVR_Enabled" }, @{ P = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"; N = "AppCaptureEnabled" })) {
            $k = Get-Item -LiteralPath $r.P -ErrorAction SilentlyContinue
            $had = [bool]($k -and ($k.GetValueNames() -contains $r.N))
            $b.Dvr += @{ P = $r.P; N = $r.N; E = $had; V = $(if ($had) { $k.GetValue($r.N) } else { $null }) }
            Set-Reg $r.P $r.N 0 "DWord"
        }
        Log "  Game Boost: Game Bar recording paused"
    }
    $script:boost = $b
    $btnBoost.Text = "Stop Game Boost"
    $script:boostLbl.Text = "On. Switch to your game - it gets high priority once it is in front."
    $boostTimer.Start()
}
function Stop-Boost {
    $b = $script:boost
    if (-not $b) { return }
    $boostTimer.Stop()
    if ($b.Scheme) { powercfg /setactive $b.Scheme | Out-Null }
    foreach ($d in $b.Dvr) {
        try {
            if ($d.E) { Set-Reg $d.P $d.N $d.V "DWord" }
            else { Remove-ItemProperty -LiteralPath $d.P -Name $d.N -ErrorAction SilentlyContinue }
        } catch { }
    }
    foreach ($id in @($b.Prio.Keys)) {
        try { (Get-Process -Id $id -ErrorAction Stop).PriorityClass = $b.Prio[$id] } catch { }
    }
    $script:boost = $null
    $btnBoost.Text = "Start Game Boost"
    $script:boostLbl.Text = "Off. Everything was put back to normal."
    Log "Game Boost off - settings restored"
}
$btnBoost.Add_Click({
    $form.Cursor = "WaitCursor"
    try { if ($script:boost) { Stop-Boost } else { Start-Boost } } catch { Log "Game Boost: $($_.Exception.Message)" }
    $form.Cursor = "Default"
})

$cardNv = New-Card 212 286 652 150
New-Heading "NVIDIA OPTIMIZER" 18 12 $cardNv
$script:nvInfo = New-Label "" 18 38 616 36 $fUI $cMuted $cCard
$btnNvMax   = New-Button "Max power + clocks" 18 80 196 40 "accent"
$btnNvReset = New-Button "Reset to default" 222 80 150 40 "neutral"
$btnNvPanel = New-Button "NVIDIA Control Panel" 380 80 180 40 "neutral"
$cardNv.Controls.AddRange(@($script:nvInfo, $btnNvMax, $btnNvReset, $btnNvPanel))
$cardNv.Controls.Add((New-Label "Ultimate. Uses NVIDIA's own nvidia-smi tool. Runs hotter and louder. Everything resets when you restart." 18 124 616 18 $fSmall $cMuted $cCard))
Add-ToPage "boost" $cardNv

$cardAmd = New-Card 212 448 652 128
New-Heading "AMD OPTIMIZER" 18 12 $cardAmd
$script:amdInfo = New-Label "" 18 38 616 22 $fUI $cMuted $cCard
$btnAmdTw  = New-Button "Apply AMD tweaks" 18 66 196 40 "accent"
$btnAmdOc  = New-Button "Open AMD tuning" 222 66 170 40 "neutral"
$cardAmd.Controls.AddRange(@($script:amdInfo, $btnAmdTw, $btnAmdOc))
$cardAmd.Controls.Add((New-Label "AMD only allows overclocking from its own AMD Software (Performance > Tuning). The tweaks can be undone." 18 106 616 18 $fSmall $cMuted $cCard))
Add-ToPage "boost" $cardAmd

function Get-NvSmi {
    foreach ($p in @("$env:SystemRoot\System32\nvidia-smi.exe", "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe")) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}
function Nv-Query($fields) {
    $s = Get-NvSmi
    if (-not $s) { return $null }
    $o = & $s "--query-gpu=$fields" "--format=csv,noheader,nounits" 2>$null | Select-Object -First 1
    if ($o) { return @($o -split ',\s*') } else { return $null }
}
function Load-GpuInfo {
    $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { [string]$_.Name })
    $q = Nv-Query "name,temperature.gpu,clocks.gr,clocks.max.gr,power.draw,power.limit,power.max_limit"
    $hasNv = [bool]($q -and $q.Count -ge 7)
    if ($hasNv) {
        $script:nvInfo.Text = "$($q[0])   |   $($q[1]) C   |   $($q[2]) of $($q[3]) MHz`nPower $($q[4]) W   |   limit $($q[5]) W (card max $($q[6]) W)"
    } elseif (@($gpus | Where-Object { $_ -match 'NVIDIA' }).Count -gt 0) {
        $script:nvInfo.Text = "NVIDIA card found, but nvidia-smi is missing. Update your NVIDIA driver."
    } else { $script:nvInfo.Text = "No NVIDIA graphics card found on this PC." }
    $btnNvMax.Enabled = $hasNv; $btnNvReset.Enabled = $hasNv
    $amd = @($gpus | Where-Object { $_ -match 'AMD|Radeon' })
    if ($amd.Count -gt 0) { $script:amdInfo.Text = "$($amd[0]) found." } else { $script:amdInfo.Text = "No AMD graphics card found on this PC." }
    $btnAmdTw.Enabled = ($amd.Count -gt 0)
}
$btnNvMax.Add_Click({
    if ($script:planIdx -lt 2) { [void][System.Windows.Forms.MessageBox]::Show("GPU overclocking is an Ultimate feature.", "TKL Tweaks"); return }
    $r = [System.Windows.Forms.MessageBox]::Show("This raises your NVIDIA card's power limit to its maximum and holds its clocks at full boost.`n`nThe card will run hotter and louder. It resets when you restart, or when you click Reset to default. Continue?", "TKL Tweaks", "YesNo", "Warning")
    if ($r -ne "Yes") { return }
    $s = Get-NvSmi; $q = Nv-Query "power.max_limit,clocks.max.gr"
    $pl = 0.0; $mc = 0
    if ($q -and [double]::TryParse($q[0], [System.Globalization.NumberStyles]::Float, [cultureinfo]::InvariantCulture, [ref]$pl)) {
        $o = (& $s -pl $pl.ToString([cultureinfo]::InvariantCulture) 2>&1 | Out-String).Trim()
        Log "  NVIDIA power limit: $o"
    } else { Log "  NVIDIA: this card does not allow changing its power limit." }
    if ($q -and [int]::TryParse($q[1], [ref]$mc) -and $mc -gt 0) {
        $o = (& $s -lgc "$mc,$mc" 2>&1 | Out-String).Trim()
        Log "  NVIDIA clocks: $o"
    }
    Load-GpuInfo
})
$btnNvReset.Add_Click({
    $s = Get-NvSmi; if (-not $s) { return }
    $o = (& $s -rgc 2>&1 | Out-String).Trim(); Log "  NVIDIA clocks: $o"
    $q = Nv-Query "power.default_limit"; $pl = 0.0
    if ($q -and [double]::TryParse($q[0], [System.Globalization.NumberStyles]::Float, [cultureinfo]::InvariantCulture, [ref]$pl)) {
        $o = (& $s -pl $pl.ToString([cultureinfo]::InvariantCulture) 2>&1 | Out-String).Trim(); Log "  NVIDIA power limit: $o"
    }
    Load-GpuInfo
})
$btnNvPanel.Add_Click({
    try { Start-Process "shell:AppsFolder\NVIDIACorp.NVIDIAControlPanel_56jybvy8sckqj!NVIDIACorp.NVIDIAControlPanel" }
    catch { try { Start-Process "nvcplui.exe" } catch { Log "NVIDIA Control Panel is not installed." } }
})
$btnAmdTw.Add_Click({ Apply-Ids @("u_amdulps") })
$btnAmdOc.Add_Click({
    $exe = Join-Path $env:ProgramFiles "AMD\CNext\CNext\RadeonSoftware.exe"
    if (Test-Path -LiteralPath $exe) { Start-Process $exe } else { Start-Process "https://www.amd.com/en/support/download/drivers.html" }
})

# ---------- Page: Appearance ----------
$cardTheme = New-Card 212 78 652 150
New-Heading "THEME" 18 12 $cardTheme
$ti = 0
foreach ($n in $themes.Keys) {
    $tx = 18 + (($ti % 7) * 88); $ty2 = 40 + ([math]::Floor($ti / 7) * 52)
    $tb2 = New-Button $n $tx $ty2 82 44 "neutral"
    $tb2.Name = $n; $tb2.Font = $fUIb
    $tb2.Tag = Rgb $themes[$n].Acc; $tb2.BackColor = $tb2.Tag; $tb2.Color2 = Rgb $themes[$n].Acc2
    $tb2.Add_Click({ Apply-Theme $this.Name })
    $cardTheme.Controls.Add($tb2); [void]$script:themeButtons.Add($tb2); $ti++
}
$tbC = New-Button "Custom..." (18 + (($ti % 7) * 88)) (40 + ([math]::Floor($ti / 7) * 52)) 82 44 "neutral"
$tbC.Name = "Custom"; $tbC.Font = $fUIb
$cardTheme.Controls.Add($tbC); [void]$script:themeButtons.Add($tbC)
function Set-CustomTheme($c) {
    $d = { param($t) @([int]($c.R * $t), [int]($c.G * $t), [int]($c.B * $t)) }
    $l = { param($t) @([int]($c.R + (255 - $c.R) * $t), [int]($c.G + (255 - $c.G) * $t), [int]($c.B + (255 - $c.B) * $t)) }
    $acc = @([int]$c.R, [int]$c.G, [int]$c.B)
    $o2 = @([int](($c.R + $c.B) / 2), [int](($c.G + $c.R) / 2), [int](($c.B + $c.G) / 2))
    $themes["Custom"] = @{ B1A = (& $d 0.10); B1B = (& $d 0.24); B2A = (& $d 0.16); B2B = (& $d 0.05)
        O1 = $acc; O2 = $o2; Dot = (& $l 0.5); Acc = $acc; Acc2 = (& $l 0.3) }
    $settings.Custom = "{0},{1},{2}" -f $c.R, $c.G, $c.B
    $tbC.Tag = Rgb $acc; $tbC.BackColor = $tbC.Tag; $tbC.Color2 = Rgb $themes["Custom"].Acc2
}
$tbC.Add_Click({
    $cd = New-Object System.Windows.Forms.ColorDialog
    $cd.FullOpen = $true; $cd.Color = $script:accent
    if ($cd.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) { Set-CustomTheme $cd.Color; Apply-Theme "Custom" }
    $cd.Dispose()
})
Add-ToPage "look" $cardTheme

$cardBg = New-Card 212 240 652 336
New-Heading "BACKGROUND" 18 12 $cardBg
$cardBg.Controls.Add((New-Label "Animation style" 18 46 170 20 $fUI $cText $cCard))
$styleBox = New-Object DarkCombo
$styleBox.DropDownStyle = "DropDownList"; $styleBox.FlatStyle = "Flat"
$styleBox.Location = New-Object System.Drawing.Point(190, 42); $styleBox.Size = New-Object System.Drawing.Size(200, 28)
$styleBox.BackColor = $cInner; $styleBox.ForeColor = $cText; $styleBox.Font = $fUI
foreach ($s in $styles) { [void]$styleBox.Items.Add($s) }
$chkAnim = New-Object TToggle
$chkAnim.Text = "Animated"; $chkAnim.Checked = $true
$chkAnim.Location = New-Object System.Drawing.Point(408, 44)
$chkAnim.ForeColor = $cText; $chkAnim.BackColor = $cCard
$chkVig = New-Object TToggle
$chkVig.Text = "Vignette"; $chkVig.Checked = $true
$chkVig.Location = New-Object System.Drawing.Point(522, 44)
$chkVig.ForeColor = $cText; $chkVig.BackColor = $cCard
$cardBg.Controls.AddRange(@($styleBox, $chkAnim, $chkVig))
$sCount = New-Slider $cardBg "Particle count" 84 10 120 46
$sSpeed = New-Slider $cardBg "Animation speed" 122 10 300 100
$sGlow  = New-Slider $cardBg "Glow intensity" 160 0 200 100
$sDim   = New-Slider $cardBg "Image darkness" 198 0 90 55
$sGlass = New-Slider $cardBg "Panel transparency" 236 0 90 35
$btnImg   = New-Button "Choose background image..." 18 280 250 40 "accent"
$btnClear = New-Button "Remove image" 278 280 150 40 "neutral"
$btnReset = New-Button "Reset appearance" 438 280 160 40 "neutral"
$cardBg.Controls.AddRange(@($btnImg, $btnClear, $btnReset))
$cardBg.Controls.Add((New-Label "Animation pauses automatically when this window is not in front, so it never costs you FPS while you play." 18 328 616 30 $fSmall $cMuted $cCard))
Add-ToPage "look" $cardBg

$saveTimer = New-Object System.Windows.Forms.Timer
$saveTimer.Interval = 600
$saveTimer.Add_Tick({ $saveTimer.Stop(); Save-Settings })
function Queue-Save { $saveTimer.Stop(); $saveTimer.Start() }

function Mix-Color($a, $b, [double]$t) {
    [System.Drawing.Color]::FromArgb([int]($a.R + ($b.R - $a.R) * $t), [int]($a.G + ($b.G - $a.G) * $t), [int]($a.B + ($b.B - $a.B) * $t))
}
function Retint-Tree($c, $back, $fore, $border) {
    $k = $c.BackColor.ToArgb(); if ($back.ContainsKey($k)) { $c.BackColor = $back[$k] }
    $k = $c.ForeColor.ToArgb(); if ($fore.ContainsKey($k)) { $c.ForeColor = $fore[$k] }
    if ($c.Tag -is [System.Drawing.Color]) { $k = $c.Tag.ToArgb(); if ($back.ContainsKey($k)) { $c.Tag = $back[$k] } }
    if ($c -is [Card]) { $c.BorderColor = $border }
    foreach ($ch in $c.Controls) { Retint-Tree $ch $back $fore $border }
}
# Cards, boxes, neutral buttons and muted text take a dark shade of the theme accent
function Retint-Ui {
    $acc = $script:accent
    $card    = Mix-Color ([System.Drawing.Color]::FromArgb(24, 25, 32)) $acc 0.11
    $inner   = Mix-Color ([System.Drawing.Color]::FromArgb(13, 13, 19)) $acc 0.08
    $neutral = Mix-Color ([System.Drawing.Color]::FromArgb(46, 48, 60)) $acc 0.24
    $muted   = Mix-Color ([System.Drawing.Color]::FromArgb(150, 152, 168)) $acc 0.20
    $border  = Mix-Color ([System.Drawing.Color]::FromArgb(40, 42, 54)) $acc 0.28
    $back = @{}; $fore = @{}
    $back[$script:cCard.ToArgb()] = $card; $back[$script:cInner.ToArgb()] = $inner; $back[$script:cNeutral.ToArgb()] = $neutral
    $fore[$script:cMuted.ToArgb()] = $muted
    $live = $form.IsHandleCreated
    if ($live) { [NativeUi]::Redraw($form, $false) }
    try { Retint-Tree $form $back $fore $border }
    finally { if ($live) { [NativeUi]::Redraw($form, $true); $form.Invalidate($true) } }
    $script:cCard = $card; $script:cInner = $inner; $script:cNeutral = $neutral; $script:cMuted = $muted
    [UiTheme]::Track = $inner; [UiTheme]::Neutral = $neutral
    $tweakList.CardBg = $card; $tweakList.RowHi = Mix-Color $card ([System.Drawing.Color]::White) 0.06; $tweakList.MutedCol = $muted
    $tabStrip.MutedColor = $muted; $tabStrip.Invalidate()
}
function Apply-Theme($name) {
    if (-not $themes.Contains($name)) { $name = "Purple Haze" }
    $t = $themes[$name]
    $canvas.C1A = Rgb $t.B1A; $canvas.C1B = Rgb $t.B1B; $canvas.C2A = Rgb $t.B2A; $canvas.C2B = Rgb $t.B2B
    $canvas.Orb1 = Rgb $t.O1; $canvas.Orb2 = Rgb $t.O2; $canvas.Dot = Rgb $t.Dot
    $script:accent = Rgb $t.Acc; $script:accent2 = Rgb $t.Acc2
    $canvas.Accent = $script:accent; $canvas.Accent2 = $script:accent2
    $form.BackColor = Rgb $t.B1A
    [UiTheme]::Accent = $script:accent; [UiTheme]::Accent2 = $script:accent2
    Retint-Ui
    foreach ($b in $script:accentButtons) { $b.Tag = $script:accent; $b.BackColor = $script:accent; $b.Color2 = $script:accent2 }
    foreach ($l in $script:accentLabels) { $l.ForeColor = $script:accent }
    foreach ($b in $script:themeButtons) {
        $b.Selected = ($b.Name -eq $name); $b.Invalidate()
    }
    $canvas.MarkDirty(); $cardBg.Invalidate($true)
    Update-Nav
    $settings.Theme = $name; Queue-Save
    $canvas.Invalidate(); $spark.Invalidate()
    $tweakList.Accent = $script:accent; $tweakList.Invalidate(); Refresh-Dashboard
}
$styleBox.Add_SelectedIndexChanged({
    $canvas.Style = [string]$styleBox.SelectedItem; $canvas.Rebuild()
    $settings.Style = [string]$styleBox.SelectedItem; Queue-Save
})
$chkAnim.Add_CheckedChanged({ $canvas.Animate = $chkAnim.Checked; $settings.Animate = $chkAnim.Checked; Queue-Save })
$chkVig.Add_CheckedChanged({ $canvas.Vignette = $chkVig.Checked; $canvas.MarkDirty(); $settings.Vignette = $chkVig.Checked; Queue-Save })
$sGlow.Bar.Add_ValueChanged({
    $canvas.Glow = [single]($sGlow.Bar.Value / 100.0); $sGlow.Val.Text = "$($sGlow.Bar.Value)%"
    $canvas.MarkDirty(); $settings.Glow = $sGlow.Bar.Value; Queue-Save
})
$sCount.Bar.Add_ValueChanged({
    $canvas.Count = $sCount.Bar.Value; $sCount.Val.Text = "$($sCount.Bar.Value)"
    $canvas.Rebuild(); $settings.Count = $sCount.Bar.Value; Queue-Save
})
$sSpeed.Bar.Add_ValueChanged({
    $canvas.Speed = [single]($sSpeed.Bar.Value / 100.0); $sSpeed.Val.Text = "$($sSpeed.Bar.Value)%"
    $settings.Speed = $sSpeed.Bar.Value; Queue-Save
})
function Set-Glass([int]$pct) {
    $op = [int](255 - [math]::Min(90, [math]::Max(0, $pct)) * 2.2)
    foreach ($c in $canvas.Controls) { if ($c -is [Card]) { $c.Host = $canvas; $c.Opacity = $op } }
    $canvas.Invalidate($true)
}
$sGlass.Bar.Add_ValueChanged({
    $sGlass.Val.Text = "$($sGlass.Bar.Value)%"; $settings.Glass = $sGlass.Bar.Value
    Set-Glass $sGlass.Bar.Value; Queue-Save
})
$sDim.Bar.Add_ValueChanged({
    $canvas.Dim = [single]($sDim.Bar.Value / 100.0); $sDim.Val.Text = "$($sDim.Bar.Value)%"
    $canvas.MarkDirty(); $settings.Dim = $sDim.Bar.Value; Queue-Save
})
$btnImg.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp;*.gif"
    $dlg.Title = "Choose a background image"
    if ($dlg.ShowDialog() -eq "OK") {
        try { $canvas.SetImage($dlg.FileName); $settings.Image = $dlg.FileName; Queue-Save; Log "Background image set." }
        catch { Log "Could not load that image." }
    }
})
$btnClear.Add_Click({ $canvas.ClearImage(); $settings.Image = ""; Queue-Save; Log "Background image removed." })
$btnReset.Add_Click({
    $canvas.ClearImage(); $settings.Image = ""
    $styleBox.SelectedItem = "Network"; $chkAnim.Checked = $true
    $sCount.Bar.Value = 46; $sSpeed.Bar.Value = 100; $sDim.Bar.Value = 55; $sGlow.Bar.Value = 100; $sGlass.Bar.Value = 35; $chkVig.Checked = $true
    Apply-Theme "Purple Haze"; Log "Appearance reset."
})


# ---------- Apply / Undo ----------
$ovl = New-Card 0 0 440 156
$ovl.Visible = $false
$ovlTitle = New-Label "OPTIMIZING YOUR PC" 24 18 392 20 $fHead $script:accent $cCard
[void]$script:accentLabels.Add($ovlTitle)
$ovlStep  = New-Label "" 24 46 392 20 $fUI $cText $cCard
$ovlCount = New-Label "" 24 112 392 18 $fSmall $cMuted $cCard
$script:ovlRatio = 0.0
$ovlBar = New-Object BufferedPanel
$ovlBar.Location = New-Object System.Drawing.Point(24, 80); $ovlBar.Size = New-Object System.Drawing.Size(392, 14)
$ovlBar.BackColor = $cCard
Set-Rounded $ovlBar 7
$ovlBar.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $tb = New-Object System.Drawing.SolidBrush([UiTheme]::Track); $g.FillRectangle($tb, 0, 0, $s.Width, $s.Height); $tb.Dispose()
    $w = [int]($s.Width * $script:ovlRatio)
    if ($w -gt 1) {
        $r = New-Object System.Drawing.Rectangle(0, 0, $w, $s.Height)
        $fb = New-Object System.Drawing.Drawing2D.LinearGradientBrush($r, $script:accent, $script:accent2, 0.0)
        $g.FillRectangle($fb, $r); $fb.Dispose()
    }
})
$ovl.Controls.AddRange(@($ovlTitle, $ovlStep, $ovlBar, $ovlCount))
$canvas.Controls.Add($ovl)
function Show-Progress($total) {
    $ovl.Left = 212 + [int](($canvas.Width - 212 - $ovl.Width) / 2); $ovl.Top = [int](($canvas.Height - $ovl.Height) / 2)
    $ovlTitle.Text = "OPTIMIZING YOUR PC"; $script:ovlRatio = 0.0; $ovlStep.Text = "Getting ready..."
    $ovlCount.Text = "Applied 0 / $total"; $ovl.Visible = $true; $ovl.BringToFront(); $ovl.Refresh()
}
function Step-Progress($i, $total, $name) {
    $script:ovlRatio = [double]$i / [math]::Max(1, $total)
    $ovlStep.Text = $name; $ovlCount.Text = "Applied $i / $total"
    $ovlBar.Invalidate(); $ovl.Update()
}
$ovlTimer = New-Object System.Windows.Forms.Timer
$ovlTimer.Interval = 1800
$ovlTimer.Add_Tick({ $ovlTimer.Stop(); $ovl.Visible = $false })
function Apply-Ids($ids) {
    if ($ids.Count -eq 0) { Log "Nothing selected."; return }
    $btnApply.Enabled = $false; $form.Cursor = "WaitCursor"
    try {
        Log "Applying $($ids.Count) tweak(s)..."
        Show-Progress $ids.Count
        if ($chkRestore.Checked) {
            $ovlStep.Text = "Creating a restore point..."; $ovl.Update()
            Log "  Creating restore point (can take a few seconds)..."
            Enable-ComputerRestore -Drive "$env:SystemDrive\"
            Checkpoint-Computer -Description "Before TKL Tweaks" -RestorePointType MODIFY_SETTINGS
        }
        $done = 0
        foreach ($id in $ids) {
            $t = $script:tweakById[$id]
            $done++
            if (-not $t) { continue }
            Step-Progress ($done - 1) $ids.Count $t.Name
            if ($t.Plan -gt $script:planIdx) { Log "  Locked: $($t.Name)"; continue }
            try {
                Invoke-TweakApply $t
                $tweakList.SetApplied($id, $script:backup.ContainsKey($id))
            } catch { Log "  Failed: $($t.Name)" }
            [System.Windows.Forms.Application]::DoEvents()
        }
        Step-Progress $ids.Count $ids.Count "Restart your PC to finish. Undo All reverses everything."
        $ovlTitle.Text = "OPTIMIZATION COMPLETE"; $ovlTimer.Start()
        Log "Done. Restart recommended. You can close this app - changes stay applied."
        Refresh-Dashboard
    } finally { $form.Cursor = "Default"; $btnApply.Enabled = $true; if (-not $ovlTimer.Enabled) { $ovl.Visible = $false } }
}
function Apply-Recommended {
    $tweakList.SelectRecommendedEverywhere()
    $ids = @($tweakList.CheckedIds())
    if ($ids.Count -eq 0) { Log "No recommended tweaks to apply."; return }
    $r = [System.Windows.Forms.MessageBox]::Show("One-Click Optimize will apply $($ids.Count) recommended tweak(s) for your plan.`n`nEvery change is backed up first and Undo All reverses it. Continue?",
        "TKL Tweaks", "YesNo", "Question")
    if ($r -eq "Yes") { Apply-Ids $ids }
}
$btnApply.Add_Click({ Apply-Ids @($tweakList.CheckedIds()) })
$btnDashApply.Add_Click({ Apply-Recommended })
$btnUndo.Add_Click({
    $n = 0
    Log "Restoring your original settings..."
    foreach ($t in $tweaks) {
        if (Invoke-TweakUndo $t) { $n++; $tweakList.SetApplied($t.Id, $false) }
    }
    if ($n -eq 0) { Log "Nothing to undo - no saved changes were found." }
    else { Log "Restored $n tweak(s) to how they were before." }
    Refresh-Dashboard
})

# ---------- Login window ----------
function Show-Login($startup) {
    $script:loginResult = $null
    $lf = New-Object System.Windows.Forms.Form
    $lf.Text = "TKL Tweaks - Sign in"
    $lf.ClientSize = New-Object System.Drawing.Size(460, 620)
    $lf.StartPosition = "CenterScreen"; $lf.FormBorderStyle = "FixedDialog"
    $lf.MaximizeBox = $false; $lf.MinimizeBox = $false
    $lf.BackColor = $canvas.C1A; $lf.Font = $fUI; $lf.Icon = $form.Icon
    $lc = New-Object ParticleCanvas
    $lc.Dock = "Fill"
    $lc.C1A = $canvas.C1A; $lc.C1B = $canvas.C1B; $lc.C2A = $canvas.C2A; $lc.C2B = $canvas.C2B
    $lc.Orb1 = $canvas.Orb1; $lc.Orb2 = $canvas.Orb2; $lc.Dot = $canvas.Dot
    $lc.Accent = $canvas.Accent; $lc.Accent2 = $canvas.Accent2
    $lc.Count = 40; $lc.Rebuild()
    $lc.PageTitle = "TKL Tweaks"; $lc.PageSubtitle = "Sign in to unlock your plan"
    $lc.TitleX = 34; $lc.TitleY = 30
    $lf.Controls.Add($lc)

    $card = New-Card 30 110 400 490
    $mode = "signin"
    if ((-not $script:acct.User) -and (-not $TKL.ApiUrl)) { $mode = "create" }

    $head = New-Label "SIGN IN" 24 18 300 18 $fHead $script:accent $cCard
    $uLbl = New-Label "Username" 24 52 200 18 $fSmall $cMuted $cCard
    $uBox = New-Object System.Windows.Forms.TextBox
    $uBox.Location = New-Object System.Drawing.Point(24, 72); $uBox.Size = New-Object System.Drawing.Size(352, 28)
    $uBox.BackColor = $cInner; $uBox.ForeColor = $cText; $uBox.BorderStyle = "FixedSingle"; $uBox.Font = $fUI
    $pLbl = New-Label "Password" 24 110 200 18 $fSmall $cMuted $cCard
    $pBox = New-Object System.Windows.Forms.TextBox
    $pBox.Location = New-Object System.Drawing.Point(24, 130); $pBox.Size = New-Object System.Drawing.Size(352, 28)
    $pBox.BackColor = $cInner; $pBox.ForeColor = $cText; $pBox.BorderStyle = "FixedSingle"; $pBox.Font = $fUI
    $pBox.UseSystemPasswordChar = $true
    $cLbl = New-Label "Confirm password" 24 168 200 18 $fSmall $cMuted $cCard
    $cBox = New-Object System.Windows.Forms.TextBox
    $cBox.Location = New-Object System.Drawing.Point(24, 188); $cBox.Size = New-Object System.Drawing.Size(352, 28)
    $cBox.BackColor = $cInner; $cBox.ForeColor = $cText; $cBox.BorderStyle = "FixedSingle"; $cBox.Font = $fUI
    $cBox.UseSystemPasswordChar = $true
    $keep = New-Object TToggle
    $keep.Text = "Keep me signed in"; $keep.AutoSize = $true; $keep.ForeColor = $cText; $keep.BackColor = $cCard; $keep.Cursor = "Hand"
    $msg = New-Label "" 24 0 352 34 $fSmall $cBad $cCard
    $btnGo = New-Button "Sign in" 24 0 352 42 "accent"
    $btnSwitch = New-Button "Need an account? Create one" 24 0 352 40 "neutral"
    $btnGuest = New-Button "Continue as guest (Free plan)" 24 0 352 40 "neutral"
    $note = New-Label "Accounts are stored on this PC. Licenses unlock Premium and Ultimate tweaks." 24 0 352 32 $fSmall $cMuted $cCard
    if ($TKL.ApiUrl) { $note.Text = "Your account and license are verified by the $($TKL.Brand) server." }
    $card.Controls.AddRange(@($head, $uLbl, $uBox, $pLbl, $pBox, $cLbl, $cBox, $keep, $msg, $btnGo, $btnSwitch, $btnGuest, $note))
    $lc.Controls.Add($card)

    $layout = {
        $creating = ($script:loginMode -eq "create")
        $cLbl.Visible = $creating; $cBox.Visible = $creating
        $y = 130 + 58
        if ($creating) { $y = 188 + 58 }
        $keep.Top = $y - 4; $msg.Top = $y + 24; $btnGo.Top = $y + 62; $btnSwitch.Top = $y + 112
        $btnGuest.Top = $y + 152; $note.Top = $y + 198
        if ($creating) { $head.Text = "CREATE ACCOUNT"; $btnGo.Text = "Create account"; $btnSwitch.Text = "Already have an account? Sign in" }
        else { $head.Text = "SIGN IN"; $btnGo.Text = "Sign in"; $btnSwitch.Text = "Need an account? Create one" }
        $msg.Text = ""
    }
    $script:loginMode = $mode
    & $layout

    $btnSwitch.Add_Click({
        if ($script:loginMode -eq "create") { $script:loginMode = "signin" } else { $script:loginMode = "create" }
        & $layout
    })
    $btnGuest.Add_Click({
        $script:loginResult = @{ User = "Guest"; Keep = $false }
        $lf.Close()
    })
    $btnGo.Add_Click({
        $u = $uBox.Text.Trim(); $pw = $pBox.Text
        if ($u -notmatch '^[A-Za-z0-9_.-]{3,24}$') { $msg.Text = "Username must be 3-24 letters, numbers, dots, dashes or underscores."; return }
        if ($pw.Length -lt 6) { $msg.Text = "Password must be at least 6 characters."; return }
        $btnGo.Enabled = $false; $lf.Cursor = "WaitCursor"
        try {
            if ($script:loginMode -eq "create") {
                if ($pw -ne $cBox.Text) { $msg.Text = "Passwords do not match."; return }
                if ($script:acct.User -and (-not $TKL.ApiUrl)) {
                    $q = [System.Windows.Forms.MessageBox]::Show("An account already exists on this PC. Creating a new one replaces it and removes its license. Continue?",
                        "TKL Tweaks", "YesNo", "Warning")
                    if ($q -ne "Yes") { return }
                }
                $res = Invoke-Register $u $pw
            } else { $res = Invoke-Login $u $pw }
            if ($res.Ok) {
                $script:loginResult = @{ User = $u; Keep = $keep.Checked }
                $lf.Close()
            } else { $msg.Text = $res.Msg }
        } finally { $lf.Cursor = "Default"; $btnGo.Enabled = $true }
    })
    $lf.AcceptButton = $btnGo
    $lf.Add_Shown({
        [NativeUi]::DarkTitle($lf.Handle)
        [NativeUi]::CaptionColor($lf.Handle, $canvas.C1A.R, $canvas.C1A.G, $canvas.C1A.B)
        $uBox.Focus()
    })
    [void]$lf.ShowDialog()
    [void]$script:accentButtons.Remove($btnGo)
    $lf.Dispose()
    return $script:loginResult
}

# ---------- Page: Macros (user macro library) ----------
$macroFile = Join-Path $dataDir "macros.json"
$script:macros = New-Object System.Collections.ArrayList
function New-Macro($name, $desc, $steps) { [pscustomobject]@{ Name = $name; Desc = $desc; Steps = @($steps) } }
function Save-Macros {
    try {
        if (-not (Test-Path $dataDir)) { New-Item -ItemType Directory -Path $dataDir -Force | Out-Null }
        ConvertTo-Json -InputObject @($script:macros) -Depth 5 | Set-Content -LiteralPath $macroFile -Encoding UTF8
    } catch { Log "Could not save macros." }
}
function Read-MacroFile($path) {
    $out = @()
    $j = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    foreach ($m in $j) { if ($m.Name) { $out += New-Macro ([string]$m.Name) ([string]$m.Desc) @($m.Steps | ForEach-Object { [string]$_ }) } }
    return $out
}
function Load-Macros {
    $script:macros.Clear()
    if (Test-Path $macroFile) {
        try { foreach ($m in @(Read-MacroFile $macroFile)) { [void]$script:macros.Add($m) } } catch { Log "macros.json could not be read." }
        return
    }
    [void]$script:macros.Add((New-Macro "Pre-game cleanup" "Closes common background apps and flushes DNS before you play." @(
        "ps: Get-Process -Name OneDrive, Teams, ms-teams, Spotify -ErrorAction SilentlyContinue | Stop-Process -Force",
        "cmd: ipconfig /flushdns")))
    [void]$script:macros.Add((New-Macro "Network refresh" "Clears DNS and re-registers your connection. Good before ranked." @(
        "cmd: ipconfig /flushdns", "cmd: ipconfig /registerdns", "wait: 1", "ps: Clear-DnsClientCache")))
    [void]$script:macros.Add((New-Macro "Clean temp files" "Deletes temp files that are not in use." @(
        'ps: Remove-Item "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue')))
    [void]$script:macros.Add((New-Macro "Launch Fortnite" "Starts Fortnite through the Epic Games Launcher." @(
        "url: com.epicgames.launcher://apps/Fortnite?action=launch&silent=true")))
    [void]$script:macros.Add((New-Macro "Esports boost" "Applies a few latency tweaks (locked ones are skipped on lower plans)." @(
        "tweaks: dnsflush, win32prio, timerres", "wait: 1", "cmd: ipconfig /flushdns")))
    [void]$script:macros.Add((New-Macro "Full network reset" "Release/renew IP, flush DNS, reset Winsock. Use after VPN issues." @(
        "cmd: ipconfig /release", "wait: 2", "cmd: ipconfig /renew",
        "cmd: ipconfig /flushdns", "cmd: netsh winsock reset", "cmd: netsh int ip reset", "wait: 1")))
    [void]$script:macros.Add((New-Macro "Kill background apps" "Closes Discord, browsers, Spotify, Teams and OneDrive." @(
        "ps: Get-Process -Name Discord, chrome, msedge, firefox, Spotify, Teams, ms-teams, OneDrive, Steam -ErrorAction SilentlyContinue | Stop-Process -Force")))
    [void]$script:macros.Add((New-Macro "Quick FPS pack" "Applies free latency and power tweaks in one run." @(
        "tweaks: power, dnsflush, transp", "wait: 1")))
    [void]$script:macros.Add((New-Macro "Clean for benchmark" "Temp clean and DNS flush before a test." @(
        'ps: Remove-Item "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue',
        "cmd: ipconfig /flushdns")))
    [void]$script:macros.Add((New-Macro "Clear shader caches" "Deletes common NVIDIA/AMD/DX shader caches." @(
        'ps: $paths = @("$env:LOCALAPPDATA\NVIDIA\DXCache","$env:LOCALAPPDATA\NVIDIA\GLCache","$env:LOCALAPPDATA\D3DSCache","$env:LOCALAPPDATA\AMD\DxCache"); foreach ($p in $paths) { if (Test-Path $p) { Remove-Item "$p\*" -Recurse -Force -ErrorAction SilentlyContinue } }')))
    [void]$script:macros.Add((New-Macro "Launch Valorant" "Opens Riot Client for Valorant." @("url: riotclient://")))
    [void]$script:macros.Add((New-Macro "Launch CS2" "Opens Counter-Strike 2 via Steam." @("open: steam://rungameid/730")))
    [void]$script:macros.Add((New-Macro "Launch Apex" "Opens Apex Legends via Steam." @("open: steam://rungameid/1172470")))
    [void]$script:macros.Add((New-Macro "Steam Big Picture" "Opens Steam in Big Picture mode." @("open: steam://open/bigpicture")))
    [void]$script:macros.Add((New-Macro "DNS to Cloudflare" "Sets 1.1.1.1 then flushes DNS." @(
        "ps: Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ('1.1.1.1','1.0.0.1') }",
        "wait: 1", "cmd: ipconfig /flushdns")))
    [void]$script:macros.Add((New-Macro "DNS to Google" "Sets 8.8.8.8 then flushes DNS." @(
        "ps: Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ('8.8.8.8','8.8.4.4') }",
        "wait: 1", "cmd: ipconfig /flushdns")))
    Save-Macros
}

$cardMac = New-Card 212 78 652 498
New-Heading "MACRO LIBRARY" 18 12 $cardMac
$macList = New-Object DarkList
$macList.Location = New-Object System.Drawing.Point(18, 40); $macList.Size = New-Object System.Drawing.Size(240, 400)
$macList.BackColor = $cInner; $macList.ForeColor = $cText; $macList.Font = $fUI
$macList.Anchor = "Top, Bottom, Left"
function New-MacBox($y, $h) {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Location = New-Object System.Drawing.Point(276, $y); $t.Size = New-Object System.Drawing.Size(358, $h)
    $t.BackColor = $cInner; $t.ForeColor = $cText; $t.BorderStyle = "FixedSingle"; $t.Font = $fUI
    $t.Anchor = "Top, Left, Right"
    return $t
}
$macName = New-MacBox 58 26
$macDesc = New-MacBox 110 26
$macSteps = New-MacBox 162 216
$macSteps.Multiline = $true; $macSteps.AcceptsReturn = $true; $macSteps.ScrollBars = "Both"; $macSteps.WordWrap = $false
$macSteps.Font = New-Object System.Drawing.Font("Consolas", 9.5); $macSteps.Anchor = "Top, Bottom, Left, Right"
$macHelp = New-Label "One step per line:   ps: PowerShell   cmd: command   open: app or file   url: link   tweaks: id, id   wait: seconds.   Lines starting with # are notes." 276 384 358 52 $fSmall $cMuted $cCard
$macHelp.Anchor = "Bottom, Left, Right"
$cardMac.Controls.AddRange(@($macList,
    (New-Label "Name" 276 40 200 16 $fSmall $cMuted $cCard), $macName,
    (New-Label "Description" 276 92 200 16 $fSmall $cMuted $cCard), $macDesc,
    (New-Label "Steps" 276 144 200 16 $fSmall $cMuted $cCard), $macSteps, $macHelp))
$btnMNew    = New-Button "New" 18 452 87 40 "neutral"
$btnMSave   = New-Button "Save" 100 452 87 40 "good"
$btnMDel    = New-Button "Delete" 182 452 87 40 "neutral"
$btnMImport = New-Button "Import" 276 452 98 40 "neutral"
$btnMExport = New-Button "Export" 368 452 98 40 "neutral"
$btnMRun    = New-Button "Run macro" 460 452 174 40 "accent"
foreach ($b in @($btnMNew, $btnMSave, $btnMDel, $btnMImport, $btnMExport, $btnMRun)) { $b.Anchor = "Bottom, Left" }
$btnMRun.Anchor = "Bottom, Right"
$cardMac.Controls.AddRange(@($btnMNew, $btnMSave, $btnMDel, $btnMImport, $btnMExport, $btnMRun))
Add-ToPage "macros" $cardMac

function Show-Macro($m) {
    if ($m) { $macName.Text = $m.Name; $macDesc.Text = $m.Desc; $macSteps.Text = (@($m.Steps) -join "`r`n") }
    else { $macName.Text = ""; $macDesc.Text = ""; $macSteps.Text = "" }
}
function Refresh-MacList($sel) {
    $macList.BeginUpdate(); $macList.Items.Clear()
    foreach ($m in $script:macros) { [void]$macList.Items.Add($m.Name) }
    $macList.EndUpdate()
    if ($macList.Items.Count -gt 0) { $macList.SelectedIndex = [math]::Max(0, [math]::Min([int]$sel, $macList.Items.Count - 1)) }
    else { Show-Macro $null }
}
function Get-EditorSteps { @($macSteps.Lines | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith("#") }) }

$macList.Add_SelectedIndexChanged({ if ($macList.SelectedIndex -ge 0) { Show-Macro $script:macros[$macList.SelectedIndex] } })
$btnMNew.Add_Click({
    $macList.ClearSelected(); Show-Macro $null
    $macName.Text = "My macro"; $macSteps.Text = "# Example steps`r`ncmd: ipconfig /flushdns`r`nwait: 1"
    $macName.Focus(); $macName.SelectAll()
})
$btnMSave.Add_Click({
    $n = $macName.Text.Trim()
    if (-not $n) { Log "Give the macro a name first."; return }
    $steps = @(Get-EditorSteps)
    $bad = @($steps | Where-Object { $_ -notmatch '^(ps|cmd|open|url|tweaks|wait)\s*:' })
    if ($bad.Count) { Log "Unknown step: $($bad[0])  (start each line with ps:, cmd:, open:, url:, tweaks: or wait:)"; return }
    $m = New-Macro $n $macDesc.Text.Trim() $steps
    $i = $macList.SelectedIndex
    if ($i -ge 0) { $script:macros[$i] = $m } else { [void]$script:macros.Add($m); $i = $script:macros.Count - 1 }
    Save-Macros; Refresh-MacList $i; Log "Saved macro: $n"
})
$btnMDel.Add_Click({
    $i = $macList.SelectedIndex
    if ($i -lt 0) { return }
    $q = [System.Windows.Forms.MessageBox]::Show("Delete the macro '$($script:macros[$i].Name)'?", "TKL Tweaks", "YesNo", "Question")
    if ($q -ne "Yes") { return }
    $script:macros.RemoveAt($i); Save-Macros; Refresh-MacList $i; Log "Macro deleted."
})
$btnMExport.Add_Click({
    $list = @($script:macros)
    if ($macList.SelectedIndex -ge 0) { $list = @($script:macros[$macList.SelectedIndex]) }
    if ($list.Count -eq 0) { return }
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = "TKL macros|*.json"; $dlg.FileName = (($list[0].Name -replace '[^\w\- ]', '') + ".json")
    if ($dlg.ShowDialog() -eq "OK") {
        ConvertTo-Json -InputObject $list -Depth 5 | Set-Content -LiteralPath $dlg.FileName -Encoding UTF8
        Log "Exported $($list.Count) macro(s) to $($dlg.FileName)"
    }
})
$btnMImport.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = "TKL macros|*.json"
    if ($dlg.ShowDialog() -ne "OK") { return }
    try { $new = @(Read-MacroFile $dlg.FileName) } catch { Log "That file is not a valid macro file."; return }
    if ($new.Count -eq 0) { Log "No macros found in that file."; return }
    $names = ($new | Select-Object -First 8 | ForEach-Object { " - " + $_.Name }) -join "`n"
    $q = [System.Windows.Forms.MessageBox]::Show("Import $($new.Count) macro(s)?`n`n$names`n`nMacros run commands on your PC as Administrator. Only import macros from people you trust, and read the steps before running them.",
        "TKL Tweaks", "YesNo", "Warning")
    if ($q -ne "Yes") { return }
    foreach ($m in $new) { [void]$script:macros.Add($m) }
    Save-Macros; Refresh-MacList ($script:macros.Count - 1); Log "Imported $($new.Count) macro(s)."
})

# Macros run one step per timer tick; commands run in a background runspace so the window never freezes
$script:macQueue = $null; $script:macPs = $null; $script:macHandle = $null
$script:macWaitUntil = [datetime]::MinValue; $script:macRunName = ""
$macTimer = New-Object System.Windows.Forms.Timer
$macTimer.Interval = 100
function Stop-Macro($msg) {
    $macTimer.Stop(); $script:macQueue = $null
    if ($script:macPs) { try { $script:macPs.Stop(); $script:macPs.Dispose() } catch { }; $script:macPs = $null }
    $btnMRun.Text = "Run macro"; Log $msg; $script:statusLbl.Text = $msg
}
$btnMRun.Add_Click({
    if ($script:macQueue) { Stop-Macro "Macro stopped."; return }
    $steps = @(Get-EditorSteps)
    if ($steps.Count -eq 0) { Log "This macro has no steps."; return }
    $script:macQueue = New-Object System.Collections.Queue
    foreach ($s in $steps) { $script:macQueue.Enqueue($s) }
    $script:macRunName = $macName.Text; $script:macWaitUntil = [datetime]::MinValue
    $btnMRun.Text = "Stop"
    Log "Running macro: $($script:macRunName) ($($steps.Count) steps)"
    $script:statusLbl.Text = "Running macro: $($script:macRunName)..."
    $macTimer.Start()
})
$macTimer.Add_Tick({
    if (-not $script:macQueue) { $macTimer.Stop(); return }
    if ($script:macPs) {
        if (-not $script:macHandle.IsCompleted) { return }
        try {
            foreach ($o in $script:macPs.EndInvoke($script:macHandle)) { foreach ($ln in ("$o" -split "`r?`n")) { if ($ln.Trim()) { Log "      $ln" } } }
            foreach ($er in $script:macPs.Streams.Error) { Log "      Error: $er" }
        } catch { Log "      Error: $($_.Exception.Message)" }
        $script:macPs.Dispose(); $script:macPs = $null
    }
    if ([datetime]::Now -lt $script:macWaitUntil) { return }
    if ($script:macQueue.Count -eq 0) { Stop-Macro "Macro finished: $($script:macRunName)"; return }
    $step = [string]$script:macQueue.Dequeue()
    $ix = $step.IndexOf(":")
    $kind = $step.Substring(0, $ix).Trim().ToLower(); $val = $step.Substring($ix + 1).Trim()
    Log "  > $kind  $val"
    try {
        switch ($kind) {
            "wait"   { $script:macWaitUntil = [datetime]::Now.AddSeconds([double]$val) }
            "tweaks" { Apply-Ids @($val -split '[,\s]+' | Where-Object { $_ }) }
            { $_ -eq "open" -or $_ -eq "url" } { Start-Process -FilePath "cmd.exe" -ArgumentList "/c start `"`" $val" -WindowStyle Hidden }
            default {
                $script:macPs = [powershell]::Create()
                if ($kind -eq "cmd") { [void]$script:macPs.AddScript('param($c) cmd.exe /c $c 2>&1 | Out-String').AddArgument($val) }
                else { [void]$script:macPs.AddScript($val).AddCommand("Out-String") }
                $script:macHandle = $script:macPs.BeginInvoke()
            }
        }
    } catch { Log "      Failed: $($_.Exception.Message)" }
})

# ---------- Bigger window: grow every page to fill the larger client area ----------
$growX = 420; $growY = 220
function Grow-Card($card, $dx, $dy) {
    $W = $card.Width; $H = $card.Height
    $default = [System.Windows.Forms.AnchorStyles]"Top, Left"
    foreach ($c in @($card.Controls)) {
        if ($c.Anchor -ne $default) { continue }
        $a = [System.Windows.Forms.AnchorStyles]::Left
        if ($dx -and $c.Right -ge ($W - 30) -and $c.Width -ge 200) { $a = $a -bor [System.Windows.Forms.AnchorStyles]::Right }
        if ($dy -and $c.Top -ge ($H - 62)) { $a = $a -bor [System.Windows.Forms.AnchorStyles]::Bottom }
        else {
            $a = $a -bor [System.Windows.Forms.AnchorStyles]::Top
            if ($dy -and $c.Height -ge 200) { $a = $a -bor [System.Windows.Forms.AnchorStyles]::Bottom }
        }
        $c.Anchor = $a
    }
    $card.Size = New-Object System.Drawing.Size(($W + $dx), ($H + $dy))
    Set-Rounded $card 14
}
foreach ($c in @($canvas.Controls)) {
    if ($c -isnot [Card] -or $c -eq $sidebar -or $c -eq $winCard) { continue }
    if ($c.Name -like "planCard*") { continue }
    if ($c -eq $statusCard) { $c.Top += $growY; Grow-Card $c $growX 0; continue }
    $dy = 0; if ($c.Bottom -eq 576 -or $c.Bottom -eq 598) { $dy = $growY }
    if ($c.Left -ge 200 -and $c -ne $sidebar) { Grow-Card $c $growX $dy }
}
# Place Free / Premium / Ultimate in a clean equal row
function Layout-PlanCards {
    if (-not $script:planCards -or $script:planCards.Count -lt 3) { return }
    $left = 212
    $top = 248
    $gap = 14
    $avail = [math]::Max(600, $form.ClientSize.Width - $left - 16)
    $w = [int](($avail - 2 * $gap) / 3)
    if ($w -lt 180) { $w = 180 }
    for ($i = 0; $i -lt 3; $i++) {
        $pc = $script:planCards[$i].Card
        $pc.Left = $left + $i * ($w + $gap)
        $pc.Top = $top
        $pc.Width = $w
        $pc.Height = 210
        $pc.BorderColor = $planCol[$i]
        Set-Rounded $pc 16
    }
}
Layout-PlanCards
foreach ($c in @($sidebar.Controls)) { if ($c.Top -ge 370) { $c.Top += $growY } }
$sidebar.Height += $growY; Set-Rounded $sidebar 22
$form.ClientSize = New-Object System.Drawing.Size((880 + $growX), (640 + $growY))
$winCard.Left = $form.ClientSize.Width - $winCard.Width - 16
$winCard.Top = 14
# Stretch tall content cards to use the extra height
foreach ($c in @($canvas.Controls)) {
    if ($c -is [Card] -and $c -ne $sidebar -and $c -ne $winCard -and $c -ne $statusCard) {
        if ($c.Left -ge 200 -and $c.Height -gt 280) {
            $c.Height = [math]::Max($c.Height, $form.ClientSize.Height - $c.Top - 56)
            Set-Rounded $c 16
        }
    }
}
if ($statusCard) { $statusCard.Top = $form.ClientSize.Height - $statusCard.Height - 16 }
$sidebar.Height = $form.ClientSize.Height - 32
Set-Rounded $sidebar 16
Layout-Main

# ---------- Saved appearance, then start ----------
$form.Add_FormClosing({ if ($script:boost) { Stop-Boost }; $macTimer.Stop(); $pingTimer.Stop(); $saveTimer.Stop(); Save-Settings; Save-Account })

$styleBox.SelectedItem = [string]$settings.Style
if ($styleBox.SelectedIndex -lt 0) { $styleBox.SelectedIndex = 0 }
$sCount.Bar.Value = [math]::Min(120, [math]::Max(10, [int]$settings.Count))
$sSpeed.Bar.Value = [math]::Min(300, [math]::Max(10, [int]$settings.Speed))
$sDim.Bar.Value   = [math]::Min(90,  [math]::Max(0,  [int]$settings.Dim))
$sGlass.Bar.Value = [math]::Min(90, [math]::Max(0, [int]$settings.Glass)); $sGlass.Val.Text = "$($sGlass.Bar.Value)%"
Set-Glass $sGlass.Bar.Value
$sGlow.Bar.Value  = [math]::Min(200, [math]::Max(0,  [int]$settings.Glow))
$sCount.Val.Text = "$($sCount.Bar.Value)"; $sSpeed.Val.Text = "$($sSpeed.Bar.Value)%"; $sDim.Val.Text = "$($sDim.Bar.Value)%"; $sGlow.Val.Text = "$($sGlow.Bar.Value)%"
$canvas.Glow = [single]($sGlow.Bar.Value / 100.0)
$chkVig.Checked = [bool]$settings.Vignette; $canvas.Vignette = $chkVig.Checked
$canvas.Count = $sCount.Bar.Value; $canvas.Speed = [single]($sSpeed.Bar.Value / 100.0)
$canvas.Dim = [single]($sDim.Bar.Value / 100.0); $canvas.Rebuild()
$chkAnim.Checked = [bool]$settings.Animate
if ($settings.Image -and (Test-Path $settings.Image)) { try { $canvas.SetImage($settings.Image) } catch { } }
if ("$($settings.Custom)" -match '^(\d+),(\d+),(\d+)$') {
    Set-CustomTheme ([System.Drawing.Color]::FromArgb([int]$matches[1], [int]$matches[2], [int]$matches[3]))
}
Apply-Theme ([string]$settings.Theme)

# Mark tweaks that are already applied (from saved backups)
foreach ($id in @($script:backup.Keys)) { if ($script:tweakById.ContainsKey($id)) { $tweakList.SetApplied($id, $true) } }

# Sign in: automatic if the user asked to stay signed in, otherwise show the login window
if ($script:acct.User -and $script:acct.Auto -and (-not $TKL.ApiUrl)) {
    $script:user = $script:acct.User
    Set-Session $script:user (Get-AccountPlan)
} else {
    $lr = Show-Login $true
    if (-not $lr) { exit }
    Complete-Login $lr
}

Load-Macros; Refresh-MacList 0
Select-Page "dash"
Update-ListInfo
Log "Welcome to $($TKL.Brand). Tip: run a latency test BEFORE applying tweaks, then again after."
[void]$form.ShowDialog()

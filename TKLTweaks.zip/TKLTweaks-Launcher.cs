// TKL Tweaks launcher — compile with csc.exe (see Build-Launcher.bat)
// Runs TKLTweaks.ps1 from the same folder, elevated, no console window.
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

static class Program
{
    [STAThread]
    static void Main()
    {
        try
        {
            string dir = AppDomain.CurrentDomain.BaseDirectory;
            string ps1 = Path.Combine(dir, "TKLTweaks.ps1");
            if (!File.Exists(ps1))
            {
                MessageBox.Show(
                    "TKLTweaks.ps1 was not found.\n\nPut TKLTweaks.exe and TKLTweaks.ps1 in the same folder.",
                    "TKL Tweaks",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            // Re-launch elevated if needed
            try
            {
                using (var id = System.Security.Principal.WindowsIdentity.GetCurrent())
                {
                    var p = new System.Security.Principal.WindowsPrincipal(id);
                    if (!p.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator))
                    {
                        var elev = new ProcessStartInfo
                        {
                            FileName = Application.ExecutablePath,
                            UseShellExecute = true,
                            Verb = "runas",
                            WorkingDirectory = dir
                        };
                        try { Process.Start(elev); }
                        catch { /* user cancelled UAC */ }
                        return;
                    }
                }
            }
            catch { }

            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"" + ps1 + "\"",
                WorkingDirectory = dir,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            Process.Start(psi);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "TKL Tweaks", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}

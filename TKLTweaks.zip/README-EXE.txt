TKL Tweaks — EXE launcher
=========================

WHY NOT "BAT TO EXE" WEBSITES?
  Those tools often pack scripts in ways antivirus calls malware.
  This builds a tiny real .NET exe with the Windows compiler.

BUILD (on your Windows PC)
  1. Copy this folder to your PC
  2. Double-click Build-Launcher.bat
  3. You get TKLTweaks.exe

SHIP TO FRIENDS
  Same folder:
    TKLTweaks.exe      ← double-click this
    TKLTweaks.ps1      ← still required (the real app)

  Optional: keep Launch TKL Tweaks.bat as backup

WHAT THE EXE DOES
  - Asks for Administrator (UAC)
  - Starts TKLTweaks.ps1 hidden via PowerShell
  - No console flash

NOTE
  Antivirus may still flag a new unsigned exe. That is common.
  Signing with a code-signing certificate reduces that (paid).

@echo off
title Build TKL Tweaks EXE launcher
cd /d "%~dp0"

set CSC=
if exist "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if exist "%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe

if "%CSC%"=="" (
  echo Could not find csc.exe
  echo Install .NET Framework 4.x or use Developer Command Prompt.
  pause
  exit /b 1
)

echo Compiling TKLTweaks.exe ...
"%CSC%" /nologo /target:winexe /optimize+ /r:System.Windows.Forms.dll /r:System.dll /out:TKLTweaks.exe TKLTweaks-Launcher.cs
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)

echo.
echo OK - created TKLTweaks.exe
echo.
echo Put these in the SAME folder for friends:
echo   TKLTweaks.exe
echo   TKLTweaks.ps1
echo.
echo Do NOT ship this Build-Launcher.bat or the .cs file unless you want them to rebuild.
pause
